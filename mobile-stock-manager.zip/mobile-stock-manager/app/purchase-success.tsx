import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  Easing,
  ScrollView,
  Platform,
} from 'react-native';
import { Stack, useRouter, useLocalSearchParams } from 'expo-router';
import { BlurView } from 'expo-blur';

const { width, height } = Dimensions.get('window');
const maxScale = Math.sqrt(width * width + height * height) / 60;

export default function PurchaseSuccess() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const [isNavigating, setIsNavigating] = useState(false);

  const glowAnim = useRef(new Animated.Value(0)).current;
  const checkScale = useRef(new Animated.Value(0)).current;
  const transitionAnim = useRef(new Animated.Value(0)).current;
  const fadeCircle = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.timing(fadeCircle, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start();

    Animated.parallel([
      Animated.spring(checkScale, {
        toValue: 1,
        friction: 5,
        tension: 120,
        useNativeDriver: true,
      }),
      Animated.loop(
        Animated.sequence([
          Animated.timing(glowAnim, {
            toValue: 1,
            duration: 900,
            useNativeDriver: true,
          }),
          Animated.timing(glowAnim, {
            toValue: 0,
            duration: 900,
            useNativeDriver: true,
          }),
        ])
      ),
    ]).start();
  }, []);

  const handleCircleNavigation = (destination: string) => {
    setIsNavigating(true);
    transitionAnim.setValue(0);

    // Expand circle to reveal the destination page below
    Animated.timing(transitionAnim, {
      toValue: 1,
      duration: 800,
      easing: Easing.out(Easing.ease),
      useNativeDriver: true,
    }).start(() => {
      // Navigate after animation completes
      if (destination === 'back') {
        router.back();
      } else if (destination === '/') {
        // Navigate DIRECTLY to Dashboard (tabs) with refresh param
        router.replace({ pathname: '/(tabs)', params: { refresh: Date.now().toString() } } as any);
      } else {
        router.replace({ pathname: destination, params: { refresh: Date.now().toString() } } as any);
      }

      // After navigation completes, hide the overlay
      setTimeout(() => {
        setIsNavigating(false);
        transitionAnim.setValue(0);
      }, 100);
    });
  };

  return (
    <View style={styles.mainContainer}>
      <Stack.Screen options={{ headerShown: false }} />
      
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
      >
        <BlurView intensity={90} tint="light" style={styles.header}>
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => router.back()}
          >
            <Text style={styles.backIcon}>❮</Text>
          </TouchableOpacity>

          <Text style={styles.headerTitle}>
            Purchase Successful
          </Text>
        </BlurView>

        <View style={styles.successWrap}>
          <Animated.View
            style={[
              styles.glow,
              {
                opacity: glowAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.2, 0.45],
                }),
                transform: [
                  {
                    scale: glowAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [1, 1.18],
                    }),
                  },
                ],
              },
            ]}
          />

          <Animated.View
            style={[
              styles.check,
              {
                transform: [{ scale: checkScale }],
              },
            ]}
          >
            <Text style={styles.tick}>✓</Text>
          </Animated.View>
        </View>

        <Text style={styles.title}>Purchase Successful!</Text>
        <Text style={styles.subtitle}>
          Inventory updated successfully
        </Text>

        <View style={styles.card}>
          <Row label="Model" value={params.model} />
          <Row label="IMEI" value={params.imei1} />
          <Row label="Purchase Price" value={`₹${params.price}`} />
          <Row label="MOP" value={params.mop} />
          <Row
            label="Purchase Date"
            value={new Date(params.purchaseDate as string).toLocaleString()}
            noBorder
          />
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => handleCircleNavigation('/')}
          >
            <Text style={styles.primaryText}>
              BACK TO DASHBOARD
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryBtn}
            onPress={() => handleCircleNavigation('/purchase')}
          >
            <Text style={styles.secondaryText}>
              BACK TO PURCHASE
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {isNavigating && (
        <Animated.View
          pointerEvents="none"
          style={[
            styles.navCircle,
            {
              transform: [
                {
                  scale: transitionAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, maxScale],
                  }),
                },
              ],
              opacity: transitionAnim.interpolate({
                inputRange: [0, 0.7, 1],
                outputRange: [1, 1, 0],
              }),
            },
          ]}
        />
      )}

      <Animated.View
        pointerEvents="none"
        style={[
          styles.pageCircleOverlay,
          {
            opacity: fadeCircle,
          },
        ]}
      />
    </View>
  );
}

function Row({
  label,
  value,
  noBorder = false,
}: {
  label: string;
  value: any;
  noBorder?: boolean;
}) {
  return (
    <View
      style={[
        styles.row,
        noBorder && { borderBottomWidth: 0 },
      ]}
    >
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: '#007BFF',
  },
  scrollView: {
    flex: 1,
  },
  container: {
    padding: 20,
    alignItems: 'center',
    paddingTop: Platform.OS === 'android' ? 140 : 120,
    paddingBottom: 40,
  },
  header: {
    position: 'absolute',
    top: Platform.OS === 'android' ? 40 : 50,
    left: 16,
    right: 16,
    borderRadius: 24,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    overflow: 'hidden',
    zIndex: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  backBtn: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  backIcon: {
    fontSize: 22,
    color: '#007BFF',
    fontWeight: '700',
    marginLeft: -2,
  },
  headerTitle: {
    flex: 1,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '800',
    color: '#1A202C',
    marginRight: 44,
  },
  successWrap: {
    width: 160,
    height: 160,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  glow: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 80,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  check: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
  },
  tick: {
    fontSize: 64,
    color: '#007BFF',
    fontWeight: '700',
  },
  title: {
    marginTop: 28,
    fontSize: 32,
    fontWeight: '900',
    color: '#fff',
    textAlign: 'center',
  },
  subtitle: {
    marginTop: 8,
    color: '#EAF4FF',
    fontSize: 16,
    fontWeight: '600',
  },
  card: {
    width: '100%',
    marginTop: 32,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 28,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.15)',
  },
  rowLabel: {
    color: '#EAF4FF',
    fontSize: 14,
    fontWeight: '600',
  },
  rowValue: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '800',
    textAlign: 'right',
    flex: 1,
    marginLeft: 20,
  },
  buttonContainer: {
    width: '100%',
    marginTop: 32,
    gap: 16,
  },
  primaryBtn: {
    width: '100%',
    paddingVertical: 18,
    borderRadius: 20,
    backgroundColor: '#fff',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  secondaryBtn: {
    width: '100%',
    paddingVertical: 18,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#fff',
    alignItems: 'center',
  },
  primaryText: {
    color: '#007BFF',
    fontWeight: '900',
    fontSize: 16,
    letterSpacing: 1,
  },
  secondaryText: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 16,
    letterSpacing: 1,
  },
  navCircle: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: 120,
    height: 120,
    marginLeft: -60,
    marginTop: -60,
    borderRadius: 60,
    backgroundColor: '#ffffff',
    zIndex: 9999,
  },
  pageCircleOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#ffffff',
    zIndex: 9999,
  },
});
