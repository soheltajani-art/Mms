import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import { ChevronLeft, BarChart2, Package, ShoppingCart, TrendingUp, Camera, Search, Calculator } from 'lucide-react-native';
import { useRouter } from 'expo-router';

const HowItWorksPage = () => {
  const router = useRouter();

  const howItWorksData = [
    {
      title: 'Dashboard: Your Business Overview',
      icon: <BarChart2 size={24} color="#1565C0" />,
      description: 'The dashboard is your command center, providing a real-time snapshot of your business. Each block is designed for quick insights:',
      subPoints: [
        'Total Sales: Shows the total revenue generated from all completed sales.',
        'Total Purchase: Displays the total amount of money you have invested in your inventory.',
        'Available Stock: The number of items currently in your inventory and ready to be sold.',
        'Sold Stock: The total number of items you have sold.',
        'Today\'s Profit: Your net profit for the current day, calculated in real-time.'
      ],
      footer: 'These metrics help you make informed decisions quickly and efficiently.'
    },
    {
      title: 'How App Calculations Work',
      icon: <Calculator size={24} color="#FF6F00" />,
      description: 'The app performs several calculations automatically to provide you with accurate financial metrics. The most important calculation is profit:',
      subPoints: [
        'Profit Calculation: Profit for each sale is calculated using a simple formula:',
        'Profit = Selling Price - Purchase Price',
        'Example: If you buy a phone for ₹10,000 (Purchase Price) and sell it for ₹12,000 (Selling Price), your profit is ₹2,000.',
        'Today\'s Profit: The dashboard displays \"Today\'s Profit,\" which is the sum of profits from all sales made on the current day.'
      ],
      footer: 'This automated calculation ensures that you always have an accurate understanding of your profitability.'
    },
    {
      title: 'Adding Products to Your Inventory (Purchase)',
      icon: <Package size={24} color="#1E8449" />,
      description: 'Easily add new items to your inventory through the purchase screen. You will find a simple form with input fields for all necessary product details, such as:',
      subPoints: [
        'Product Name/Model',
        'IMEI or Serial Number (for unique identification)',
        'Purchase Price',
        'Supplier Information',
        'Product Specifications (e.g., color, storage)',
      ],
      footer: 'Once submitted, the new product is automatically added to your \"Available Stock\" and becomes ready for sale.'
    },
    {
      title: 'Selling a Product',
      icon: <ShoppingCart size={24} color="#C62828" />,
      description: 'Our sales process is streamlined for speed and accuracy. Here’s how it works:',
      subPoints: [
        'Search for the product: Use the dedicated search bar to find a product by its unique IMEI number. The search input has validation to ensure you enter the correct format.',
        'Select the product: Once the IMEI is verified, the product\'s details are automatically fetched.',
        'Enter sale details: Fill in the input fields for customer information, selling price, and any additional notes.',
        'Complete the sale: After confirming the details, the product is marked as \"Sold.\" It is automatically moved from your available inventory to the \"Sold Out Items\" section for your records.',
      ],
      footer: 'You can even search for another product immediately after a sale using the \"Search Another Product\" button, making consecutive sales seamless.'
    },
    {
      title: 'Powerful Search Bars',
      icon: <Search size={24} color="#F9A825" />,
      description: 'The app features powerful search functionality on multiple pages to help you find what you need quickly:',
      subPoints: [
        'Features Search: On the \"Features\" page, use the search bar at the top to filter and find any feature by its name, description, or keywords.',
        'Product Search (IMEI): On the \"Sell Stock\" page, the search bar is specifically designed to look up products by their IMEI. The search button is disabled until you enter an IMEI, ensuring you always search with the correct identifier.',
      ],
    },
    {
      title: 'Advanced Tools: Barcode Scanner & Image Capture',
      icon: <Camera size={24} color="#37474F" />,
      description: 'To further enhance your workflow, the app includes:',
      subPoints: [
          'Barcode Scanner: Use your device’s camera to scan product barcodes for quick checkouts and inventory updates, reducing manual entry and saving time.',
          'Image Capturing: Add a personal touch by capturing and uploading images for your products directly within the app. A visual reference makes product identification much easier.',
      ]
    },
     {
      title: 'Analytics & Reporting',
      icon: <TrendingUp size={24} color="#512DA8" />,
      description: 'Track your business performance with our detailed analytics and reporting tools:',
      subPoints: [
          'Daily Performance: Get a summary of your sales, profits, and activities for any selected date.',
          'Lifetime History: Access a comprehensive overview of your business growth and performance over time.',
      ]
    }
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>How to Use the App</Text>
        <View style={{ width: 24 }} />
      </View>
      <View style={styles.contentWrapper}>
        <ScrollView contentContainerStyle={styles.contentContainer}>
          {howItWorksData.map((item, index) => (
            <View key={index} style={styles.itemContainer}>
              <View style={styles.itemHeader}>
                <View style={styles.itemIcon}>{item.icon}</View>
                <Text style={styles.itemTitle}>{item.title}</Text>
              </View>
              <Text style={styles.itemDescription}>{item.description}</Text>
              {item.subPoints && (
                <View style={styles.subPointsContainer}>
                  {item.subPoints.map((point, subIndex) => (
                    <Text key={subIndex} style={styles.subPoint}>• {point}</Text>
                  ))}
                </View>
              )}
              {item.footer && (
                  <Text style={styles.itemFooter}>{item.footer}</Text>
              )}
            </View>
          ))}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#E3F2FD',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingVertical: 12,
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        marginHorizontal: 16,
        marginTop: 16,
        borderWidth: 2,
        borderColor: '#E5E7EB',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 4,
        elevation: 2,
    },
    headerTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: '#000',
    },
    backButton: {
        backgroundColor: '#FFFFFF',
        borderRadius: 10,
        padding: 8,
        borderWidth: 1.5,
        borderColor: '#E5E7EB',
    },
    contentWrapper: {
      flex: 1,
      backgroundColor: '#FFFFFF',
      borderRadius: 30,
      marginTop: 16,
      overflow: 'hidden',
      marginHorizontal: 16,
      marginBottom: 16,
    },
    contentContainer: {
      padding: 16,
      paddingBottom: 24,
    },
    itemContainer: {
      backgroundColor: '#FFFFFF',
      borderRadius: 16,
      padding: 16,
      marginBottom: 16,
      borderWidth: 1,
      borderColor: '#E5E7EB',
    },
    itemHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 12,
    },
    itemIcon: {
      marginRight: 12,
    },
    itemTitle: {
      fontSize: 18,
      fontWeight: '600',
      color: '#000',
      flex: 1,
    },
    itemDescription: {
      fontSize: 14,
      color: '#666',
      lineHeight: 20,
    },
    subPointsContainer: {
      marginTop: 10,
      paddingLeft: 10,
    },
    subPoint: {
      fontSize: 14,
      color: '#666',
      lineHeight: 20,
    },
    itemFooter: {
        marginTop: 12,
        fontSize: 14,
        color: '#333',
        fontStyle: 'italic',
        lineHeight: 20,
    },
  });
  

export default HowItWorksPage;
