import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform, Modal } from 'react-native';
import { Feather } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';

interface DatePickerModalProps {
  visible: boolean;
  currentDate: Date;
  onDateChange: (date: Date) => void;
  onClose: () => void;
}

const DatePickerModal: React.FC<DatePickerModalProps> = ({
  visible,
  currentDate,
  onDateChange,
  onClose,
}) => {
  const [tempDate, setTempDate] = useState(currentDate);

  // Sync tempDate with currentDate when modal opens
  React.useEffect(() => {
    if (visible) {
      setTempDate(currentDate);
    }
  }, [visible, currentDate]);

  const handleDateChange = (event: any, selectedDate?: Date) => {
    if (Platform.OS === 'android') {
      onClose();
      if (selectedDate) {
        onDateChange(selectedDate);
      }
    } else if (Platform.OS === 'web') {
      // Web doesn't show native picker, so we keep the modal open
      if (selectedDate) {
        setTempDate(selectedDate);
      }
    } else {
      // iOS keeps picker open until user confirms
      if (selectedDate) {
        setTempDate(selectedDate);
      }
    }
  };

  const handleConfirm = () => {
    onDateChange(tempDate);
    onClose();
  };

  const handleCancel = () => {
    // Reset to the current date from props
    setTempDate(new Date(currentDate));
    onClose();
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  // Web fallback: Use HTML input
  if (Platform.OS === 'web') {
    return (
      <Modal
        visible={visible}
        transparent={true}
        animationType="fade"
        onRequestClose={handleCancel}
      >
        <View style={styles.webModalOverlay}>
          <View style={styles.webModalContent}>
            <Text style={styles.webModalTitle}>Select Date</Text>
            
            <View style={styles.webDateInputContainer}>
              <input
                type="date"
                value={tempDate.toISOString().split('T')[0]}
                onChange={(e) => {
                  if (e.target.value) {
                    const [year, month, day] = e.target.value.split('-');
                    setTempDate(new Date(parseInt(year), parseInt(month) - 1, parseInt(day)));
                  }
                }}
                style={styles.webDateInput as any}
              />
            </View>

            <Text style={styles.webSelectedDate}>{formatDate(tempDate)}</Text>

            <View style={styles.webButtonContainer}>
              <TouchableOpacity style={styles.webCancelButton} onPress={handleCancel}>
                <Text style={styles.webCancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.webConfirmButton} onPress={handleConfirm}>
                <Text style={styles.webConfirmButtonText}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  }

  // Native picker for Android and iOS
  return (
    <>
      {visible && (
        <DateTimePicker
          testID="dateTimePicker"
          value={tempDate}
          mode="date"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={handleDateChange}
        />
      )}
      {Platform.OS === 'ios' && visible && (
        <Modal
          visible={visible}
          transparent={true}
          animationType="slide"
          onRequestClose={handleCancel}
        >
          <View style={styles.iosModalOverlay}>
            <View style={styles.iosModalContent}>
              <View style={styles.iosHeader}>
                <TouchableOpacity onPress={handleCancel}>
                  <Text style={styles.iosCancelText}>Cancel</Text>
                </TouchableOpacity>
                <Text style={styles.iosTitle}>Select Date</Text>
                <TouchableOpacity onPress={handleConfirm}>
                  <Text style={styles.iosConfirmText}>Done</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  // Web styles
  webModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  webModalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    width: '90%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  webModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 16,
    textAlign: 'center',
  },
  webDateInputContainer: {
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    overflow: 'hidden',
  },
  webDateInput: {
    width: '100%',
    padding: 12,
    fontSize: 16,
    borderWidth: 0,
    fontFamily: 'inherit',
  },
  webSelectedDate: {
    fontSize: 16,
    color: '#1565C0',
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 24,
  },
  webButtonContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  webCancelButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    backgroundColor: '#FFFFFF',
  },
  webCancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
    textAlign: 'center',
  },
  webConfirmButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    backgroundColor: '#1565C0',
  },
  webConfirmButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    textAlign: 'center',
  },

  // iOS styles
  iosModalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  iosModalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  iosHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  iosCancelText: {
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  iosTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
  },
  iosConfirmText: {
    fontSize: 16,
    color: '#1565C0',
    fontWeight: '600',
  },
});

export default DatePickerModal;
