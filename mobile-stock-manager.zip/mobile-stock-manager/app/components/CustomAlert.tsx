import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TextInput,
  Animated,
  Platform,
  KeyboardAvoidingView,
  Dimensions
} from 'react-native';
import { AlertTriangle, Lock, Eye, EyeOff, XCircle } from 'lucide-react-native';
import { BlurView } from 'expo-blur';

interface CustomAlertProps {
  visible: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  showPasswordInput?: boolean;
}

const { width } = Dimensions.get('window');

const CustomAlert: React.FC<CustomAlertProps> = ({
  visible,
  onClose,
  onConfirm,
  title,
  message,
  showPasswordInput = false
}) => {
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const correctPassword = 'Tajani Studio'; // This should ideally come from a secure config or API

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const shakeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 8,
          tension: 40,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 0.8,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start(() => {
        setPassword('');
        setPasswordError('');
        setShowPassword(false);
      });
    }
  }, [visible]);

  const shake = () => {
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 10, duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 50, useNativeDriver: true }),
    ]).start();
  };

  const handleConfirmPress = () => {
    if (showPasswordInput) {
      if (!password.trim()) {
        setPasswordError('Password is required');
        shake();
        return;
      }
      if (password.trim() === correctPassword) {
        onConfirm();
      } else {
        setPasswordError('Incorrect password! Please try again.');
        shake();
        setPassword('');
      }
    } else {
      onConfirm();
    }
  };

  const handleCancelPress = () => {
    onClose();
  };

  if (!visible && fadeAnim._value === 0) return null;

  return (
    <Modal
      transparent={true}
      animationType="none"
      visible={visible}
      onRequestClose={handleCancelPress}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.overlay}
      >
        <Animated.View
          style={[
            styles.backdrop,
            { opacity: fadeAnim }
          ]}
        >
          <TouchableOpacity
            style={styles.backdropClickable}
            activeOpacity={1}
            onPress={handleCancelPress}
          />
        </Animated.View>

        <Animated.View
          style={[
            styles.alertContainer,
            {
              opacity: fadeAnim,
              transform: [
                { scale: scaleAnim },
                { translateX: shakeAnim }
              ]
            }
          ]}
        >
          <BlurView intensity={40} tint="dark" style={styles.blurWrapper}>
            <View style={styles.alertBox}>
              <View style={styles.headerIcon}>
                <View style={styles.iconCircle}>
                  <AlertTriangle size={32} color="#fff" />
                </View>
              </View>

              <Text style={styles.title}>{title}</Text>
              <Text style={styles.message}>{message}</Text>

              {showPasswordInput && (
                <View style={styles.passwordSection}>
                  <View style={[
                    styles.inputWrapper,
                    passwordError ? styles.inputErrorBorder : (isFocused ? styles.inputFocused : styles.inputNormalBorder)
                  ]}>
                    <Lock size={18} color="#A0AEC0" style={styles.inputIcon} />
                    <TextInput
                      style={[
                        styles.input,
                        Platform.OS === 'web' && { outline: 'none' } as any
                      ]}
                      placeholder="Enter password to confirm"
                      placeholderTextColor="#CBD5E0"
                      secureTextEntry={!showPassword}
                      value={password}
                      onChangeText={(text) => {
                        setPassword(text);
                        if (passwordError) setPasswordError('');
                      }}
                      onFocus={() => setIsFocused(true)}
                      onBlur={() => setIsFocused(false)}
                      autoCapitalize="none"
                      autoCorrect={false}
                    />
                    <TouchableOpacity
                      onPress={() => setShowPassword(!showPassword)}
                      style={styles.eyeIcon}
                    >
                      {showPassword ? (
                        <EyeOff size={18} color="#A0AEC0" />
                      ) : (
                        <Eye size={18} color="#A0AEC0" />
                      )}
                    </TouchableOpacity>
                  </View>

                  {passwordError ? (
                    <View style={styles.errorContainer}>
                      <XCircle size={14} color="#EF4444" />
                      <Text style={styles.errorText}>{passwordError}</Text>
                    </View>
                  ) : (
                    <Text style={styles.hintText}>Hint: "Tajani Studio"</Text>
                  )}
                </View>
              )}

              <View style={styles.buttonGroup}>
                <TouchableOpacity
                  style={[styles.button, styles.confirmBtn]}
                  onPress={handleConfirmPress}
                  activeOpacity={0.8}
                >
                  <Text style={styles.confirmBtnText}>YES, DELETE ALL DATA</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.button, styles.cancelBtn]}
                  onPress={handleCancelPress}
                  activeOpacity={0.7}
                >
                  <Text style={styles.cancelBtnText}>CANCEL</Text>
                </TouchableOpacity>
              </View>
            </View>
          </BlurView>
        </Animated.View>
      </KeyboardAvoidingView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.7)', // Slightly less opaque backdrop
  },
  backdropClickable: {
    flex: 1,
  },
  alertContainer: {
    width: width * 0.9, // Slightly wider alert
    maxWidth: 450,
    borderRadius: 20, // Softer corners
    overflow: 'hidden',
    elevation: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  blurWrapper: {
    width: '100%',
  },
  alertBox: {
    padding: 28, // Increased padding
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)', // Lighter background for better contrast
    borderWidth: 1,
    borderColor: '#E2E8F0', // Soft border color
  },
  headerIcon: {
    marginBottom: 24,
  },
  iconCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#EF4444', // Red for danger
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0, // No extra border
  },
  title: {
    fontSize: 24, // Larger title
    fontWeight: 'bold',
    color: '#1A202C', // Darker text for better readability
    marginBottom: 12,
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  message: {
    fontSize: 16,
    color: '#4A5568', // Softer message text
    textAlign: 'center',
    marginBottom: 28,
    lineHeight: 24,
    fontWeight: 'normal',
  },
  passwordSection: {
    width: '100%',
    marginBottom: 28,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F7FAFC', // Light background for input
    borderRadius: 12, // Softer input corners
    paddingHorizontal: 16,
    height: 52, // Slightly smaller input height
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  inputNormalBorder: {
    borderColor: '#E2E8F0',
  },
  inputFocused: {
    borderColor: '#EF4444',
    borderWidth: 2,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
  },
  inputErrorBorder: {
    borderColor: '#EF4444', // Red border for error
    borderWidth: 2,
    backgroundColor: '#FFF5F5',
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    color: '#2D3748', // Darker input text
    fontSize: 16,
    fontWeight: '500',
    paddingVertical: 0, // Remove default vertical padding
  },
  eyeIcon: {
    padding: 8,
  },
  hintText: {
    fontSize: 13,
    color: '#718096', // Softer hint text
    marginTop: 8,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
    gap: 6,
  },
  errorText: {
    fontSize: 14,
    color: '#EF4444', // Red error text
    fontWeight: '600',
  },
  buttonGroup: {
    width: '100%',
    gap: 12,
  },
  button: {
    height: 52, // Consistent button height
    borderRadius: 12, // Softer button corners
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  confirmBtn: {
    backgroundColor: '#EF4444', // Red confirm button
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 4,
  },
  confirmBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
  cancelBtn: {
    backgroundColor: '#E2E8F0', // Light gray cancel button
    borderWidth: 0, // No border needed
  },
  cancelBtnText: {
    color: '#4A5568', // Darker text for cancel button
    fontSize: 15,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
});

export default CustomAlert;
