
import React from 'react';
import { StyleSheet, View, Text } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const ProductDetails = () => {
  return (
    <LinearGradient
      colors={['#eef2f7', '#e6ebf2']}
      style={styles.gradientContainer}
    >
      <View style={styles.container}>
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>U</Text>
            <LinearGradient
              colors={['#22c55e', '#16a34a']}
              style={styles.stock}
            >
              <Text style={styles.stockText}>In Stock</Text>
            </LinearGradient>
          </View>

          <View style={styles.row}>
            <Text style={styles.labelText}>IMEI</Text>
            <Text style={styles.value}>123444444441142</Text>
          </View>
          <View style={styles.divider} />

          <View style={styles.row}>
            <Text style={styles.labelText}>MOP [Market Operating Price]</Text>
            <Text style={styles.value}>₹ 10</Text>
          </View>
          <View style={styles.divider} />

          <View style={styles.row}>
            <Text style={styles.labelText}>Purchase Price</Text>
            <Text style={styles.value}>₹ 9</Text>
          </View>
          <View style={styles.divider} />

          <View style={styles.row}>
            <Text style={styles.labelText}>Purchase Date</Text>
            <Text style={styles.value}>4/19/2026</Text>
          </View>

          <Text style={styles.photoTitle}>Photo Documentation</Text>

          <View style={styles.photoRow}>
            <View style={styles.photoBlock}>
              <View style={[styles.label, styles.required]}>
                <Text style={styles.labelTextRequired}>REQUIRED</Text>
              </View>
              <View style={styles.uploadBox}>
                <Text style={styles.uploadBoxText}>VIEW PHOTO</Text>
              </View>
            </View>

            <View style={styles.photoBlock}>
              <View style={[styles.label, styles.optional]}>
                <Text style={styles.labelTextOptional}>OPTIONAL</Text>
              </View>
              <View style={styles.uploadBox}>
                <Text style={styles.uploadBoxText}>VIEW PHOTO</Text>
              </View>
            </View>
          </View>
        </View>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  gradientContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    width: 380,
  },
  card: {
    backgroundColor: '#f9f9f9',
    borderRadius: 20,
    padding: 20,
    shadowColor: 'rgba(0,0,0,0.08)',
    shadowOffset: { width: 8, height: 8 },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 5,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  stock: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 20,
  },
  stockText: {
    color: 'white',
    fontSize: 13,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  divider: {
    height: 1,
    backgroundColor: '#e5e7eb',
  },
  labelText: {
    color: '#444',
  },
  value: {
    color: '#7b7b7b',
    fontWeight: '500',
  },
  photoTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginVertical: 15,
  },
  photoRow: {
    flexDirection: 'row',
    gap: 12,
  },
  photoBlock: {
    flex: 1,
  },
  label: {
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 12,
    marginBottom: 6,
    alignSelf: 'flex-start',
  },
  required: {
    backgroundColor: '#ffe4e6',
  },
  optional: {
    backgroundColor: '#e0f2fe',
  },
  labelTextRequired: {
    color: '#dc2626',
    fontSize: 11,
    fontWeight: '600',
  },
  labelTextOptional: {
      color: '#0284c7',
      fontSize: 11,
      fontWeight: '600',
  },
  uploadBox: {
    height: 120,
    borderWidth: 2,
    borderColor: '#d1d5db',
    borderStyle: 'dashed',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fafafa',
  },
  uploadBoxText: {
    color: '#9ca3af',
    fontSize: 13,
  },
});

export default ProductDetails;
