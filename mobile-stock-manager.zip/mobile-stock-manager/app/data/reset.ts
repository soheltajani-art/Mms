import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { Platform } from 'react-native';

/**
 * Comprehensive app reset function that clears:
 * 1. All AsyncStorage data
 * 2. All files in the document directory (Native only)
 * 3. Prepares the app for a fresh start
 */
export const resetApp = async (): Promise<void> => {
    try {
        console.log('Starting app reset process...');
        
        // Step 1: Clear all AsyncStorage data (Works on Web, Android, iOS)
        console.log('Clearing AsyncStorage...');
        await AsyncStorage.clear();
        console.log('AsyncStorage cleared successfully');
        
        // Step 2: Clear all files in documentDirectory (Native only)
        if (Platform.OS !== 'web') {
            const docDir = FileSystem.documentDirectory;
            if (docDir) {
                console.log('Clearing document directory:', docDir);
                try {
                    const files = await FileSystem.readDirectoryAsync(docDir);
                    console.log(`Found ${files.length} items to delete`);
                    
                    for (const file of files) {
                        const filePath = `${docDir}${file}`;
                        try {
                            const info = await FileSystem.getInfoAsync(filePath);
                            if (info.exists) {
                                await FileSystem.deleteAsync(filePath, { idempotent: true });
                                console.log(`Deleted: ${file}`);
                            }
                        } catch (fileError) {
                            console.warn(`Failed to delete ${file}:`, fileError);
                        }
                    }
                } catch (dirError) {
                    console.warn('Error reading document directory:', dirError);
                }
            } else {
                console.warn('Document directory not available');
            }
        } else {
            console.log('Skipping FileSystem reset on Web platform');
        }
        
        console.log('✓ App data and files cleared successfully');
    } catch (error) {
        console.error('✗ Failed to clear all app data:', error);
        throw new Error(`Reset failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
};

/**
 * Partial reset - clears only AsyncStorage
 */
export const resetAsyncStorage = async (): Promise<void> => {
    try {
        console.log('Clearing AsyncStorage only...');
        await AsyncStorage.clear();
        console.log('✓ AsyncStorage cleared successfully');
    } catch (error) {
        console.error('✗ Failed to clear AsyncStorage:', error);
        throw error;
    }
};

/**
 * Verify reset was successful by checking if key data is gone
 */
export const verifyReset = async (): Promise<boolean> => {
    try {
        const userName = await AsyncStorage.getItem('userName');
        const shopName = await AsyncStorage.getItem('shopName');
        const isReturning = await AsyncStorage.getItem('isReturningFromWelcome');
        
        const isReset = !userName && !shopName && !isReturning;
        console.log('Reset verification:', { isReset, userName, shopName, isReturning });
        return isReset;
    } catch (error) {
        console.error('Failed to verify reset:', error);
        return false;
    }
};
