import { useRouter } from 'expo-router';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ChevronLeft, Info } from 'lucide-react-native';

export default function AcceptableUsePolicy() {
  const router = useRouter();

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Acceptable Use Policy</Text>
        <View style={{ width: 24 }} />
      </View>

      <Card style={styles.card}>
        <CardHeader>
          <CardTitle style={styles.cardTitle}>
            Mobile Stock Manager [Special Edition] - Acceptable Use Policy
          </CardTitle>
          <Text style={styles.subTitle}>
            By using this app, you agree to use it responsibly and correctly.
          </Text>
        </CardHeader>

        <CardContent>

          <View style={styles.noticeBox}>
            <Info size={24} color="#007AFF" style={styles.noticeIcon} />
            <View style={styles.noticeTextContainer}>
              <Text style={styles.noticeTitle}>Important Notice</Text>
              <Text style={styles.noticeText}>
                Some features may be under development and will be added in future updates. By using this app, you accept this condition.
              </Text>
            </View>
          </View>

          <Text style={styles.sectionTitle}>1. Access</Text>
          <Text style={styles.bulletPoint}>• All users have equal access to app features.</Text>
          <Text style={styles.bulletPoint}>• There are no admin or employee roles in this app.</Text>
          <Text style={styles.bulletPoint}>
            • Individual records cannot be deleted, but all data can be cleared using the reset function.
          </Text>

          <Text style={styles.sectionTitle}>2. Permitted Use</Text>
          <Text style={styles.bulletPoint}>
            • The app is intended for managing and tracking stock data.
          </Text>
          <Text style={styles.bulletPoint}>
            • Users are responsible for entering accurate stock information.
          </Text>
          <Text style={styles.bulletPoint}>
            • Only stock-related data should be stored in the app.
          </Text>

          <Text style={styles.sectionTitle}>3. Prohibited Use</Text>
          <Text style={styles.bulletPoint}>
            • Do not use the app for illegal, harmful, or fraudulent activities.
          </Text>
          <Text style={styles.bulletPoint}>
            • Do not attempt to hack, modify, or reverse engineer the app.
          </Text>
          <Text style={styles.bulletPoint}>
            • Do not misuse or distribute app data without authorization.
          </Text>

          <Text style={styles.sectionTitle}>4. Data Responsibility</Text>
          <Text style={styles.bulletPoint}>
            • All data is stored locally on the device.
          </Text>

          <Text style={styles.sectionTitle}>5. Reset Function</Text>
          <Text style={styles.bulletPoint}>
            • The reset function allows users to delete all stored data.
          </Text>
          <Text style={styles.bulletPoint}>
            • This action permanently removes all data and cannot be undone.
          </Text>

          <Text style={styles.sectionTitle}>6. App Updates and Changes</Text>
          <Text style={styles.bulletPoint}>
            • The app may be updated, modified, or discontinued at any time without notice.
          </Text>

          <Text style={styles.footerText}>
            By using Mobile Stock Manager [Special Edition], you agree to this Acceptable Use Policy.
          </Text>

        </CardContent>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  card: {
    margin: 16,
    marginTop: 0,
    borderRadius: 20,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subTitle: {
    fontSize: 16,
    color: '#6C757D',
    marginBottom: 16,
  },
  noticeBox: {
    backgroundColor: '#E7F3FF',
    borderRadius: 20,
    padding: 16,
    marginVertical: 16,
    flexDirection: 'row',
  },
  noticeIcon: {
    marginRight: 12,
  },
  noticeTextContainer: {
    flex: 1,
  },
  noticeTitle: {
    fontWeight: 'bold',
    color: '#007AFF',
    marginBottom: 4,
  },
  noticeText: {
    color: '#007AFF',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  bulletPoint: {
    fontSize: 16,
    lineHeight: 24,
    color: '#495057',
    marginBottom: 8,
  },
  footerText: {
    marginTop: 24,
    fontSize: 14,
    textAlign: 'center',
    color: '#6C757D',
  },
});