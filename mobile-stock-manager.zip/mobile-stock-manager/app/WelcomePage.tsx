
import { useRouter } from 'expo-router';
import { useState, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, TextInput, ActivityIndicator, Alert, Platform } from 'react-native';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { Checkbox } from '../components/ui/checkbox';
import { Label } from '../components/ui/label';
import { Package, TrendingUp, Zap, CheckCircle2 } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Link } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useFonts, DancingScript_700Bold } from '@expo-google-fonts/dancing-script';
import { BlurView } from 'expo-blur';

export default function WelcomePage() {
  const router = useRouter();

  let [fontsLoaded] = useFonts({
    DancingScript_700Bold,
  });

  const [isTermsAccepted, setIsTermsAccepted] = useState(false);
  const [isPrivacyAccepted, setIsPrivacyAccepted] = useState(false);
  const [isAgreementAccepted, setIsAgreementAccepted] = useState(false);
  const [isPolicyAccepted, setIsPolicyAccepted] = useState(false);
  const [isDisclaimerAccepted, setIsDisclaimerAccepted] = useState(false);
  const [isAllConfirmed, setIsAllConfirmed] = useState(false);
    const [userName, setUserName] = useState('');
    const [shopName, setShopName] = useState('');
    const [focusedField, setFocusedField] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showResetSuccess, setShowResetSuccess] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const stampAnim = useRef(new Animated.Value(0)).current;
  const resetNoticeAnim = useRef(new Animated.Value(0)).current;

  // Load animations on component mount
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        friction: 5,
        useNativeDriver: true,
      }),
    ]).start();

    // Check for reset notification
    const checkResetNotification = async () => {
      const showReset = await AsyncStorage.getItem('showResetNotification');
      if (showReset === 'true') {
        setShowResetSuccess(true);
        await AsyncStorage.removeItem('showResetNotification');
        
        // Animate reset notice
        Animated.sequence([
          Animated.spring(resetNoticeAnim, {
            toValue: 1,
            friction: 8,
            useNativeDriver: true,
          }),
          Animated.delay(4000),
          Animated.timing(resetNoticeAnim, {
            toValue: 0,
            duration: 500,
            useNativeDriver: true,
          })
        ]).start(() => setShowResetSuccess(false));
      }
    };
    checkResetNotification();
  }, []);

  const allCheckboxesTicked = isTermsAccepted && isPrivacyAccepted && isAgreementAccepted && isPolicyAccepted && isDisclaimerAccepted && isAllConfirmed;

  // Handle stamp animation when all checkboxes are ticked
  useEffect(() => {
    if (allCheckboxesTicked) {
      Animated.spring(stampAnim, {
        toValue: 1,
        friction: 3,
        tension: 40,
        useNativeDriver: true,
      }).start();
    } else {
      stampAnim.setValue(0);
    }
  }, [allCheckboxesTicked]);

  const handleContinue = async () => {
    if (canContinue) {
      setIsLoading(true);
      // Extra delay for UX feel if needed, but the stamp is already shown
      setTimeout(async () => {
          await AsyncStorage.setItem('isReturningFromWelcome', 'true');
          await AsyncStorage.setItem('userName', userName.trim());
          await AsyncStorage.setItem('shopName', shopName.trim());
          router.replace('/Loading-screen');
      }, 500);
    }
  };

  const canContinue = allCheckboxesTicked && userName.trim() !== '' && shopName.trim() !== '';

  const stampRotation = stampAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['-45deg', '-45deg'],
  });

  const stampScale = stampAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1.5, 1],
  });

  if (!fontsLoaded) {
    return null; 
  }

  return (
    <LinearGradient
      colors={['#E0E7FF', '#F0F2F5', '#E0E7FF']}
      style={styles.gradientContainer}
    >
      {showResetSuccess && (
        <Animated.View style={[styles.resetNotice, { 
          opacity: resetNoticeAnim,
          transform: [{ translateY: resetNoticeAnim.interpolate({
            inputRange: [0, 1],
            outputRange: [-100, 0]
          })}]
        }]}>
          <BlurView intensity={80} tint="light" style={styles.resetNoticeBlur}>
            <CheckCircle2 size={24} color="#2E7D32" />
            <Text style={styles.resetNoticeText}>App data reset successfully!</Text>
          </BlurView>
        </Animated.View>
      )}

      <Animated.ScrollView style={[styles.container, { opacity: fadeAnim }]}>
        <Animated.View style={{ transform: [{ translateY: slideAnim }] }}>
          <Card style={styles.card}>
            <CardHeader style={styles.cardHeader}>
                <View style={styles.iconContainer}>
                    <Zap height={40} width={40} color="#4A90E2" />
                </View>
                <CardTitle style={styles.cardTitle}>Welcome to MOBILE STOCK MANAGER</CardTitle>
                <Text style={styles.presentedBy}>Powered by Mohammed Sohel Tajani</Text>
                <CardDescription style={styles.cardDescription}>
                    Your all-in-one inventory management solution.
                </CardDescription>
            </CardHeader>
            <CardContent style={styles.cardContent}>
                <View style={styles.featuresContainer}>
                    <View style={styles.feature}>
                        <View style={styles.featureIconContainerGreen}>
                            <Package height={20} width={20} color="#2E7D32" />
                        </View>
                        <View style={styles.featureTextContainer}>
                            <Text style={styles.featureTitle}>Track Everything</Text>
                            <Text style={styles.featureDescription}>Seamlessly track all your sales, purchases, and transfers in one place.</Text>
                        </View>
                    </View>
                    <View style={styles.feature}>
                        <View style={styles.featureIconContainerPurple}>
                            <TrendingUp height={20} width={20} color="#512DA8" />
                        </View>
                        <View style={styles.featureTextContainer}>
                            <Text style={styles.featureTitle}>Gain Insights</Text>
                            <Text style={styles.featureDescription}>Get a clear view of your business's financial health with detailed history and profit analysis.</Text>
                        </View>
                    </View>
                </View>

                <View style={styles.checkboxesContainer}>
                    {allCheckboxesTicked && (
                        <Animated.View pointerEvents="none" style={[styles.stampContainer, {
                            opacity: stampAnim.interpolate({
                              inputRange: [0, 1],
                              outputRange: [0, 0.8],
                            }),
                            transform: [
                                { scale: stampScale },
                                { rotate: stampRotation }
                            ]
                        }]}>
                            <View style={styles.stamp}>
                                <BlurView intensity={20} tint="light" style={StyleSheet.absoluteFill} />
                                <Text style={styles.stampTextTitle}>MOBILE STOCK</Text>
                                <Text style={styles.stampTextSubtitle}>OFFICIAL SEAL</Text>
                                <Text style={styles.stampTextStatus}>ACCEPTED</Text>
                            </View>
                        </Animated.View>
                    )}
                    <View style={styles.checkboxRow}>
                        <View style={styles.checkboxLabelContainer}>
                            <Checkbox id="terms" checked={isTermsAccepted} onValueChange={setIsTermsAccepted} disabled={allCheckboxesTicked} />
                            <Label htmlFor="terms" style={styles.checkboxLabel}>
                                TERMS AND CONDITIONS
                            </Label>
                        </View>
                        <Link href="/terms-and-conditions" asChild>
                          <TouchableOpacity>
                              <Text style={styles.viewText}>View</Text>
                          </TouchableOpacity>
                        </Link>
                    </View>
                    <View style={styles.checkboxRow}>
                       <View style={styles.checkboxLabelContainer}>
                            <Checkbox id="privacy" checked={isPrivacyAccepted} onValueChange={setIsPrivacyAccepted} disabled={allCheckboxesTicked} />
                            <Label htmlFor="privacy" style={styles.checkboxLabel}>
                                PRIVACY AND POLICY
                            </Label>
                        </View>
                        <Link href="/privacy-policy" asChild>
                             <TouchableOpacity>
                                <Text style={styles.viewText}>View</Text>
                            </TouchableOpacity>
                        </Link>
                    </View>
                    <View style={styles.checkboxRow}>
                       <View style={styles.checkboxLabelContainer}>
                            <Checkbox id="agreement" checked={isAgreementAccepted} onValueChange={setIsAgreementAccepted} disabled={allCheckboxesTicked} />
                            <Label htmlFor="agreement" style={styles.checkboxLabel}>
                                USER AGREEMENT
                            </Label>
                        </View>
                        <Link href="/user-agreement" asChild>
                             <TouchableOpacity>
                                <Text style={styles.viewText}>View</Text>
                            </TouchableOpacity>
                        </Link>
                    </View>
                    <View style={styles.checkboxRow}>
                       <View style={styles.checkboxLabelContainer}>
                            <Checkbox id="policy" checked={isPolicyAccepted} onValueChange={setIsPolicyAccepted} disabled={allCheckboxesTicked} />
                            <Label htmlFor="policy" style={styles.checkboxLabel}>
                                ACCEPTABLE USE POLICY
                            </Label>
                        </View>
                        <Link href="/acceptable-use-policy" asChild>
                             <TouchableOpacity>
                                <Text style={styles.viewText}>View</Text>
                            </TouchableOpacity>
                        </Link>
                    </View>
                    <View style={styles.checkboxRow}>
                       <View style={styles.checkboxLabelContainer}>
                            <Checkbox id="disclaimer" checked={isDisclaimerAccepted} onValueChange={setIsDisclaimerAccepted} disabled={allCheckboxesTicked} />
                            <Label htmlFor="disclaimer" style={styles.checkboxLabel}>
                                DISCLAIMER
                            </Label>
                        </View>
                        <Link href="/disclaimer" asChild>
                             <TouchableOpacity>
                                <Text style={styles.viewText}>View</Text>
                            </TouchableOpacity>
                        </Link>
                    </View>
                    <View style={styles.checkboxRow}>
                       <View style={styles.checkboxLabelContainer}>
                            <Checkbox id="confirmAll" checked={isAllConfirmed} onValueChange={setIsAllConfirmed} disabled={allCheckboxesTicked} />
                            <Label htmlFor="confirmAll" style={styles.checkboxLabel}>
                                I CONFIRM AND AGREE TO ALL
                            </Label>
                        </View>
                    </View>
                </View>

                <View style={styles.nameInputContainer}>
                    <View style={styles.inputWrapper}>
                        <Text style={styles.inputLabel}>Enter Your Full Name</Text>
                        <TextInput
                            style={[
                                styles.input,
                                focusedField === 'userName' && styles.inputFocused,
                                !allCheckboxesTicked && styles.inputDisabled,
                                Platform.OS === 'web' && { outline: 'none' } as any
                            ]}
                            placeholder="e.g. Mohammed"
                            value={userName}
                            onChangeText={setUserName}
                            onFocus={() => setFocusedField('userName')}
                            onBlur={() => setFocusedField(null)}
                            placeholderTextColor={allCheckboxesTicked ? "#2563EB" : "#94A3B8"}
                            editable={allCheckboxesTicked}
                        />
                    </View>
                    <View style={styles.inputWrapper}>
                        <Text style={styles.inputLabel}>Enter Your Shop Name</Text>
                        <TextInput
                            style={[
                                styles.input,
                                focusedField === 'shopName' && styles.inputFocused,
                                !allCheckboxesTicked && styles.inputDisabled,
                                Platform.OS === 'web' && { outline: 'none' } as any
                            ]}
                            placeholder="e.g. MST"
                            value={shopName}
                            onChangeText={setShopName}
                            onFocus={() => setFocusedField('shopName')}
                            onBlur={() => setFocusedField(null)}
                            placeholderTextColor={allCheckboxesTicked ? "#2563EB" : "#94A3B8"}
                            editable={allCheckboxesTicked}
                        />
                    </View>
                    <TouchableOpacity
                        style={[styles.button, !canContinue && styles.buttonDisabled]}
                        onPress={handleContinue}
                        disabled={!canContinue || isLoading}
                    >
                        {isLoading ? (
                            <ActivityIndicator color="#FFFFFF" />
                        ) : (
                            <Text style={styles.buttonText}>CONTINUE</Text>
                        )}
                    </TouchableOpacity>
                </View>
            </CardContent>
          </Card>
        </Animated.View>
      </Animated.ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradientContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  card: {
    margin: 20,
    marginTop: Platform.OS === 'android' ? 60 : 40,
    borderRadius: 30,
    borderWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 10,
    backgroundColor: '#FFFFFF',
    overflow: 'hidden',
  },
  cardHeader: {
    alignItems: 'center',
    paddingTop: 30,
    paddingBottom: 20,
  },
  iconContainer: {
    backgroundColor: '#EEF2FF',
    padding: 20,
    borderRadius: 25,
    marginBottom: 15,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '900',
    textAlign: 'center',
    color: '#1E293B',
    lineHeight: 28,
  },
  presentedBy: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 5,
    fontWeight: '700',
    letterSpacing: 1,
  },
  cardDescription: {
    textAlign: 'center',
    marginTop: 10,
    fontSize: 14,
    color: '#64748B',
    paddingHorizontal: 20,
  },
  cardContent: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  featuresContainer: {
    gap: 20,
    marginBottom: 30,
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  featureIconContainerGreen: {
    backgroundColor: '#DCFCE7',
    padding: 10,
    borderRadius: 12,
  },
  featureIconContainerPurple: {
    backgroundColor: '#F3E8FF',
    padding: 10,
    borderRadius: 12,
  },
  featureTextContainer: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1E293B',
  },
  featureDescription: {
    fontSize: 13,
    color: '#64748B',
    lineHeight: 18,
  },
  checkboxesContainer: {
    backgroundColor: '#F8FAFC',
    padding: 15,
    borderRadius: 20,
    gap: 12,
    marginBottom: 25,
    position: 'relative',
    overflow: 'visible',
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  checkboxLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  checkboxLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#475569',
  },
  viewText: {
    fontSize: 12,
    color: '#4A90E2',
    fontWeight: '700',
  },
  nameInputContainer: {
    gap: 15,
    marginBottom: 25,
  },
  inputWrapper: {
    gap: 8,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '700',
    color: '#475569',
    marginLeft: 4,
  },
  input: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    borderRadius: 12,
    padding: 12,
    fontSize: 15,
    color: '#2563EB',
    fontWeight: '600',
  },
  inputDisabled: {
    backgroundColor: '#F1F5F9',
    borderColor: '#E2E8F0',
    color: '#94A3B8',
  },
  inputFocused: {
    borderColor: '#1565C0',
    backgroundColor: '#FFFFFF',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 12,
    elevation: 8,
  },
  button: {
    backgroundColor: '#4A90E2',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#4A90E2',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  buttonDisabled: {
    backgroundColor: '#CBD5E1',
    shadowOpacity: 0,
    elevation: 0,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  stampContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  stamp: {
    backgroundColor: 'transparent',
    paddingHorizontal: 30,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 4,
    borderColor: 'rgba(0, 0, 0, 0.4)',
    alignItems: 'center',
    overflow: 'hidden',
  },
  stampTextTitle: {
    color: '#111827',
    fontWeight: '900',
    fontSize: 16,
    textAlign: 'center',
  },
  stampTextSubtitle: {
    color: '#111827',
    fontWeight: '900',
    fontSize: 12,
    textAlign: 'center',
    marginVertical: 2,
  },
  stampTextStatus: {
    color: '#111827',
    fontWeight: '900',
    fontSize: 18,
    textAlign: 'center',
  },
  resetNotice: {
    position: 'absolute',
    top: 50,
    left: 20,
    right: 20,
    zIndex: 100,
    alignItems: 'center',
  },
  resetNoticeBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 30,
    gap: 10,
    borderWidth: 1,
    borderColor: '#DCFCE7',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  resetNoticeText: {
    color: '#1E293B',
    fontWeight: '700',
    fontSize: 14,
  }
});
