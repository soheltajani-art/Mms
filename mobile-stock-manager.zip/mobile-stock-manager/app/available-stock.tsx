
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, FlatList, SafeAreaView } from 'react-native';
import { ChevronLeft, Search, Box, X } from 'lucide-react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { getAvailableStock, StockItem } from './data/storage';
import { PhotoPreview } from '../components/PhotoPreview';
import ProductCard from '../components/ProductCard';

const AvailableStockPage = () => {
  const router = useRouter();
  const [allProducts, setAllProducts] = useState<StockItem[]>([]);
  const [products, setProducts] = useState<StockItem[]>([]);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [allDataLoaded, setAllDataLoaded] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState('');
  const PRODUCTS_PER_PAGE = 20;

  useFocusEffect(
    useCallback(() => {
      const fetchStock = async () => {
        const stock = await getAvailableStock();
        setAllProducts(stock);
        setPage(1);
        setAllDataLoaded(false);
        setProducts([]);
        setSearchQuery('');
      };
      fetchStock();
    }, [])
  );

  const filteredProducts = allProducts.filter(product => {
    if (!searchQuery.trim()) return true;
    
    const query = searchQuery.trim().toLowerCase();
    const modelMatch = product.model?.toLowerCase().includes(query) ?? false;
    const imeiMatch = product.primaryImei?.includes(query) ?? false;
    const nameMatch = product.name?.toLowerCase().includes(query) ?? false;
    const modelNoMatch = product.modelNo?.toLowerCase().includes(query) ?? false;
    
    return modelMatch || imeiMatch || nameMatch || modelNoMatch;
  });

  useEffect(() => {
    if (allDataLoaded) return;
    const newProducts = filteredProducts.slice((page - 1) * PRODUCTS_PER_PAGE, page * PRODUCTS_PER_PAGE);
    if (newProducts.length > 0) {
      if (page === 1) {
        setProducts(newProducts);
      } else {
        setProducts(prevProducts => [...prevProducts, ...newProducts]);
      }
    } else {
      if (page === 1) {
        setProducts([]);
      }
      setAllDataLoaded(true);
    }
  }, [page, filteredProducts, allDataLoaded]);

  useEffect(() => {
    setPage(1);
    setAllDataLoaded(false);
  }, [searchQuery]);

  const handleLoadMore = () => {
    if (!allDataLoaded) {
      setPage(prevPage => prevPage + 1);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setFocusedField(null);
  };

  const renderFooter = () => {
    if (allDataLoaded && products.length > 0) {
      return <Text style={styles.endOfListText}>End of product list</Text>;
    }
    return null;
  };

  const handleViewPhoto = (photoUri: string) => {
    setPreviewPhotoUri(photoUri);
    setShowPhotoPreview(true);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Available Stock</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={[styles.searchContainer, focusedField === 'search' && styles.searchContainerFocused]}>
        <Search size={20} color={focusedField === 'search' ? '#1565C0' : '#909090'} style={styles.searchIcon} />
        <TextInput
          placeholder="Search by name or IMEI..."
          placeholderTextColor="#909090"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => setFocusedField('search')}
          onBlur={() => setFocusedField(null)}
        />
        {searchQuery ? (
          <TouchableOpacity onPress={handleClearSearch} style={styles.clearButton}>
            <X size={18} color="#909090" />
          </TouchableOpacity>
        ) : null}
      </View>

      <View style={styles.infoRow}>
        <View style={styles.itemsAvailableContainer}>
          <Text style={styles.itemsAvailable}>{filteredProducts.length} ITEMS AVAILABLE</Text>
        </View>
        {searchQuery.length > 0 && (
          <Text style={styles.searchHint}>Search active</Text>
        )}
      </View>

      <View style={styles.contentWrapper}>
        <FlatList
            data={products}
            renderItem={({ item }) => (
              <ProductCard item={item} onViewPhoto={handleViewPhoto} isAvailable={true} />
            )}
            keyExtractor={item => item.id}
            onEndReached={handleLoadMore}
            onEndReachedThreshold={0.5}
            ListFooterComponent={renderFooter}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24, flexGrow: 1 }}
            ListEmptyComponent={(
              <View style={styles.emptyStateContainer}>
                <View style={styles.iconBackground}>
                  <Box size={48} color="#1565C0" />
                </View>
                <Text style={styles.emptyStateTitle}>
                  {searchQuery.length > 0 ? 'NO MATCHES FOUND' : 'STOCK IS EMPTY'}
                </Text>
                <Text style={styles.emptyStateSubtitle}>
                  {searchQuery.length > 0
                    ? "We couldn\'t find any products matching your search."
                    : 'Your inventory is currently empty. Add new items to your warehouse to see them here.'}
                </Text>
              </View>
            )}
          />
      </View>

      {showPhotoPreview && (
          <PhotoPreview
            photoUri={previewPhotoUri}
            isVisible={showPhotoPreview}
            onClose={() => setShowPhotoPreview(false)}
            allowRetake={false}
          />
        )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    marginHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    overflow: 'hidden',
    marginHorizontal: 12,
    marginBottom: 12,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    marginHorizontal: 12,
    paddingHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  searchContainerFocused: {
    borderColor: '#1565C0',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
    marginRight: 12,
  },
  clearButton: {
    padding: 8,
    marginLeft: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    fontSize: 14,
    color: '#000',

  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 12,
    marginTop: 10,
    marginBottom: 10,
  },
  itemsAvailableContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 2,
    elevation: 1,
  },
  itemsAvailable: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#0D47A1',
    letterSpacing: 0.3,
  },
  searchHint: {
    fontSize: 9,
    color: '#666',
    fontStyle: 'italic',
  },
  emptyStateContainer: {
    flex: 1,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBackground: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1.5,
    borderColor: '#1565C0',
  },
  emptyStateTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0D47A1',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtitle: {
    fontSize: 14,
    color: '#1565C0',
    textAlign: 'center',
    lineHeight: 20,
  },
  endOfListText: {
    textAlign: 'center',
    padding: 12,
    fontSize: 12,
    color: '#888',
  },
});

export default AvailableStockPage;
