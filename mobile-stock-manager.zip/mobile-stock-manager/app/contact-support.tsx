import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, Linking, ScrollView } from 'react-native';
import { ChevronLeft, Mail, ChevronRight } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { BlurView } from 'expo-blur';

const ContactSupportPage = () => {
  const router = useRouter();

  const handleEmailPress = (email: string, subject: string) => {
    const encodedSubject = encodeURIComponent(subject);
    Linking.openURL(`mailto:${email}?subject=${encodedSubject}`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Contact Support</Text>
        <View style={{ width: 24 }} />
      </View>
      <View style={styles.contentWrapper}>
        <ScrollView contentContainerStyle={styles.contentContainer}>
          <ContactCard
            icon={<Mail size={24} color="#C62828" />}
            title="Report an Issue"
            email="ms8112009@gmail.com"
            onPress={() => handleEmailPress('ms8112009@gmail.com', 'Issue Report')}
            theme="red"
          />
          <ContactCard
            icon={<Mail size={24} color="#1565C0" />}
            title="Suggest an Improvement"
            email="soheltajani@gmail.com"
            onPress={() => handleEmailPress('soheltajani@gmail.com', 'Improvement Suggestion')}
            theme="blue"
          />
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

const ContactCard = ({ icon, title, email, onPress, theme }: any) => {
  let wrapperStyle, cardStyle, titleColor, descriptionColor, chevronColor, iconBgColor;

  switch (theme) {
    case 'red':
      wrapperStyle = styles.redSpecialCardWrapper;
      cardStyle = styles.redSpecialCard;
      titleColor = '#C62828';
      descriptionColor = '#D32F2F';
      chevronColor = '#C62828';
      iconBgColor = 'rgba(255, 235, 238, 0.6)';
      break;
    default: // blue
      wrapperStyle = styles.blueSpecialCardWrapper;
      cardStyle = styles.blueSpecialCard;
      titleColor = '#0D47A1';
      descriptionColor = '#1A237E';
      chevronColor = '#0D47A1';
      iconBgColor = 'rgba(227, 242, 253, 0.6)';
      break;
  }

  return (
    <TouchableOpacity onPress={onPress} style={[styles.specialCardWrapper, wrapperStyle]}>
      <BlurView intensity={95} tint="light" style={[styles.specialCard, cardStyle]}>
        <View style={[styles.iconContainer, { backgroundColor: iconBgColor }]}>
          {icon}
        </View>
        <View style={styles.textContainer}>
          <Text style={[styles.cardTitle, { color: titleColor, fontWeight: 'bold' }]}>{title}</Text>
          <Text style={[styles.cardDescription, { color: descriptionColor, fontWeight: '500' }]}>{email}</Text>
        </View>
        <ChevronRight size={20} color={chevronColor} />
      </BlurView>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginHorizontal: 16,
    marginTop: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 30,
    marginTop: 16,
    overflow: 'hidden',
    marginHorizontal: 16,
    marginBottom: 16,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 24,
  },
  specialCardWrapper: {
    borderRadius: 24,
    marginBottom: 24,
  },
  blueSpecialCardWrapper: {
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  redSpecialCardWrapper: {
    shadowColor: '#C62828',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  specialCard: {
    borderRadius: 24,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  blueSpecialCard: {
    backgroundColor: 'rgba(227, 242, 253, 0.9)',
  },
  redSpecialCard: {
    backgroundColor: 'rgba(255, 235, 238, 0.9)',
  },
  iconContainer: {
    padding: 12,
    borderRadius: 999,
    marginRight: 16,
  },
  textContainer: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  cardDescription: {
    fontSize: 14,
    marginTop: 4,
  },
});

export default ContactSupportPage;