
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, FlatList, SafeAreaView } from 'react-native';
import { ChevronLeft, Search, Box, X } from 'lucide-react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { getHistory, HistoryItem } from './data/storage';
import ProductCard from '../components/ProductCard';
import { PhotoPreview } from '../components/PhotoPreview';

const LifetimeStatsPage = () => {
  const router = useRouter();
  const [allHistory, setAllHistory] = useState<HistoryItem[]>([]);
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [allDataLoaded, setAllDataLoaded] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState('');
  const ITEMS_PER_PAGE = 20;

  useFocusEffect(
    useCallback(() => {
      const fetchHistory = async () => {
        const history = await getHistory();
        setAllHistory(history);
        setPage(1);
        setAllDataLoaded(false);
        setHistoryItems([]);
        setSearchQuery(''); // Reset search on focus
      };
      fetchHistory();
    }, [])
  );

  const filteredHistory = allHistory.filter(item => {
    if (!searchQuery.trim()) return true;
    
    const query = searchQuery.trim().toLowerCase();
    const modelMatch = item.model?.toLowerCase().includes(query) ?? false;
    const imeiMatch = item.primaryImei?.includes(query) ?? false;
    
    return modelMatch || imeiMatch;
  });

  useEffect(() => {
    if (allDataLoaded) return;
    const newItems = filteredHistory.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);
    if (newItems.length > 0) {
      if (page === 1) {
        setHistoryItems(newItems);
      } else {
        setHistoryItems(prevItems => [...prevItems, ...newItems]);
      }
    } else {
      if (page === 1) {
        setHistoryItems([]);
      }
      setAllDataLoaded(true);
    }
  }, [page, filteredHistory, allDataLoaded]);


  useEffect(() => {
    setPage(1);
    setAllDataLoaded(false);
  }, [searchQuery]);

  const handleLoadMore = () => {
    if (!allDataLoaded) {
      setPage(prevPage => prevPage + 1);
    }
  };
  
  const handleClearSearch = () => {
    setSearchQuery('');
    setFocusedField(null);
  };

  const renderFooter = () => {
    if (allDataLoaded && historyItems.length > 0) {
      return <Text style={styles.endOfListText}>End of history</Text>;
    }
    return null;
  };

  const handleViewPhoto = (photoUri: string) => {
    setPreviewPhotoUri(photoUri);
    setShowPhotoPreview(true);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Lifetime History</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={[styles.searchContainer, focusedField === 'search' && styles.searchContainerFocused]}>
        <Search size={20} color={focusedField === 'search' ? '#1E8449' : '#909090'} style={styles.searchIcon} />
        <TextInput
          placeholder="Search by model or IMEI..."
          placeholderTextColor="#909090"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => setFocusedField('search')}
          onBlur={() => setFocusedField(null)}
        />
        {searchQuery ? (
          <TouchableOpacity onPress={handleClearSearch} style={styles.clearButton}>
            <X size={18} color="#909090" />
          </TouchableOpacity>
        ) : null}
      </View>

      <View style={styles.infoRow}>
          <View style={styles.itemsStatsContainer}>
              <Text style={styles.itemsStatsText}>{filteredHistory.length} TRANSACTIONS IN HISTORY</Text>
          </View>
          {searchQuery.length > 0 && (
            <Text style={styles.searchHint}>Search active</Text>
          )}
      </View>

      <View style={styles.contentWrapper}>
        <FlatList
            data={historyItems}
            renderItem={({ item }) => <ProductCard item={item} onViewPhoto={handleViewPhoto} isAvailable={item.type !== 'SOLD'} />}
            keyExtractor={(item, index) => `${item.id}-${index}`}
            onEndReached={handleLoadMore}
            onEndReachedThreshold={0.5}
            ListFooterComponent={renderFooter}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24, flexGrow: 1 }}
            ListEmptyComponent={(
              <View style={styles.emptyStateContainer}>
                <View style={styles.iconBackground}>
                  <Box size={48} color="#1E8449" />
                </View>
                <Text style={styles.emptyStateTitle}>
                  {searchQuery.length > 0 ? 'NO MATCHES FOUND' : 'NO LIFETIME DATA'}
                </Text>
                <Text style={styles.emptyStateSubtitle}>
                  {searchQuery.length > 0
                    ? "We couldn't find any transactions matching your search."
                    : 'Your lifetime business history will appear here once you start buying or selling.'
                  }
                </Text>
              </View>
            )}
          />
      </View>

      {showPhotoPreview && (
        <PhotoPreview
          photoUri={previewPhotoUri}
          isVisible={showPhotoPreview}
          onClose={() => setShowPhotoPreview(false)}
          allowRetake={false}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E8F5E9', // Light green background
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginHorizontal: 16,
    marginTop: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 30,
    overflow: 'hidden',
    marginHorizontal: 16,
    marginBottom: 16,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginHorizontal: 16,
    paddingHorizontal: 16,
    marginTop: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  searchContainerFocused: {
    borderColor: '#1E8449',
    borderWidth: 2.5,
    shadowColor: '#1E8449',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
    marginRight: 12,
  },
  clearButton: {
    padding: 8,
    marginLeft: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: '#000',

  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  itemsStatsContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  itemsStatsText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#145A32', // Dark Green
    letterSpacing: 0.5,
  },
  searchHint: {
    fontSize: 10,
    color: '#666',
    fontStyle: 'italic',
  },
  emptyStateContainer: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBackground: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#C8E6C9', // Darker green for icon background
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 32,
    borderWidth: 2,
    borderColor: '#1E8449',
  },
  emptyStateTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#145A32', // Dark Green
    textAlign: 'center',
    marginBottom: 12,
  },
  emptyStateSubtitle: {
    fontSize: 16,
    color: '#1E8449', // Medium Green
    textAlign: 'center',
    lineHeight: 22,
  },
  endOfListText: {
    textAlign: 'center',
    padding: 16,
    fontSize: 14,
    color: '#888',
  },
});

export default LifetimeStatsPage;
