import React, { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Alert, ActivityIndicator, Platform, KeyboardAvoidingView, Image } from 'react-native';
import { Stack, useRouter, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { ChevronLeft, ScanLine, AlertCircle, CheckCircle2, IndianRupee, Smartphone, Calendar, Hash, User, Phone } from 'lucide-react-native';
import { BarcodeScanner } from '../../components/BarcodeScanner';
import { sellStockItem, getAvailableStockByImei, StockItem } from '../data/storage';
import { LinearGradient } from 'expo-linear-gradient';

const InfoRow = ({ icon: Icon, label, value, color = '#666' }: any) => (
  <View style={styles.infoRow}>
    <View style={styles.infoLabelContainer}>
      <Icon size={16} color={color} style={styles.infoIcon} />
      <Text style={styles.infoLabel}>{label}</Text>
    </View>
    <Text style={styles.infoValue}>{value}</Text>
  </View>
);

export default function SellStock() {
  const router = useRouter();
  const params = useLocalSearchParams();
  
  const [searchImei, setSearchImei] = useState(params.imei || '');
  const [sellingPrice, setSellingPrice] = useState('');
  const [stockItem, setStockItem] = useState<StockItem | null>(null);

  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      if (params.reset === 'true') {
        resetForm();
      }
    }, [params.reset])
  );

  const resetForm = () => {
    setSearchImei('');
    setSellingPrice('');
    setStockItem(null);
    setErrors({});
    setSearchError(null);
    setIsLoading(false);
  };

  useEffect(() => {
    if (params.imei) {
      handleSearch(params.imei as string);
    }
  }, [params.imei]);

  const handleSearch = async (imei: string) => {
    if (!imei || imei.length < 15) {
      setSearchError('Please enter a valid 15-digit IMEI');
      setStockItem(null);
      return;
    }

    setIsLoading(true);
    setSearchError(null);
    try {
      const result = await getAvailableStockByImei(imei);
      if (result.item) {
        setStockItem(result.item);
      } else {
        setSearchError(result.error || 'Product not found in available stock');
        setStockItem(null);
      }
    } catch (error) {
      console.error('Search failed:', error);
      setSearchError('An error occurred during search');
    } finally {
      setIsLoading(false);
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!stockItem) newErrors.search = 'Please find a product first';
    if (!sellingPrice || isNaN(parseFloat(sellingPrice))) newErrors.sellingPrice = 'Valid selling price is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm() || !stockItem) return;

    setIsLoading(true);
    try {
      const purchasePrice = stockItem.purchaseCost || stockItem.buyingPrice || 0;
      await sellStockItem(stockItem.id, {
        sellingPrice: parseFloat(sellingPrice),
        customerName: '',
        customerContact: '',
        saleDate: new Date().toISOString(),
        customerPhoto: '',
      });
      
      router.push({
        pathname: '/sell-success',
        params: {
          model: stockItem.model || stockItem.modelNo,
          imei: stockItem.primaryImei,
          purchasePrice: purchasePrice.toString(),
          sellingPrice: sellingPrice,
          profit: (parseFloat(sellingPrice) - purchasePrice).toString(),
          sellDate: new Date().toISOString(),
        },
      });

    } catch (error) {
      console.error('Sell failed:', error);
      Alert.alert('Error', 'An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBarcodeScanComplete = (imei1: string) => {
    setSearchImei(imei1);
    setShowBarcodeScanner(false);
    handleSearch(imei1);
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        <Stack.Screen options={{ headerShown: false }} />
        
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ChevronLeft size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Sell Product</Text>
          <View style={{ width: 24 }} />
        </View>

        <View style={styles.mainContent}>
          {/* Search Section */}
          <View style={styles.sectionCard}>
            <Text style={styles.sectionLabel}>FIND PRODUCT</Text>
            <View style={[styles.searchWrapper, focusedField === 'search' && styles.inputFocused, searchError && styles.inputError]}>
              <Hash size={20} color="#666" style={styles.inputIcon} />
              <TextInput
                style={[styles.searchInput, Platform.OS === 'web' && { outline: 'none' } as any]}
                placeholder="Enter 15-digit IMEI"
                placeholderTextColor="#999"
                value={searchImei}
                onChangeText={(text) => {
                  setSearchImei(text);
                  if (text.length === 15) handleSearch(text);
                }}
                keyboardType="numeric"
                maxLength={15}
                onFocus={() => setFocusedField('search')}
                onBlur={() => setFocusedField(null)}
              />
            </View>
            
            <TouchableOpacity style={styles.scanBtn} onPress={() => setShowBarcodeScanner(true)}>
              <ScanLine size={20} color="#D32F2F" />
              <Text style={styles.scanBtnText}>Scan Barcode</Text>
            </TouchableOpacity>

            {searchError && (
              <View style={styles.errorBox}>
                <AlertCircle size={14} color="#D32F2F" />
                <Text style={styles.errorText}>{searchError}</Text>
              </View>
            )}
          </View>

          {isLoading && !stockItem && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#D32F2F" />
              <Text style={styles.loadingText}>Searching Stock...</Text>
            </View>
          )}

          {/* Product Details Section */}
          {stockItem && (
            <View style={styles.detailsCard}>
              <View style={styles.successBadge}>
                <CheckCircle2 size={16} color="#2E7D32" />
                <Text style={styles.successBadgeText}>Product Found</Text>
              </View>

              <Text style={styles.modelTitle}>{stockItem.model || stockItem.modelNo}</Text>
              
              <View style={styles.infoGrid}>
                <InfoRow icon={Smartphone} label="IMEI" value={stockItem.primaryImei} color="#D32F2F" />
                <InfoRow icon={IndianRupee} label="Purchase Price" value={`₹${stockItem.purchaseCost || stockItem.buyingPrice}`} color="#2E7D32" />
                <InfoRow icon={Calendar} label="Purchase Date" value={new Date(stockItem.purchaseDate).toLocaleDateString()} color="#1976D2" />
              </View>

              {stockItem.compulsoryPhoto && (
                <View style={styles.photoPreviewContainer}>
                  <Text style={styles.photoLabel}>Photo Documentation</Text>
                  <Image source={{ uri: stockItem.compulsoryPhoto }} style={styles.productImage} />
                </View>
              )}

              <View style={styles.divider} />

              <Text style={styles.sectionLabel}>SALE INFORMATION</Text>
              
              <View style={styles.priceInputWrapper}>
                <Text style={styles.priceLabel}>SELLING PRICE</Text>
                <View style={[styles.priceInputBox, errors.sellingPrice && styles.inputError, focusedField === 'sellingPrice' && styles.inputFocused]}>
                  <IndianRupee size={20} color="#666" />
                  <TextInput
                    style={[styles.priceInput, Platform.OS === 'web' && { outline: 'none' } as any]}
                    placeholder="0.00"
                    placeholderTextColor="#999"
                    keyboardType="numeric"
                    value={sellingPrice}
                    onChangeText={setSellingPrice}
                    onFocus={() => setFocusedField('sellingPrice')}
                    onBlur={() => setFocusedField(null)}
                  />
                </View>
                {errors.sellingPrice && <Text style={styles.errorText}>{errors.sellingPrice}</Text>}
              </View>

              <TouchableOpacity 
                style={[styles.submitBtn, isLoading && styles.submitBtnDisabled]} 
                onPress={handleSubmit}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <Text style={styles.submitBtnText}>Complete Sale</Text>
                    <CheckCircle2 size={20} color="#fff" />
                  </>
                )}
              </TouchableOpacity>
            </View>
          )}
        </View>

        <BarcodeScanner 
          isVisible={showBarcodeScanner} 
          onScan={handleBarcodeScanComplete} 
          onClose={() => setShowBarcodeScanner(false)} 
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFEBEE' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#000' },
  mainContent: { paddingHorizontal: 20 },
  sectionCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  sectionLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#999',
    letterSpacing: 1,
    marginBottom: 15,
  },
  searchWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FB',
    borderRadius: 12,
    paddingHorizontal: 15,
    borderWidth: 1.5,
    borderColor: '#E1E5EB',
    marginBottom: 15,
  },
  inputIcon: { marginRight: 10 },
  searchInput: { flex: 1, paddingVertical: 12, fontSize: 16, color: '#333', fontWeight: '500' },
  inputFocused: { 
    borderColor: '#D32F2F', 
    backgroundColor: '#fff',
    shadowColor: '#D32F2F',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6,
    borderWidth: 2,
  },
  inputError: { borderColor: '#D32F2F', backgroundColor: '#FFF5F5' },
  scanBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFEBEE',
    borderRadius: 12,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#FFCDD2',
    gap: 8,
  },
  scanBtnText: { color: '#D32F2F', fontWeight: '700', fontSize: 15 },
  errorBox: { flexDirection: 'row', alignItems: 'center', marginTop: 10, gap: 6 },
  errorText: { color: '#D32F2F', fontSize: 13, fontWeight: '500' },
  loadingContainer: { alignItems: 'center', marginTop: 40 },
  loadingText: { marginTop: 10, color: '#666', fontWeight: '600' },
  detailsCard: {
    backgroundColor: '#fff',
    borderRadius: 24,
    padding: 20,
    marginTop: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 8,
  },
  successBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    width: '100%',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#C8E6C9',
  },
  successBadgeText: { color: '#2E7D32', fontSize: 14, fontWeight: '700' },
  modelTitle: { fontSize: 24, fontWeight: '800', color: '#1A1A1A', marginBottom: 20 },
  infoGrid: { gap: 12 },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#F8F9FB',
    padding: 12,
    borderRadius: 12,
  },
  infoLabelContainer: { flexDirection: 'row', alignItems: 'center' },
  infoIcon: { marginRight: 8 },
  infoLabel: { fontSize: 13, color: '#666', fontWeight: '600' },
  infoValue: { fontSize: 14, color: '#1A1A1A', fontWeight: '700' },
  photoPreviewContainer: { marginTop: 20 },
  photoLabel: { fontSize: 12, fontWeight: '700', color: '#999', marginBottom: 10 },
  productImage: { width: '100%', height: 150, borderRadius: 15, resizeMode: 'cover' },
  divider: { height: 1, backgroundColor: '#EEE', marginVertical: 25 },
  priceInputWrapper: { marginBottom: 25 },
  priceLabel: { fontSize: 12, fontWeight: '700', color: '#666', marginBottom: 10 },
  priceInputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FB',
    borderRadius: 15,
    paddingHorizontal: 15,
    borderWidth: 1.5,
    borderColor: '#E1E5EB',
  },
  priceInput: { flex: 1, paddingVertical: 15, fontSize: 20, fontWeight: '700', color: '#1A1A1A', marginLeft: 5 },
  submitBtn: {
    backgroundColor: '#D32F2F',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    borderRadius: 15,
    gap: 10,
    shadowColor: '#D32F2F',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  submitBtnDisabled: { backgroundColor: '#EF9A9A' },
  submitBtnText: { color: '#fff', fontSize: 18, fontWeight: '800' },
});
