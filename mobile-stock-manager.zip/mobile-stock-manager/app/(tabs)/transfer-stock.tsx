
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Feather, ChevronLeft } from 'lucide-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';

export default function TransferStock() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Transfer Stock</Text>
        <View style={{ width: 24 }} />
      </View>
      <ScrollView style={styles.content}>
        <View style={styles.constructionBox}>
          <Feather name="tool" size={48} color="#0D47A1" />
          <Text style={styles.title}>Page Under Construction</Text>
          <Text style={styles.message}>This feature is currently under development. Please check back later!</Text>
        </View>
        <Text style={styles.guideTitle}>Transfer Function</Text>
        <Text style={styles.guideText}>
          Stock Transfer is the process of moving a product from one shop, branch, or location to another. This process helps maintain accurate inventory records and ensures that stock movements are tracked correctly.
        </Text>
        <Text style={styles.guideText}>
          There are two main types of transfers:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Transfer In</Text>
          <Text style={styles.listItem}>• Transfer Out</Text>
        </View>
        <Text style={styles.guideText}>
          Transfer management also includes features for payment tracking, duplicate prevention, sell restrictions on unpaid transfers, reverse transfers, and detailed transfer records.
        </Text>

        <Text style={styles.guideHeading}>1. Transfer In</Text>
        <Text style={styles.guideText}>
          A **Transfer In** is used when your shop receives a product from another shop.
        </Text>
        <Text style={styles.guideSubheading}>Example:</Text>
        <Text style={styles.guideText}>
          Shop B receives stock from Shop A. In this scenario, Shop B will create a **Transfer In** because the product is being added to its inventory.
        </Text>
        <Text style={styles.guideText}>
          The result is that the product is added to the inventory, and the stock count increases.
        </Text>

        <Text style={styles.guideSubheading}>Transfer In Payment Logic</Text>
        <Text style={styles.guideText}>
          A Transfer In can be marked as either **Paid** or **Unpaid**.
        </Text>
        <Text style={styles.guideSubheading}>Paid Transfer In</Text>
        <Text style={styles.guideText}>
          When a **Transfer In** is marked as **Paid**:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• The product is added to the inventory immediately.</Text>
          <Text style={styles.listItem}>• The transfer is considered financially settled.</Text>
          <Text style={styles.listItem}>• The transfer is marked as completed.</Text>
          <Text style={styles.listItem}>• No further financial action is needed.</Text>
        </View>

        <Text style={styles.guideSubheading}>Unpaid Transfer In</Text>
        <Text style={styles.guideText}>
          When a **Transfer In** is marked as **Unpaid**:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• The product is added to the inventory immediately because it has physically arrived at the shop.</Text>
          <Text style={styles.listItem}>• However, the payment is still pending, and the financial settlement must be completed later in the **Transfer Records**.</Text>
          <Text style={styles.listItem}>• Even though the product is counted in the inventory, it cannot be transferred out again until its unpaid status is settled.</Text>
          <Text style={styles.listItem}>• This rule prevents risky stock movements and financial confusion.</Text>
        </View>

        <Text style={styles.guideHeading}>2. Transfer Out</Text>
        <Text style={styles.guideText}>
          A **Transfer Out** is used when your shop sends a product to another shop.
        </Text>
        <Text style={styles.guideSubheading}>Example:</Text>
        <Text style={styles.guideText}>
          Shop A sends stock to Shop B. In this case, Shop A will create a **Transfer Out** because the product is leaving its inventory.
        </Text>

        <Text style={styles.guideSubheading}>Transfer Out Payment Logic</Text>
        <Text style={styles.guideText}>
          A Transfer Out can also be marked as **Paid** or **Unpaid**.
        </Text>
        <Text style={styles.guideSubheading}>Paid Transfer Out</Text>
        <Text style={styles.guideText}>
          When a **Transfer Out** is marked as **Paid**:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• The product is removed from the inventory immediately.</Text>
          <Text style={styles.listItem}>• This happens because the item has been sent, the payment is financially settled, and the transfer is completed.</Text>
          <Text style={styles.listItem}>• This is considered the final state of the transfer.</Text>
        </View>

        <Text style={styles.guideSubheading}>Unpaid Transfer Out</Text>
        <Text style={styles.guideText}>
          When a **Transfer Out** is marked as **Unpaid**:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• The product is not removed from the inventory immediately. This is because the payment is still pending, and the transfer is not yet financially complete.</Text>
          <Text style={styles.listItem}>• The product remains visible in the inventory until the payment is completed.</Text>
          <Text style={styles.listItem}>• Later, when the transfer is marked as **Paid** in the **Transfer Records**, the stock is deducted from the inventory.</Text>
          <Text style={styles.listItem}>• This prevents stock loss from unpaid outgoing transfers.</Text>
        </View>

        <Text style={styles.guideHeading}>The Transfer Process</Text>
        <Text style={styles.guideText}>
          The entire transfer process involves several important steps.
        </Text>

        <Text style={styles.guideSubheading}>Step 1: Scan Barcode or Search for a Product</Text>
        <Text style={styles.guideText}>
          The transfer process begins with selecting the product. This can be done in two ways:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Scan the product's barcode</Text>
          <Text style={styles.listItem}>• Search for the product manually</Text>
        </View>
        <Text style={styles.guideText}>
          This helps the system identify the exact product for the transfer.
        </Text>

        <Text style={styles.guideSubheading}>Automatic Transfer Type Detection</Text>
        <Text style={styles.guideText}>
          After scanning or searching:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• If the product already exists in your inventory, the system prepares a **Transfer Out**.</Text>
          <Text style={styles.listItem}>• If the product does not exist in your inventory, the system prepares a **Transfer In**.</Text>
        </View>
        <Text style={styles.guideText}>
          This automatic detection reduces errors and improves workflow speed.
        </Text>

        <Text style={styles.guideSubheading}>Step 2: Validation Checks</Text>
        <Text style={styles.guideText}>
          Before a transfer is saved, the system performs several important validation checks to protect the accuracy of your inventory.
        </Text>

        <Text style={styles.guideSubheading}>Validation A: Unpaid Transfer In Restriction</Text>
        <Text style={styles.guideText}>
          If a product entered your shop through an **Unpaid Transfer In**, it cannot be transferred out again immediately. This action is blocked because the financial settlement is still pending. The transfer must be settled before the product can be moved again. This prevents repeated transfers of unpaid stock.
        </Text>

        <Text style={styles.guideSubheading}>Validation B: Duplicate Transfer Prevention</Text>
        <Text style={styles.guideText}>
          If a product is already part of an active transfer, the system will block another transfer for the same product. This avoids duplicate transfers and stock mismatches. Before a new transfer can be created, the previous one must be either completed or reversed. This ensures accurate inventory tracking.
        </Text>

        <Text style={styles.guideSubheading}>Step 3: Select the Transfer Type</Text>
        <Text style={styles.guideText}>
          The user selects the transfer type (**Transfer In** or **Transfer Out**). This tells the system whether the product is entering or leaving the inventory, and the system then applies the correct rules for updating the stock.
        </Text>

        <Text style={styles.guideSubheading}>Step 4: Specify the From and To Shops</Text>
        <Text style={styles.guideText}>
          Every transfer must include the **From Shop** and **To Shop** details to define the origin and destination of the product. The system automatically fills one of these fields based on your current shop and the selected transfer type. The user only needs to enter the other shop's details. This reduces errors and improves speed.
        </Text>

        <Text style={styles.guideSubheading}>Step 5: Select the Payment Status</Text>
        <Text style={styles.guideText}>
          The user must choose the payment status (**Paid** or **Unpaid**). This is a critical step because it controls when stock updates occur, whether the financial settlement is complete, and whether any restrictions will apply later. An incorrect payment status can cause inventory problems.
        </Text>

        <Text style={styles.guideSubheading}>Step 6: Save the Transfer</Text>
        <Text style={styles.guideText}>
          After all validation checks have passed, the transfer is saved. At this stage:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• The transfer record is created.</Text>
          <Text style={styles.listItem}>• The inventory is updated based on the transfer rules.</Text>
          <Text style={styles.listItem}>• The history is stored.</Text>
          <Text style={styles.listItem}>• The transfer becomes visible in the **Transfer Records**.</Text>
        </View>
        <Text style={styles.guideText}>
          This completes the main transfer process.
        </Text>

        <Text style={styles.guideHeading}>Transfer Records</Text>
        <Text style={styles.guideText}>
          The **Transfer Records** section is used to manage all past and active transfers. It is an essential control center for transfer management. From the **Transfer Records**, users can:
        </Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• View transfer history</Text>
          <Text style={styles.listItem}>• Check payment status</Text>
          <Text style={styles.listItem}>• Complete unpaid transfers</Text>
          <Text style={styles.listItem}>• Mark unpaid transfers as paid</Text>
          <Text style={styles.listItem}>• Reverse incorrect transfers</Text>
          <Text style={styles.listItem}>• Track stock movement</Text>
        </View>
        <Text style={styles.guideText}>
          This section helps maintain inventory accuracy over time.
        </Text>

        <Text style={styles.guideHeading}>Reverse Transfer</Text>
        <Text style={styles.guideText}>
          A **Reverse Transfer** should be used if a customer decides not to buy a product after it has been transferred from another shop, or if there is a payment issue. This will reverse the transfer and return the stock to the original shop. This should be done by the owner of Shop B in front of the owner of Shop A to prevent any confusion.
        </Text>
        <Text style={styles.guideText}>
          **Reverse Transfer** is used when a mistake is made during a transfer. Examples of mistakes include selecting the wrong shop, transferring the wrong product, or selecting the wrong payment status or transfer type. Instead of manually adjusting the stock, the correct procedure is to reverse the original transfer. A **Reverse Transfer** cancels the original transfer and restores the stock to its correct state. After reversing the transfer, a new, correct one can be created. This prevents stock mismatches and accounting issues.
        </Text>

        <Text style={styles.guideHeading}>Important Rules</Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• **Rule 1:** Products from an **Unpaid Transfer In** are counted in the inventory but cannot be transferred out until the payment is settled.</Text>
          <Text style={styles.listItem}>• **Rule 2:** Products from a **Paid Transfer In** are counted in the inventory, and the transfer is considered complete.</Text>
          <Text style={styles.listItem}>• **Rule 3:** A **Paid Transfer Out** immediately removes the stock from the inventory.</Text>
          <Text style={styles.listItem}>• **Rule 4:** An **Unpaid Transfer Out** does not remove the stock from the inventory until the payment is completed.</Text>
          <Text style={styles.listItem}>• **Rule 5:** A product that is already part of an active transfer cannot be transferred again.</Text>
          <Text style={styles.listItem}>• **Rule 6:** Always reverse incorrect transfers before creating a new one. This keeps the stock records accurate.</Text>
        </View>

        <Text style={styles.guideHeading}>Some Suggestion for transfer</Text>
        <View style={styles.list}>
          <Text style={styles.listItem}>• Always scan the barcode first to avoid mistakes in product selection.</Text>
          <Text style={styles.listItem}>• Always carefully verify the **From Shop** and **To Shop** details.</Text>
          <Text style={styles.listItem}>• Always confirm the payment status before saving.</Text>
          <Text style={styles.listItem}>• Regularly check the **Transfer Records** for any pending unpaid transfers.</Text>
          <Text style={styles.listItem}>• Always use the **Reverse Transfer** feature instead of making manual stock corrections.</Text>
        </View>
        <Text style={styles.guideText}>
          Following these suggestions helps maintain a professional and reliable inventory system.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    marginHorizontal: 16,
    marginTop: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  content: {
    flex: 1,
    padding: 20,
    margin: 16,
    backgroundColor: '#fff',
    borderRadius: 24
  },
  constructionBox: {
    backgroundColor: 'rgba(227, 242, 253, 0.9)',
    borderRadius: 20,
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    shadowColor: '#1565C0',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D47A1',
    marginTop: 20,
    textAlign: 'center',
  },
  message: {
    fontSize: 16,
    color: '#1A237E',
    textAlign: 'center',
    marginTop: 10,
  },
  guideTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#0D47A1',
    marginBottom: 16,
  },
  guideHeading: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1565C0',
    marginTop: 16,
    marginBottom: 8,
  },
  guideSubheading: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A237E',
    marginTop: 12,
    marginBottom: 6,
  },
  guideText: {
    fontSize: 16,
    color: '#1A237E',
    marginBottom: 12,
    lineHeight: 24,
  },
  list: {
    marginLeft: 16,
    marginBottom: 12,
  },
  listItem: {
    fontSize: 16,
    color: '#1A237E',
    lineHeight: 24,
  },
});
