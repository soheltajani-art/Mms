import React, { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Alert, Image, ActivityIndicator, Platform } from 'react-native';
import { Stack, useRouter, useFocusEffect } from 'expo-router';
import { ChevronLeft, Camera, ScanLine, X, AlertCircle, CheckCircle } from 'lucide-react-native';
import { ImageCapture } from '../../components/ImageCapture';
import { BarcodeScanner } from '../../components/BarcodeScanner';
import { addAvailableStock, checkImeiStatus, StockItem } from '../data/storage';

const FormField = React.memo(({ label, value, placeholder, onChangeText, keyboardType = 'default', maxLength, error, onFocus, onBlur, isRequired = false }: any) => {
  const [isFocused, setIsFocused] = useState(false);

  const handleFocus = () => {
    setIsFocused(true);
    onFocus?.();
  };

  const handleBlur = () => {
    setIsFocused(false);
    onBlur?.();
  };

  return (
    <View style={styles.inputGroup}>
      <View style={styles.labelContainer}>
        <Text style={styles.label}>{label}</Text>
        {isRequired && <Text style={styles.requiredAsterisk}>*</Text>}
      </View>
      <TextInput
        style={[
          styles.input, 
          isFocused && styles.inputFocused, 
          error && styles.inputError,
          Platform.OS === 'web' && { outline: 'none' } as any
        ]}
        placeholder={placeholder}
        placeholderTextColor="#999"
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        maxLength={maxLength}
        onFocus={handleFocus}
        onBlur={handleBlur}
      />
      {error ? (
        <View style={styles.errorContainer}>
          <AlertCircle size={14} color="#D32F2F" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      ) : null}
    </View>
  );
});

export default function Purchase() {
  const router = useRouter();
  const [modelNo, setModelNo] = useState('');
  const [primaryImei, setPrimaryImei] = useState('');
  const [buyingPrice, setBuyingPrice] = useState('');
  const [mop, setMop] = useState('');
  const [compulsoryPhoto, setCompulsoryPhoto] = useState<string | null>(null);
  const [optionalPhoto, setOptionalPhoto] = useState<string | null>(null);
  const [showCompulsoryCamera, setShowCompulsoryCamera] = useState(false);
  const [showOptionalCamera, setShowOptionalCamera] = useState(false);
  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  useFocusEffect(
    useCallback(() => {
      setModelNo('');
      setPrimaryImei('');
      setBuyingPrice('');
      setMop('');
      setCompulsoryPhoto(null);
      setOptionalPhoto(null);
      setShowCompulsoryCamera(false);
      setShowOptionalCamera(false);
      setShowBarcodeScanner(false);
      setErrors({});
      setIsLoading(false);
    }, [])
  );

  useEffect(() => {
    const validateImei = async () => {
      if (primaryImei.length === 15) {
        const { isDuplicate, message } = await checkImeiStatus(primaryImei);
        setErrors(prev => ({ ...prev, primaryImei: isDuplicate ? message : '' }));
      }
    };
    validateImei();
  }, [primaryImei]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!modelNo.trim()) newErrors.modelNo = 'Model number is required';
    if (primaryImei.length !== 15) newErrors.primaryImei = 'IMEI must be 15 digits';
    if (!buyingPrice || isNaN(parseFloat(buyingPrice))) newErrors.buyingPrice = 'Valid buying price is required';
    if (!mop || isNaN(parseFloat(mop))) newErrors.mop = 'Valid MOP is required';
    if (!compulsoryPhoto) newErrors.photo = 'At least one photo is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    const newItem: StockItem = {
      id: Date.now().toString(),
      modelNo,
      primaryImei,
      buyingPrice: parseFloat(buyingPrice),
      mopValue: parseFloat(mop),
      frontImage: '',
      backImage: '',
      purchaseDate: new Date().toISOString(),
      compulsoryPhoto: compulsoryPhoto || undefined,
      optionalPhoto: optionalPhoto || undefined,
    };

    try {
      const result = await addAvailableStock(newItem);
      if (result.duplicate) {
        Alert.alert('Duplicate Product', result.message);
      } else {
        router.push({
          pathname: '/purchase-success',
          params: {
            model: modelNo,
            imei1: primaryImei,
            price: buyingPrice,
            mop: mop,
            purchaseDate: newItem.purchaseDate,
            compulsoryPhoto: compulsoryPhoto,
            optionalPhoto: optionalPhoto || '',
          },
        });
      }
    } catch (error) {
      console.error('Failed to add stock:', error);
      Alert.alert('Error', 'An unexpected error occurred while adding the product.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCompulsoryPhotoCapture = (photoUri: string) => {
    setCompulsoryPhoto(photoUri);
    setShowCompulsoryCamera(false);
    setErrors({ ...errors, photo: '' });
  };

  const handleOptionalPhotoCapture = (photoUri: string) => {
    setOptionalPhoto(photoUri);
    setShowOptionalCamera(false);
  };

  const handleBarcodeScanComplete = (imei1: string) => {
    setPrimaryImei(imei1);
    setShowBarcodeScanner(false);
    setErrors(prev => ({ ...prev, primaryImei: '' }));
  };

  return (
    <ScrollView style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>New Purchase</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.card}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Device Information</Text>
        </View>

        <FormField label="MODEL NO" value={modelNo} placeholder="Enter device model" onChangeText={setModelNo} error={errors.modelNo} isRequired />
        <FormField label="IMEI" value={primaryImei} placeholder="Enter 15-digit IMEI" onChangeText={setPrimaryImei} keyboardType="numeric" maxLength={15} error={errors.primaryImei} isRequired />

        <TouchableOpacity style={styles.scanButton} onPress={() => setShowBarcodeScanner(true)}>
          <ScanLine size={24} color="#007AFF" />
          <Text style={styles.scanButtonText}>Scan Barcode (15-digit)</Text>
        </TouchableOpacity>

        <View style={styles.divider} />

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Pricing Information</Text>
        </View>

        <View style={styles.priceSection}>
          <View style={styles.priceInputGroup}>
            <View style={styles.labelContainer}>
              <Text style={styles.label}>BUYING PRICE</Text>
              <Text style={styles.requiredAsterisk}>*</Text>
            </View>
            <View style={[
              styles.priceInputContainer, 
              focusedField === 'buyingPrice' && styles.priceInputContainerFocused, 
              errors.buyingPrice ? styles.inputError : null
            ]}>
              <Text style={styles.currencySymbol}>₹</Text>
              <TextInput 
                style={[
                  styles.priceInput,
                  Platform.OS === 'web' && { outline: 'none' } as any
                ]} 
                placeholder="0.00" 
                placeholderTextColor="#999" 
                keyboardType="numeric" 
                value={buyingPrice} 
                onChangeText={setBuyingPrice} 
                onFocus={() => setFocusedField('buyingPrice')} 
                onBlur={() => setFocusedField(null)} 
              />
            </View>
            {errors.buyingPrice ? (
              <View style={styles.errorContainer}>
                <AlertCircle size={14} color="#D32F2F" />
                <Text style={styles.errorText}>{errors.buyingPrice}</Text>
              </View>
            ) : null}
          </View>

          <View style={styles.priceInputGroup}>
            <View style={styles.labelContainer}>
              <Text style={styles.label}>MOP [Market Operating Price]</Text>
              <Text style={styles.requiredAsterisk}>*</Text>
            </View>
            <View style={[
              styles.priceInputContainer, 
              focusedField === 'mop' && styles.priceInputContainerFocused, 
              errors.mop ? styles.inputError : null
            ]}>
              <Text style={styles.currencySymbol}>₹</Text>
              <TextInput 
                style={[
                  styles.priceInput,
                  Platform.OS === 'web' && { outline: 'none' } as any
                ]} 
                placeholder="0.00" 
                placeholderTextColor="#999" 
                keyboardType="numeric" 
                value={mop} 
                onChangeText={setMop} 
                onFocus={() => setFocusedField('mop')} 
                onBlur={() => setFocusedField(null)} 
              />
            </View>
            {errors.mop ? (
              <View style={styles.errorContainer}>
                <AlertCircle size={14} color="#D32F2F" />
                <Text style={styles.errorText}>{errors.mop}</Text>
              </View>
            ) : null}
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Photo Documentation</Text>
        </View>

        <View style={styles.photoSection}>
          <View style={styles.photoUpload}>
            <View style={styles.photoHeader}>
              <View style={[styles.tag, styles.compulsory]}>
                <Text style={styles.tagTextCompulsory}>REQUIRED</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.photoBoxContainer} onPress={() => setShowCompulsoryCamera(true)}>
              {compulsoryPhoto ? (
                <View style={styles.photoBoxWithImage}>
                  <Image source={{ uri: compulsoryPhoto }} style={styles.photoImage} />
                  <View style={styles.photoOverlay}>
                    <Camera size={24} color="#fff" />
                    <Text style={styles.photoOverlayText}>CHANGE PHOTO</Text>
                  </View>
                </View>
              ) : (
                <View style={styles.photoBox}>
                  <Camera size={32} color="#ccc" />
                  <Text style={styles.photoText}>TAKE PHOTO</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          <View style={styles.photoUpload}>
            <View style={styles.photoHeader}>
              <View style={[styles.tag, styles.optional]}>
                <Text style={styles.tagTextOptional}>OPTIONAL</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.photoBoxContainer} onPress={() => setShowOptionalCamera(true)}>
              {optionalPhoto ? (
                <View style={styles.photoBoxWithImage}>
                  <Image source={{ uri: optionalPhoto }} style={styles.photoImage} />
                  <View style={styles.photoOverlay}>
                    <Camera size={24} color="#fff" />
                    <Text style={styles.photoOverlayText}>CHANGE PHOTO</Text>
                  </View>
                </View>
              ) : (
                <View style={styles.photoBox}>
                  <Camera size={32} color="#ccc" />
                  <Text style={styles.photoText}>TAKE PHOTO</Text>
                </View>
              )}
            </TouchableOpacity>
            {optionalPhoto ? (
              <TouchableOpacity style={styles.removePhotoButton} onPress={() => setOptionalPhoto(null)}>
                <X size={14} color="#fff" />
                <Text style={styles.removePhotoText}>REMOVE</Text>
              </TouchableOpacity>
            ) : null}
          </View>
        </View>

        {errors.photo ? (
          <View style={styles.errorContainer}>
            <AlertCircle size={14} color="#D32F2F" />
            <Text style={styles.errorText}>{errors.photo}</Text>
          </View>
        ) : null}

        <View style={styles.infoContainer}>
          <View style={styles.infoRow}><CheckCircle size={16} color="#007AFF" /><Text style={styles.infoText}>Photos provide detailed product information</Text></View>
          <View style={styles.infoRow}><CheckCircle size={16} color="#007AFF" /><Text style={styles.infoText}>Not all details can be entered in the form</Text></View>
          <View style={styles.infoRow}><CheckCircle size={16} color="#007AFF" /><Text style={styles.infoText}>At least one photo is required</Text></View>
        </View>

        <TouchableOpacity style={[styles.submitButton, isLoading ? styles.submitButtonDisabled : null]} onPress={handleSubmit} disabled={isLoading}>
          {isLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.submitButtonText}>Submit Purchase</Text>}
        </TouchableOpacity>
      </View>

      {showCompulsoryCamera ? <ImageCapture isCompulsory={true} onPhotoCapture={handleCompulsoryPhotoCapture} onClose={() => setShowCompulsoryCamera(false)} /> : null}
      {showOptionalCamera ? <ImageCapture isCompulsory={false} onPhotoCapture={handleOptionalPhotoCapture} onClose={() => setShowOptionalCamera(false)} /> : null}
      <BarcodeScanner 
        isVisible={showBarcodeScanner} 
        onScan={handleBarcodeScanComplete} 
        onClose={() => setShowBarcodeScanner(false)} 
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#E3F2FD' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#000' },
  card: { backgroundColor: '#fff', borderRadius: 20, padding: 20, marginHorizontal: 16, marginTop: 16, marginBottom: 24, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 4, elevation: 2 },
  sectionHeader: { marginBottom: 16 },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: '#333', letterSpacing: 0.3 },
  inputGroup: { marginBottom: 16 },
  labelContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  label: { fontSize: 12, color: '#666', fontWeight: '600', letterSpacing: 0.2 },
  requiredAsterisk: { color: '#D32F2F', marginLeft: 4, fontWeight: 'bold' },
  input: { backgroundColor: '#F7F8FA', borderRadius: 10, padding: 12, fontSize: 16, borderColor: '#E5E7EB', borderWidth: 1.5, color: '#000' },
  inputFocused: { 
    borderColor: '#1565C0', 
    backgroundColor: '#FFFFFF', 
    borderWidth: 2.5,
  },
  inputError: { borderColor: '#D32F2F', backgroundColor: '#FFEBEE', borderWidth: 2 },
  errorContainer: { flexDirection: 'row', alignItems: 'center', marginTop: 6, paddingHorizontal: 8, gap: 6 },
  errorText: { fontSize: 12, color: '#D32F2F', fontWeight: '500' },
  scanButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#EBF5FF', borderRadius: 10, padding: 14, marginBottom: 16, gap: 10, borderWidth: 2, borderColor: '#007AFF', shadowColor: '#007AFF', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.2, shadowRadius: 6, elevation: 3 },
  scanButtonText: { color: '#007AFF', fontSize: 16, fontWeight: '600' },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 16 },
  priceSection: { flexDirection: 'column', gap: 16 },
  priceInputGroup: { width: '100%' },
  priceInputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F7F8FA', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 12, borderColor: '#E5E7EB', borderWidth: 1.5, overflow: 'hidden' },
  priceInputContainerFocused: { 
    borderColor: '#1565C0', 
    backgroundColor: '#FFFFFF', 
    borderWidth: 2.5,
  },
  currencySymbol: { fontSize: 18, color: '#666', marginRight: 4, fontWeight: '600' },
  priceInput: { flex: 1, fontSize: 16, color: '#000' },
  photoSection: { flexDirection: 'row', justifyContent: 'space-between', gap: 12, marginBottom: 16 },
  photoUpload: { flex: 1, alignItems: 'center' },
  photoHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, width: '100%' },
  tag: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 6 },
  compulsory: { backgroundColor: '#BBDEFB' },
  optional: { backgroundColor: '#E5F1FF' },
  tagTextCompulsory: { color: '#0D47A1', fontSize: 10, fontWeight: 'bold', letterSpacing: 0.3 },
  tagTextOptional: { color: '#007AFF', fontSize: 10, fontWeight: 'bold', letterSpacing: 0.3 },
  photoBoxContainer: { width: '100%', height: 150, borderRadius: 15, overflow: 'hidden' },
  photoBox: { flex: 1, backgroundColor: '#F7F8FA', borderRadius: 15, borderWidth: 2, borderColor: '#E5E7EB', borderStyle: 'dashed', justifyContent: 'center', alignItems: 'center', gap: 8 },
  photoBoxWithImage: { flex: 1, borderRadius: 15, overflow: 'hidden' },
  photoImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  photoOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', gap: 4 },
  photoOverlayText: { color: '#fff', fontSize: 11, fontWeight: 'bold', letterSpacing: 0.2 },
  photoText: { color: '#999', fontSize: 12, fontWeight: '600' },
  removePhotoButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#D32F2F', paddingHorizontal: 12, paddingVertical: 7, borderRadius: 6, marginTop: 10, gap: 4 },
  removePhotoText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  infoContainer: { backgroundColor: '#E3F2FD', padding: 14, borderRadius: 10, marginBottom: 20, borderLeftWidth: 4, borderLeftColor: '#007AFF' },
  infoRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 8, gap: 10 },
  infoText: { fontSize: 12, color: '#0D47A1', lineHeight: 18, flex: 1, fontWeight: '500' },
  submitButton: { backgroundColor: '#007AFF', borderRadius: 12, padding: 16, alignItems: 'center', borderWidth: 2, borderColor: '#007AFF', shadowColor: '#007AFF', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 4 },
  submitButtonDisabled: { backgroundColor: '#A9A9A9', borderColor: '#A9A9A9' },
  submitButtonText: { color: '#fff', fontSize: 18, fontWeight: 'bold', letterSpacing: 0.3 },
});
