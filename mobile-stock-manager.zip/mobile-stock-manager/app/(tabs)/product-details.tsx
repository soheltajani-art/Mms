
import React from 'react';
import ProductDetails from '../product-details';

export default function ProductDetailsTab() {
  return <ProductDetails />;
}
