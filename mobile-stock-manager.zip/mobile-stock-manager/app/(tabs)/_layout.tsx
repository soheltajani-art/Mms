import React from 'react';
import { Tabs } from 'expo-router';
import { Feather } from '@expo/vector-icons';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          display: 'none',
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ color }) => <Feather name="home" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="purchase"
        options={{
          title: 'Purchase',
          tabBarIcon: ({ color }) => <Feather name="shopping-cart" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="sell-stock"
        options={{
          title: 'Sell Stock',
          tabBarIcon: ({ color }) => <Feather name="trending-up" size={24} color={color} />,
        }}
      />
      <Tabs.Screen
        name="product-details"
        options={{
          title: 'Product Details',
          tabBarIcon: ({ color }) => <Feather name="package" size={24} color={color} />,
        }}
      />
    </Tabs>
  );
}
