
import React, { useState, useCallback, useEffect, useRef } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
  Modal,
  Platform,
  Animated
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter, useFocusEffect, useLocalSearchParams } from "expo-router";
import { getTodayStats, StockItem } from "../data/storage";
import { LinearGradient } from "expo-linear-gradient";
import { BlurView } from "expo-blur";
import ProductCard from "../components/ProductCard";
import { PhotoPreview } from "../../components/PhotoPreview";
import DashboardStats from "../components/DashboardStats";
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Dashboard() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const [totalStock, setTotalStock] = useState(0);
  const [todaysPurchases, setTodaysPurchases] = useState(0);
  const [todaysSoldOut, setTodaysSoldOut] = useState(0);
  const [todaysSales, setTodaysSales] = useState(0);
  const [todaysProfit, setTodaysProfit] = useState(0);
  
  const [products, setProducts] = useState<StockItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState('');
  const [showResetSuccess, setShowResetSuccess] = useState(false);
  const resetNoticeAnim = useRef(new Animated.Value(0)).current;

  const fetchDashboardData = useCallback(async () => {
    const stats = await getTodayStats();
    
    setTotalStock(stats.totalStock);
    setTodaysPurchases(stats.todaysPurchases);
    setTodaysSoldOut(stats.todaysSold);
    setTodaysSales(stats.todaysSalesRupees);
    setTodaysProfit(stats.todaysProfit);
    setProducts(stats.recentProducts);
    setSearchQuery(''); // Clear search query when refreshing
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchDashboardData();
      
      // Check for reset notification
      const checkResetNotification = async () => {
        const showReset = await AsyncStorage.getItem('showResetNotification');
        if (showReset === 'true') {
          setShowResetSuccess(true);
          await AsyncStorage.removeItem('showResetNotification');
          
          // Animate reset notice
          Animated.sequence([
            Animated.spring(resetNoticeAnim, {
              toValue: 1,
              friction: 8,
              useNativeDriver: true,
            }),
            Animated.delay(4000),
            Animated.timing(resetNoticeAnim, {
              toValue: 0,
              duration: 500,
              useNativeDriver: true,
            })
          ]).start(() => setShowResetSuccess(false));
        }
      };
      checkResetNotification();
    }, [fetchDashboardData])
  );

  useEffect(() => {
    // Always fetch data when dashboard comes into focus
    fetchDashboardData();
  }, [fetchDashboardData]);

  const filteredProducts = products.filter(product => {
    if (!searchQuery.trim()) return true;
    
    const query = searchQuery.trim().toLowerCase();
    const modelMatch = (product.model || "").toLowerCase().includes(query);
    const imeiMatch = (product.primaryImei || "").includes(query);
    const nameMatch = (product.name || "").toLowerCase().includes(query);
    const modelNoMatch = (product.modelNo || "").toLowerCase().includes(query);
    
    return modelMatch || imeiMatch || nameMatch || modelNoMatch;
  });

  const handleViewPhoto = (photoUri: string) => {
    setPreviewPhotoUri(photoUri);
    setShowPhotoPreview(true);
  };

  const resetDashboardState = useCallback(() => {
    setSearchQuery('');
    setShowPhotoPreview(false);
    setPreviewPhotoUri('');
  }, []);

  const DashboardHeader = () => (
    <View>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <View>
              <Text style={styles.headerTitle}>Mobile Stock</Text>
              <Text style={styles.headerSubtitle}>MANAGER</Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.iconButton}>
              <Feather name="bell" size={24} color="#333" />
          </TouchableOpacity>
        </View>
      </View>

      <TouchableOpacity style={styles.card} onPress={() => router.push('/available-stock')}>
          <View style={styles.cardIconContainer}> 
              <Feather name="box" size={24} color="#8A2BE2" />
          </View>
          <Text style={styles.cardTitle}>TOTAL STOCK</Text>
          <Text style={styles.cardValue}>{totalStock}</Text>
      </TouchableOpacity>

      <DashboardStats 
        todaysPurchases={todaysPurchases} 
        todaysSoldOut={todaysSoldOut} 
        todaysSales={todaysSales} 
        todaysProfit={todaysProfit} 
      />

      <View style={styles.recentProductsHeader}>
          <Text style={styles.recentProductsTitle}>Recent Products</Text>
          <View style={{flexDirection: 'row', gap: 15}}>
              <TouchableOpacity onPress={() => router.push('/todays-purchase-report')}>
                  <Text style={styles.viewAll}>PURCHASES</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => router.push('/todays-sales-report')}>
                  <Text style={styles.viewAll}>SALES</Text>
              </TouchableOpacity>
          </View>
      </View>
      <View style={[styles.searchContainer, isFocused && styles.searchContainerFocused]}>
          <Feather name="search" size={20} color={isFocused ? "#1565C0" : "#999"} style={styles.searchIcon} />
          <TextInput
              placeholder="Search by name or IMEI..."
              placeholderTextColor="#999"
              style={[
                styles.search,
                Platform.OS === 'web' && { outline: 'none' } as any
              ]}
              value={searchQuery}
              onChangeText={setSearchQuery}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
          />
          {searchQuery ? (
            <TouchableOpacity onPress={() => setSearchQuery('')} style={styles.clearButton}>
              <Feather name="x" size={18} color="#999" />
            </TouchableOpacity>
          ) : null}
      </View>
    </View>
  );
  
  return (
    <SafeAreaView style={styles.container} onLayout={resetDashboardState}>
      {showResetSuccess && (
        <Animated.View style={[styles.resetNotice, { 
          opacity: resetNoticeAnim,
          transform: [{ translateY: resetNoticeAnim.interpolate({
            inputRange: [0, 1],
            outputRange: [-100, 0]
          })}]
        }]}>
          <BlurView intensity={80} tint="light" style={styles.resetNoticeBlur}>
            <Feather name="check-circle" size={24} color="#2E7D32" />
            <Text style={styles.resetNoticeText}>App data reset successfully!</Text>
          </BlurView>
        </Animated.View>
      )}

      <FlatList
          style={{ flex: 1 }}
          data={filteredProducts}
          renderItem={({ item }) => <ProductCard item={item} onViewPhoto={handleViewPhoto} isAvailable={item.type !== 'SOLD'} />}
          keyExtractor={(item, index) => `${item.id}-${index}`}
          ListHeaderComponent={DashboardHeader}
          ListEmptyComponent={(
              <View style={styles.emptyRecentProducts}>
                  <View style={styles.emptyRecentProductsIcon}>
                      <Feather name="package" size={30} color="#ccc" />
                  </View>
                  <Text style={styles.emptyRecentProductsText}>NO PRODUCTS ADDED YET</Text>
              </View>
          )}
          contentContainerStyle={{ paddingBottom: 120 }}
      />

      {/* Bottom Buttons */}
      <BlurView intensity={90} tint="light" style={styles.bottomButtons}>
        <TouchableOpacity style={styles.bottomButton} onPress={() => router.push('/features')}>
          <Feather name="grid" size={24} color="#000" />
          <Text style={styles.bottomButtonText}>FEATURES</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomButton} onPress={() => router.push('/(tabs)/purchase')}>
          <Feather name="box" size={24} color="#000" />
          <Text style={styles.bottomButtonText}>PURCHASE STOCK</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomButton} onPress={() => router.push('/(tabs)/sell-stock')}>
          <Feather name="trending-up" size={24} color="#000" />
          <Text style={styles.bottomButtonText}>SELL STOCK</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.bottomButton} onPress={() => router.push('/(tabs)/transfer-stock')}>
          <Feather name="arrow-right-circle" size={24} color="#000" />
          <Text style={styles.bottomButtonText}>TRANSFER</Text>
        </TouchableOpacity>
      </BlurView>

      {showPhotoPreview && (
        <PhotoPreview
          photoUri={previewPhotoUri}
          isVisible={showPhotoPreview}
          onClose={() => setShowPhotoPreview(false)}
          allowRetake={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F8F9FA",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#fff',
    borderRadius: 20,
    marginHorizontal: 16,
    marginTop: 20,
    elevation: 2,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: '#000',
  },
  headerSubtitle: {
      fontSize: 14,
      fontWeight: 'bold',
      color: '#000',
  },
  headerRight: {
      flexDirection: 'row',
  },
  iconButton: {
      backgroundColor: '#F0F0F0',
      borderRadius: 15,
      padding: 8,
      marginLeft: 10,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 5,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 20,
    marginHorizontal: 16,
    marginVertical: 15,
    paddingHorizontal: 15,
    elevation: 2,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#E5E7EB',
  },
  searchContainerFocused: {
    borderColor: '#1565C0',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
      marginRight: 10,
  },
  clearButton: {
    padding: 8,
    marginLeft: 8,
  },
  search: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: '#333',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginHorizontal: 16,
    marginVertical: 10,
    elevation: 2,
  },
  cardIconContainer: {
    backgroundColor: '#E8D9FF',
    borderRadius: 15,
    padding: 12,
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  cardTitle: {
    fontSize: 14,
    color: "#999",
    fontWeight: '600',
    marginBottom: 5,
  },
  cardValue: {
    fontSize: 36,
    fontWeight: "bold",
    color: '#000'
  },
  bottomButtons: {
    position: 'absolute',
    bottom: 20,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderRadius: 20,
    paddingVertical: 16,
    paddingHorizontal: 8,
    overflow: 'hidden',
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  bottomButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomButtonText: {
    color: '#000',
    marginTop: 6,
    fontSize: 10,
    fontWeight: '700',
    textAlign: 'center',
    width: '100%',
  },
  recentProductsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 20,
    marginBottom: 10,
  },
  recentProductsTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: '#000',
  },
  viewAll: {
      fontSize: 14,
      fontWeight: 'bold',
      color: '#8A2BE2',
  },
  emptyRecentProducts: {
      backgroundColor: '#fff',
      borderRadius: 20,
      padding: 30,
      marginHorizontal: 16,
      alignItems: 'center',
      justifyContent: 'center',
      height: 150,
  },
  emptyRecentProductsIcon: {
      backgroundColor: '#f0f0f0',
      borderRadius: 50,
      padding: 15,
  },
  emptyRecentProductsText: {
      marginTop: 15,
      color: '#ccc',
      fontSize: 14,
      fontWeight: '600',
  },
  resetNotice: {
    position: 'absolute',
    top: 20,
    left: 20,
    right: 20,
    zIndex: 100,
    alignItems: 'center',
  },
  resetNoticeBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 30,
    gap: 10,
    borderWidth: 1,
    borderColor: '#DCFCE7',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  resetNoticeText: {
    color: '#1E293B',
    fontWeight: '700',
    fontSize: 14,
  }
});
