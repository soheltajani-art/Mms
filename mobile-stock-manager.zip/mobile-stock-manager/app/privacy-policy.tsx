import { useRouter } from 'expo-router';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ChevronLeft } from 'lucide-react-native';

export default function PrivacyPolicy() {
  const router = useRouter();

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Privacy Policy</Text>
        <View style={{ width: 24 }} />
      </View>

      <Card style={styles.card}>
        <CardHeader>
          <CardTitle style={styles.cardTitle}>
            Mobile Stock Manager [Special Edition] - Privacy Policy
          </CardTitle>
        </CardHeader>

        <CardContent>
          <Text style={styles.paragraph}>
            This app is designed with privacy and data safety in mind. This Privacy Policy explains how your data is handled.
          </Text>

          <View style={styles.notice}>
            <Text style={styles.noticeText}>
              <Text style={{ fontWeight: 'bold' }}>Important Notice</Text>{'\n'}
              Some features may be under development and will be added in future updates. By using this app, you accept this condition.
            </Text>
          </View>

          <Text style={styles.subheading}>1. Data Collection</Text>
          <Text style={styles.bullet}>• The app does not collect any personal information.</Text>
          <Text style={styles.bullet}>• No phone numbers, identities, or personal data are stored.</Text>
          <Text style={styles.bullet}>• Only stock-related data entered by the user is stored locally.</Text>

          <Text style={styles.subheading}>2. Data Storage</Text>
          <Text style={styles.bullet}>• All data is stored locally on your device using internal storage.</Text>
          <Text style={styles.bullet}>• The app does not upload data to any server.</Text>

          <Text style={styles.subheading}>3. User Rights</Text>
          <Text style={styles.bullet}>• Users can view their stock records.</Text>
          <Text style={styles.bullet}>• Users cannot directly delete individual records.</Text>
          <Text style={styles.bullet}>• Users can remove all data using the reset function.</Text>

          <Text style={styles.subheading}>4. Security</Text>
          <Text style={styles.bullet}>• Data is stored locally on your device.</Text>
          <Text style={styles.bullet}>• Users are responsible for securing their device (PIN, lock, etc.).</Text>

          <Text style={styles.subheading}>5. Permissions</Text>
          <Text style={styles.bullet}>• Camera is used for barcode scanning and image capturing.</Text>
          <Text style={styles.bullet}>• Storage is used to save captured images to internal storage.</Text>

          <Text style={styles.subheading}>6. Reset Function</Text>
          <Text style={styles.bullet}>
            • The reset function permanently deletes all stored data and cannot be undone.
          </Text>

          <Text style={styles.subheading}>7. Third-Party Services</Text>
          <Text style={styles.bullet}>
            • The app may display ads using third-party services (e.g., AdMob).
          </Text>

          <Text style={styles.subheading}>8. Changes to Policy</Text>
          <Text style={styles.bullet}>• This policy may be updated from time to time.</Text>

          <Text style={styles.subheading}>9. Contact</Text>
          <Text style={styles.paragraph}>For questions or support:</Text>
          <Text style={styles.bullet}>• Email: soheltajani@gmail.com</Text>
        </CardContent>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  card: {
    margin: 16,
    marginTop: 0,
    borderRadius: 20,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  paragraph: {
    fontSize: 16,
    lineHeight: 24,
    color: '#495057',
    marginBottom: 16,
  },
  subheading: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  bullet: {
    fontSize: 16,
    lineHeight: 24,
    color: '#495057',
    marginLeft: 16,
    marginBottom: 8,
  },
  notice: {
    backgroundColor: '#E9F7FD',
    padding: 16,
    borderRadius: 20,
    marginBottom: 16,
  },
  noticeText: {
    fontSize: 16,
    color: '#0C5460',
  },
});