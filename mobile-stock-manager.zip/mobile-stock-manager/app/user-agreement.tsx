
import { useRouter } from 'expo-router';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ChevronLeft } from 'lucide-react-native';

export default function UserAgreement() {
  const router = useRouter();

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>User Agreement</Text>
        <View style={{ width: 24 }} />
      </View>
      <Card style={styles.card}>
        <CardHeader>
          <CardTitle style={styles.cardTitle}>Mobile Stock Manager [Special Edition] - User Agreement</CardTitle>
          <Text style={styles.effectiveDate}>Effective Date: April 16, 2026</Text>
        </CardHeader>
        <CardContent>
          <View style={styles.notice}>
            <Text style={styles.noticeText}>
              <Text style={{fontWeight: 'bold'}}>Important Notice</Text>{'\n'}
              Please be advised that some features mentioned in this document may be under construction. By using this application, you acknowledge and accept this condition. If you do not agree, please refrain from using the app.
            </Text>
          </View>
          <Text style={styles.paragraph}>
            By using Mobile Stock Manager [Special Edition] ("the App"), you agree to the following terms and conditions. If you do not agree, do not use the App.
          </Text>

          <Text style={styles.subheading}>1. User Responsibilities</Text>
          <Text style={styles.bullet}>• Admin and employee users can both change data within the app.</Text>
          <Text style={styles.bullet}>• Users must provide accurate employee numbers and stock details.</Text>
          <Text style={styles.bullet}>• Users must comply with local laws when using the App.</Text>

          <Text style={styles.subheading}>2. Data Privacy and Storage</Text>
          <Text style={styles.bullet}>• Employee numbers and stock data are stored locally on your device (SharedPreferences or SQLite).</Text>
          <Text style={styles.bullet}>• No cloud or external servers are used for data storage.</Text>
          <Text style={styles.bullet}>• No personal data is intentionally collected or shared by the application.</Text>

          <Text style={styles.subheading}>3. Limitation of Liability</Text>
          <Text style={styles.bullet}>• The app is provided "as is", without any guarantees.</Text>
          <Text style={styles.bullet}>• There is no guarantee that this app is free from bugs or errors. Users should use the app at their own risk.</Text>
          <Text style={styles.bullet}>• Developers are not liable for data loss, business loss, or damages arising from use of the app.</Text>
          <Text style={styles.bullet}>• Users use the app entirely at their own risk.</Text>

          <Text style={styles.subheading}>4. Acceptable Use Policy</Text>
          <Text style={styles.bullet}>• Do not misuse the App for illegal, fraudulent, or harmful activities.</Text>
          <Text style={styles.bullet}>• Do not attempt to unlawfully modify the App, or distribute stock data without consent.</Text>

          <Text style={styles.subheading}>5. Service Availability</Text>
          <Text style={styles.bullet}>• The app's current services are free. In the future, the developer or owner may introduce paid services and make this app paid.</Text>
          <Text style={styles.bullet}>• The app may be updated, changed, or discontinued at any time without prior notice.</Text>

          <Text style={styles.subheading}>6. User Data Rights</Text>
          <Text style={styles.bullet}>• Users can access, correct, and delete local stock data and employee numbers.</Text>
          <Text style={styles.bullet}>• Employees can delete received data from their devices.</Text>
          <Text style={styles.bullet}>• Admin controls the data on their device.</Text>

          <Text style={styles.subheading}>7. Contact Information for Legal Matters</Text>
          <Text style={styles.paragraph}>For any legal inquiries, disputes, or questions:</Text>
          <Text style={styles.bullet}>• Email (legal inquiries): soheltajan@gmail.com</Text>
          <Text style={styles.bullet}>• Email (suggestions/general): soheltajan@gmail.com</Text>

          <Text style={styles.footer}>
            By using Mobile Stock Manager [Special Edition], you acknowledge and agree to this User Agreement.
          </Text>
        </CardContent>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#E3F2FD',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingVertical: 12,
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        margin:16,
        borderWidth: 2,
        borderColor: '#E5E7EB',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 4,
        elevation: 2,
      },
      headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
      },
      backButton: {
        backgroundColor: '#FFFFFF',
        borderRadius: 10,
        padding: 8,
        borderWidth: 1.5,
        borderColor: '#E5E7EB',
      },
    card: {
        margin: 16,
        marginTop: 0,
        borderRadius: 20,
    },
    cardTitle: {
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 4,
    },
    effectiveDate: {
      fontSize: 14,
      color: '#6C757D',
      marginBottom: 16,
    },
    paragraph: {
        fontSize: 16,
        lineHeight: 24,
        color: '#495057',
        marginBottom: 16,
    },
    subheading: {
      fontSize: 18,
      fontWeight: 'bold',
      marginTop: 16,
      marginBottom: 8,
    },
    bullet: {
      fontSize: 16,
      lineHeight: 24,
      color: '#495057',
      marginBottom: 8,
      marginLeft: 16,
    },
    notice: {
      backgroundColor: '#E9F7FD',
      padding: 16,
      borderRadius: 20,
      marginBottom: 16,
    },
    noticeText: {
      fontSize: 16,
      color: '#0C5460',
    },
    footer: {
      textAlign: 'center',
      marginTop: 24,
      fontSize: 14,
      color: '#6C757D',
      fontWeight: 'bold',
    }
});
