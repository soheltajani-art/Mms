
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, FlatList, SafeAreaView } from 'react-native';
import { ChevronLeft, Search, Box, X } from 'lucide-react-native';
import { useRouter, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { getHistory, HistoryItem, getLocalDateString, extractLocalDateFromISO } from './data/storage';
import { PhotoPreview } from '../components/PhotoPreview';
import ProductCard from './components/ProductCard';

const TodaysSalesReport = () => {
  const router = useRouter();
  const [allSales, setAllSales] = useState<HistoryItem[]>([]);
  const [sales, setSales] = useState<HistoryItem[]>([]);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [allDataLoaded, setAllDataLoaded] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState<string | undefined>(undefined);
  const params = useLocalSearchParams();
  const { date } = params;
  const SALES_PER_PAGE = 20;

  const fetchTodaysSales = useCallback(async () => {
    const history = await getHistory();
    const targetDate = date ? new Date(date as string) : new Date();
    const targetDateString = getLocalDateString(targetDate);

    const salesForDate = history.filter(item => {
        if (item.type === 'SOLD' && item.soldDate) {
            const soldDateString = extractLocalDateFromISO(item.soldDate);
            return soldDateString === targetDateString;
        }
        return false;
    });
    setAllSales(salesForDate);
    setPage(1);
    setAllDataLoaded(false);
    setSales([]);
    setSearchQuery('');
  }, [date]);

  useFocusEffect(
    useCallback(() => {
      fetchTodaysSales();
    }, [fetchTodaysSales])
  );

  const filteredSales = allSales.filter(sale => {
    if (!searchQuery.trim()) return true;
    
    const query = searchQuery.trim().toLowerCase();
    const modelMatch = sale.model?.toLowerCase().includes(query) ?? false;
    const imeiMatch = sale.primaryImei?.includes(query) ?? false;
    
    return modelMatch || imeiMatch;
  });

  useEffect(() => {
    if (allDataLoaded) return;
    const newSales = filteredSales.slice((page - 1) * SALES_PER_PAGE, page * SALES_PER_PAGE);
    if (newSales.length > 0) {
      if (page === 1) {
        setSales(newSales);
      } else {
        setSales(prevSales => [...prevSales, ...newSales]);
      }
    } else {
      if (page === 1) {
        setSales([]);
      }
      setAllDataLoaded(true);
    }
  }, [page, filteredSales, allDataLoaded]);

  useEffect(() => {
    setPage(1);
    setAllDataLoaded(false);
  }, [searchQuery]);

  const handleLoadMore = () => {
    if (!allDataLoaded) {
      setPage(prevPage => prevPage + 1);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setFocusedField(null);
  };

  const renderFooter = () => {
    if (allDataLoaded && sales.length > 0) {
      return <Text style={styles.endOfListText}>End of sales list</Text>;
    }
    return null;
  };

  const handleViewPhoto = (photoUri: string | undefined) => {
    if (photoUri) {
      setPreviewPhotoUri(photoUri);
      setShowPhotoPreview(true);
    }
  };

  const headerTitle = date
    ? `Sales on ${new Date(date as string).toLocaleDateString()}`
    : "Today's Sales Report";

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{headerTitle}</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={[styles.searchContainer, focusedField === 'search' && styles.searchContainerFocused]}>
        <Search size={20} color={focusedField === 'search' ? '#1565C0' : '#909090'} style={styles.searchIcon} />
        <TextInput
          placeholder="Search by model or IMEI..."
          placeholderTextColor="#909090"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => setFocusedField('search')}
          onBlur={() => setFocusedField(null)}
        />
        {searchQuery ? (
          <TouchableOpacity onPress={handleClearSearch} style={styles.clearButton}>
            <X size={18} color="#909090" />
          </TouchableOpacity>
        ) : null}
      </View>

      <View style={styles.infoRow}>
        <View style={styles.itemsAvailableContainer}>
          <Text style={styles.itemsAvailable}>{filteredSales.length} ITEMS SOLD</Text>
        </View>
        {searchQuery.length > 0 && (
          <Text style={styles.searchHint}>Search active</Text>
        )}
      </View>

      <View style={styles.contentWrapper}>
        <FlatList
            data={sales}
            renderItem={({ item }) => (
              <ProductCard 
                item={item} 
                onViewPhoto={handleViewPhoto} 
                isAvailable={false} 
              />
            )}
            keyExtractor={item => item.id}
            onEndReached={handleLoadMore}
            onEndReachedThreshold={0.5}
            ListFooterComponent={renderFooter}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24, flexGrow: 1 }}
            ListEmptyComponent={(
              <View style={styles.emptyStateContainer}>
                <View style={styles.iconBackground}>
                  <Box size={48} color="#1565C0" />
                </View>
                <Text style={styles.emptyStateTitle}>
                  {searchQuery.length > 0 ? 'NO MATCHES FOUND' : 'NO SALES TODAY'}
                </Text>
                <Text style={styles.emptyStateSubtitle}>
                  {searchQuery.length > 0
                    ? "We couldn't find any sales matching your search."
                    : 'There have been no sales recorded for this day yet.'}
                </Text>
              </View>
            )}
          />
      </View>

      <PhotoPreview
        isVisible={showPhotoPreview}
        photoUri={previewPhotoUri}
        onClose={() => setShowPhotoPreview(false)}
        allowRetake={false}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginHorizontal: 16,
    marginTop: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 30,
    overflow: 'hidden',
    marginHorizontal: 16,
    marginBottom: 16,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginHorizontal: 16,
    paddingHorizontal: 16,
    marginTop: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  searchContainerFocused: {
    borderColor: '#1565C0',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
    marginRight: 12,
  },
  clearButton: {
    padding: 8,
    marginLeft: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: '#000',

  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  itemsAvailableContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  itemsAvailable: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#0D47A1',
    letterSpacing: 0.5,
  },
  searchHint: {
    fontSize: 10,
    color: '#666',
    fontStyle: 'italic',
  },
  emptyStateContainer: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBackground: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 32,
    borderWidth: 2,
    borderColor: '#1565C0',
  },
  emptyStateTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#0D47A1',
    textAlign: 'center',
    marginBottom: 12,
  },
  emptyStateSubtitle: {
    fontSize: 16,
    color: '#1565C0',
    textAlign: 'center',
    lineHeight: 22,
  },
  endOfListText: {
    textAlign: 'center',
    padding: 16,
    fontSize: 14,
    color: '#888',
  },
});

export default TodaysSalesReport;
