
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { ChevronLeft, Info } from 'lucide-react-native';
import { useRouter, Stack } from 'expo-router';

const TermsAndConditionsPage = () => {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Terms & Conditions</Text>
        <View style={{ width: 24 }}/>
      </View>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.card}>
          <Text style={styles.ownerInfo}>Owner & Copyright Holder: MOHAMMED SOHEL TAJANI</Text>
          <Text style={styles.ownerInfo}>Contact Email: soheltajani@gmail.com</Text>

          <View style={styles.noticeBox}>
            <Info size={20} color="#3B82F6" />
            <View style={styles.noticeContent}>
                <Text style={styles.noticeTitle}>Important Notice</Text>
                <Text style={styles.noticeText}>
                    Please be advised that some features mentioned in this document may be under construction. By using this application, you acknowledge and accept this condition. If you do not agree, please refrain from using the app.
                </Text>
            </View>
          </View>

          <Text style={styles.bodyText}>By logging in or using this application, you agree to the following Terms and Conditions. If you do not agree, please do not use the app.</Text>

          <Text style={styles.sectionTitle}>1. Acceptance of Terms</Text>
          <Text style={styles.bodyText}>By selecting and logging into the app, the user confirms that they have read, understood, and accepted these Terms and Conditions.</Text>

          <Text style={styles.sectionTitle}>2. User Responsibility</Text>
          <Text style={styles.bodyText}>The use of this app is entirely the responsibility of the user. The app owner is not responsible for any misuse of the application. If the app is misused in any way, the user alone is responsible for the consequences.</Text>

          <Text style={styles.sectionTitle}>3. Intellectual Property and Restrictions</Text>
          <Text style={styles.bodyText}>This application, including its code, design, branding, and user interface, is the exclusive intellectual property of the owner, MOHAMMED SOHEL TAJANI. Copying this app or any part of it is not allowed. Reverse engineering, decompiling, modifying, or creating another app using this app's code, design, or format is strictly prohibited. The app and its associated intellectual property may not be sold, shared, or distributed without express written permission from the owner.</Text>

          <Text style={styles.sectionTitle}>4. Data Storage and Privacy</Text>
          <Text style={styles.bodyText}>The app owner does not collect any personal data. All data is stored locally on the user's device.</Text>

          <Text style={styles.sectionTitle}>5. Disclaimer of Liability</Text>
          <Text style={styles.bodyText}>If the app contains errors, bugs, or does not work properly, the owner is not responsible. Users must test the app before using it for important purposes. If the app's failure causes any kind of loss, damage, or problem, the app owner will not be responsible under any circumstances.</Text>

          <Text style={styles.footerText}>Copyright (c) 2024 MOHAMMED SOHEL TAJANI. All Rights Reserved.</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  scrollContent: {
    padding: 16,
    paddingTop: 0,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  ownerInfo: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 4,
  },
  noticeBox: {
    backgroundColor: '#DBEAFE',
    borderRadius: 20,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginVertical: 20,
    borderWidth: 1,
    borderColor: '#BFDBFE'
  },
  noticeContent: {
    marginLeft: 12,
    flex: 1,
  },
  noticeTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2563EB',
  },
  noticeText: {
    fontSize: 14,
    color: '#3B82F6',
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginTop: 24,
    marginBottom: 8,
  },
  bodyText: {
    fontSize: 16,
    color: '#4B5563',
    lineHeight: 24,
    marginBottom: 16,
  },
  footerText: {
    fontSize: 12,
    color: '#6B7280',
    textAlign: 'center',
    marginTop: 24,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    paddingTop: 16,
  },
});

export default TermsAndConditionsPage;
