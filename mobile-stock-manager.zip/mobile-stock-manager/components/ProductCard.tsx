
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StockItem } from '../app/data/storage';
import { PhotoPreview } from './PhotoPreview';

interface ProductCardProps {
  item: StockItem;
  isAvailable?: boolean;
  onViewPhoto?: (photoUri: string) => void;
}

const ProductCard = ({ item, isAvailable, onViewPhoto }: ProductCardProps) => {
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState('');

  // Determine if item is sold based on type or isAvailable prop
  const isSold = item.type === 'SOLD' || !isAvailable;

  const handleViewPhoto = (photoUri: string) => {
    if (onViewPhoto) {
      onViewPhoto(photoUri);
    } else {
      setPreviewPhotoUri(photoUri);
      setShowPhotoPreview(true);
    }
  };

  // Calculate profit if item is sold
  const profit = isSold ? (item.sellingPrice || 0) - item.purchaseCost : 0;

  return (
    <>
      <View style={styles.itemContainer}>
        <LinearGradient
          colors={['#ffffff', '#f3f6fb']}
          style={styles.card}
        >
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>{item.model}</Text>
            <LinearGradient
                colors={isSold ? ['#ef4444', '#dc2626'] : ['#22c55e', '#16a34a']}
                style={styles.stock}
            >
              <Text style={styles.stockText}>{isSold ? 'Sold Out' : 'In Stock'}</Text>
            </LinearGradient>
          </View>

          <View style={styles.row}>
            <Text style={styles.labelText}>IMEI</Text>
            <Text style={styles.value}>{item.primaryImei}</Text>
          </View>
          <View style={styles.divider} />

          {!isSold ? (
            // AVAILABLE STOCK VIEW
            <>
            <View style={styles.row}>
              <Text style={styles.labelText}>MOP [Market Operating Price]</Text>
              <Text style={styles.value}>₹ {item.mopValue}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.row}>
              <Text style={styles.labelText}>Purchase Price</Text>
              <Text style={styles.value}>₹ {item.purchaseCost}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.row}>
            <Text style={styles.labelText}>Purchase Date</Text>
            <Text style={styles.value}>{new Date(item.purchaseDate).toLocaleDateString()}</Text>
          </View>
          </>
          ) : (
            // SOLD OUT VIEW - Show complete transaction details
            <>
            <View style={styles.row}>
              <Text style={styles.labelText}>Purchase Price</Text>
              <Text style={styles.value}>₹ {item.purchaseCost}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.row}>
                <Text style={styles.labelText}>Selling Price</Text>
                <Text style={styles.value}>₹ {item.sellingPrice || 0}</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.row}>
                <Text style={styles.labelText}>Profit</Text>
                <Text style={[styles.value, { color: profit >= 0 ? '#16a34a' : '#dc2626' }]}>
                  ₹ {profit.toFixed(2)}
                </Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.row}>
              <Text style={styles.labelText}>MOP</Text>
              <Text style={styles.value}>₹ {item.mopValue}</Text>
            </View>
            <View style={styles.divider} />

            <View style={styles.row}>
              <Text style={styles.labelText}>Purchase Date</Text>
              <Text style={styles.value}>{new Date(item.purchaseDate).toLocaleString()}</Text>
            </View>

            {item.soldDate && (
                <>
                  <View style={styles.divider} />
                  <View style={styles.row}>
                    <Text style={styles.labelText}>Sold Date</Text>
                    <Text style={styles.value}>{new Date(item.soldDate).toLocaleString()}</Text>
                  </View>
                </>
              )}
            </>
          )}

          {(item.compulsoryPhoto || item.optionalPhoto) && (
            <>
              <Text style={styles.photoTitle}>Photo Documentation</Text>
              <View style={styles.photoRow}>
                {item.compulsoryPhoto && (
                  <View style={styles.photoBlock}>
                    <View style={[styles.label, styles.required]}>
                      <Text style={styles.requiredText}>REQUIRED</Text>
                    </View>
                    <TouchableOpacity onPress={() => handleViewPhoto(item.compulsoryPhoto!)}>
                      <View style={styles.uploadBox}>
                        <Text style={styles.uploadBoxText}>VIEW PHOTO</Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                )}
                {item.optionalPhoto && (
                  <View style={styles.photoBlock}>
                    <View style={[styles.label, styles.optional]}>
                      <Text style={styles.optionalText}>OPTIONAL</Text>
                    </View>
                     <TouchableOpacity onPress={() => handleViewPhoto(item.optionalPhoto!)}>
                      <View style={styles.uploadBox}>
                        <Text style={styles.uploadBoxText}>VIEW PHOTO</Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </>
          )}
        </LinearGradient>
      </View>

      {showPhotoPreview && (
        <PhotoPreview
          photoUri={previewPhotoUri}
          isVisible={showPhotoPreview}
          onClose={() => setShowPhotoPreview(false)}
          allowRetake={false}
        />
      )}
    </>
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  card: {
    borderRadius: 16,
    padding: 16,
    shadowColor: "rgba(0,0,0,0.08)",
    shadowOffset: {
      width: 4,
      height: 4,
    },
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 6,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
  },
  stock: {
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 16,
  },
  stockText: {
      color: 'white',
      fontSize: 12,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 13,
  },
  divider: {
    height: 1,
    backgroundColor: '#e5e7eb',
  },
  labelText: {
    color: '#444',
    fontSize: 13,
    fontWeight: '500',
  },
  value: {
    color: '#7b7b7b',
    fontWeight: '500',
    fontSize: 13,
  },
  dateTimeContainer: {
    alignItems: 'flex-end',
  },
  photoTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginVertical: 14,
  },
  photoRow: {
    flexDirection: 'row',
    gap: 12,
  },
  photoBlock: {
    flex: 1,
  },
  label: {
    paddingVertical: 4,
    paddingHorizontal: 10,
    borderRadius: 10,
    marginBottom: 6,
    alignSelf: 'flex-start',
  },
  required: {
    backgroundColor: '#ffe4e6',
  },
  requiredText:{
      color: '#dc2626',
      fontWeight: '600',
      fontSize: 11,
  },
  optional: {
    backgroundColor: '#e0f2fe',
  },
  optionalText: {
      color: '#0284c7',
      fontWeight: '600',
      fontSize: 11,
  },
  uploadBox: {
    height: 120,
    borderWidth: 2,
    borderColor: '#d1d5db',
    borderStyle: 'dashed',
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fafafa',
  },
  uploadBoxText: {
    color: '#9ca3af',
    fontSize: 13,
  },
});

export default ProductCard;
