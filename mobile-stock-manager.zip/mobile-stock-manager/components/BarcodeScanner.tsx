import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Modal, Dimensions, Platform } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { X, Zap, ZapOff } from 'lucide-react-native';
import CameraPermissionModal from '../app/components/CameraPermissionModal';
import { getOptimalCameraResolution } from '../utils/cameraResolution';

interface BarcodeScannerProps {
  isVisible: boolean;
  onClose: () => void;
  onScan: (data: string) => void;
}

export const BarcodeScanner: React.FC<BarcodeScannerProps> = ({ isVisible, onClose, onScan }) => {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [torch, setTorch] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [pictureSize, setPictureSize] = useState<string>('1920x1080'); // Default to High Definition

  const cameraRef = useRef<CameraView>(null);

  useEffect(() => {
    if (isVisible) {
      setScanned(false);
      if (permission && !permission.granted && permission.canAskAgain) {
        setShowPermissionModal(true);
      }
    }
  }, [isVisible, permission]);

  const handleRequestPermission = async () => {
    setShowPermissionModal(false);
    const result = await requestPermission();
    if (!result.granted) {
      onClose();
    }
  };

  const handleCameraReady = async () => {
    if (cameraRef.current) {
      try {
        // Attempt to get the highest possible resolution for high clarity
        const resolutionInfo = await getOptimalCameraResolution(cameraRef.current);
        if (resolutionInfo) {
          setPictureSize(resolutionInfo.resolution);
          console.log(`🚀 Scanner Optimized: High Clarity Mode (${resolutionInfo.resolution})`);
        }
      } catch (e) {
        console.warn('Resolution optimization failed, using default HD');
      }
    }
  };

  const handleBarCodeScanned = ({ data }: { data: string }) => {
    if (scanned) return;
    
    const cleanData = data.trim();
    // High-speed validation for 15-digit barcodes (IMEI)
    if (cleanData.length === 15 && /^\d+$/.test(cleanData)) {
      setScanned(true);
      onScan(cleanData);
    }
  };

  if (!permission) return null;

  return (
    <Modal
      animationType="fade"
      transparent={false}
      visible={isVisible}
      onRequestClose={onClose}
    >
      <View style={styles.container}>
        {!permission.granted ? (
          <View style={styles.permissionContainer}>
            <CameraPermissionModal 
              visible={showPermissionModal}
              onClose={onClose}
              onConfirm={handleRequestPermission}
            />
            <Text style={styles.permissionText}>Camera access is required for high-speed scanning.</Text>
            <TouchableOpacity style={styles.permissionButton} onPress={() => setShowPermissionModal(true)}>
              <Text style={styles.permissionButtonText}>Enable Camera</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.closeButton} onPress={onClose}>
              <X size={30} color="#fff" />
            </TouchableOpacity>
          </View>
        ) : (
          <CameraView
            ref={cameraRef}
            style={styles.camera}
            facing="back"
            enableTorch={torch}
            autofocus="on" // Continuous autofocus for speed
            zoom={0} // Wider view for easier alignment
            pictureSize={pictureSize}
            onCameraReady={handleCameraReady}
            onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
            barcodeScannerSettings={{
              // Limited to specific types for faster processing
              barcodeTypes: ["code128", "code39", "ean13", "upc_a"],
            }}
          >
            <View style={styles.overlay}>
              <View style={styles.header}>
                <TouchableOpacity style={styles.iconButton} onPress={() => setTorch(!torch)}>
                  {torch ? <Zap size={28} color="#FFD700" /> : <ZapOff size={28} color="#fff" />}
                </TouchableOpacity>
                <View style={styles.headerTextContainer}>
                  <Text style={styles.headerText}>High-Speed Scanner</Text>
                  <Text style={styles.subHeaderText}>Focusing on 15-digit codes</Text>
                </View>
                <TouchableOpacity style={styles.iconButton} onPress={onClose}>
                  <X size={28} color="#fff" />
                </TouchableOpacity>
              </View>

              <View style={styles.scanAreaContainer}>
                <View style={styles.scanArea}>
                  <View style={[styles.corner, styles.topLeft]} />
                  <View style={[styles.corner, styles.topRight]} />
                  <View style={[styles.corner, styles.bottomLeft]} />
                  <View style={[styles.corner, styles.bottomRight]} />
                  <View style={styles.scanLine} />
                </View>
                <Text style={styles.hintText}>Near-Instant Detection</Text>
              </View>

              <View style={styles.footer}>
                <Text style={styles.footerText}>FREE FOREVER • OPTIMIZED PERFORMANCE</Text>
              </View>
            </View>
          </CameraView>
        )}
      </View>
    </Modal>
  );
};

const { width, height } = Dimensions.get('window');
const isSmallDevice = width < 375;
const scanAreaWidth = width * 0.85;
const scanAreaHeight = 120; // Narrower area for faster row scanning

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  camera: { flex: 1 },
  permissionContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  permissionText: { color: '#fff', fontSize: 18, textAlign: 'center', marginBottom: 20 },
  permissionButton: { backgroundColor: '#007AFF', paddingHorizontal: 25, paddingVertical: 12, borderRadius: 10 },
  permissionButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  closeButton: { position: 'absolute', top: 50, right: 20 },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.2)', justifyContent: 'space-between' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: height * 0.07, paddingHorizontal: 20 },
  headerTextContainer: { flex: 1, alignItems: 'center' },
  headerText: { color: '#fff', fontSize: 20, fontWeight: '700', letterSpacing: 0.5 },
  subHeaderText: { color: '#007AFF', fontSize: 12, fontWeight: '600', marginTop: 2 },
  iconButton: { width: 46, height: 46, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.4)', borderRadius: 23 },
  scanAreaContainer: { alignItems: 'center', justifyContent: 'center' },
  scanArea: { width: scanAreaWidth, height: scanAreaHeight, position: 'relative' },
  scanLine: { height: 1.5, backgroundColor: '#007AFF', width: '100%', position: 'absolute', top: '50%', opacity: 0.8 },
  corner: { position: 'absolute', width: 25, height: 25, borderColor: '#007AFF', borderStyle: 'solid' },
  topLeft: { top: 0, left: 0, borderTopWidth: 5, borderLeftWidth: 5 },
  topRight: { top: 0, right: 0, borderTopWidth: 5, borderRightWidth: 5 },
  bottomLeft: { bottom: 0, left: 0, borderBottomWidth: 5, borderLeftWidth: 5 },
  bottomRight: { bottom: 0, right: 0, borderBottomWidth: 5, borderRightWidth: 5 },
  hintText: { color: '#fff', marginTop: 25, fontSize: 14, fontWeight: '500', backgroundColor: 'rgba(0,74,173,0.6)', paddingHorizontal: 20, paddingVertical: 8, borderRadius: 25, overflow: 'hidden' },
  footer: { paddingBottom: 40, alignItems: 'center' },
  footerText: { color: '#fff', fontSize: 10, fontWeight: '700', opacity: 0.5, letterSpacing: 1.5 },
});

export default BarcodeScanner;
