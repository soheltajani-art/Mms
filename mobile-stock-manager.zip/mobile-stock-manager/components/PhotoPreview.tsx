
import React from 'react';
import { Modal, View, Image, StyleSheet, TouchableOpacity, Text, Dimensions, SafeAreaView } from 'react-native';
import { Feather } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

export const PhotoPreview = ({ isVisible, photoUri, onClose, onRetake, onDone, allowRetake = true }) => {
  if (!isVisible) return null;

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.container}>
        <View style={styles.modalContent}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Photo Viewer</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Feather name="x" size={24} color="#000" />
            </TouchableOpacity>
          </View>

          <Image source={{ uri: photoUri }} style={styles.previewImage} />

          <View style={styles.footer}>
            {allowRetake ? (
              <View style={styles.previewControls}>
                <TouchableOpacity onPress={onRetake} style={[styles.actionButton, styles.retakeButton]}>
                  <Feather name="refresh-cw" size={20} color="#fff" />
                  <Text style={styles.actionButtonText}>Retake</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={onDone} style={[styles.actionButton, styles.doneButton]}>
                  <Feather name="check" size={20} color="#fff" />
                  <Text style={styles.actionButtonText}>Done</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.closeControls}>
                <TouchableOpacity onPress={onClose} style={styles.closeActionButton}>
                  <Text style={styles.closeActionButtonText}>Close</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </SafeAreaView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: width * 0.9,
    backgroundColor: '#fff',
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E5E5',
  },
  headerTitle: {
    color: '#000',
    fontSize: 18,
    fontWeight: 'bold',
  },
  closeButton: {
    padding: 4,
  },
  previewImage: {
    width: '100%',
    height: height * 0.5,
    resizeMode: 'contain',
    borderRadius: 20,
  },
  footer: {
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#E5E5E5',
  },
  previewControls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
  },
  closeControls: {
    paddingVertical: 16,
    paddingHorizontal: 16,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 10,
    gap: 8,
  },
  retakeButton: {
    backgroundColor: '#FF9500',
  },
  doneButton: {
    backgroundColor: '#34C759',
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  closeActionButton: {
    backgroundColor: '#007AFF',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  closeActionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
