import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Image,
  Dimensions,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as FileSystem from 'expo-file-system';
import { X, RotateCcw, Check } from 'lucide-react-native';
import CameraPermissionModal from '../app/components/CameraPermissionModal';
import { getOptimalCameraResolution, formatMegapixels } from '../utils/cameraResolution';

const { width, height } = Dimensions.get('window');
const isSmallDevice = width < 375;

interface ImageCaptureProps {
  isCompulsory: boolean;
  onPhotoCapture: (photoUri: string) => void;
  onClose: () => void;
}

export const ImageCapture: React.FC<ImageCaptureProps> = ({
  isCompulsory,
  onPhotoCapture,
  onClose,
}) => {
  const [permission, requestPermission] = useCameraPermissions();
  const [cameraMode, setCameraMode] = useState<'capture' | 'preview'>('capture');
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [isTakingPicture, setIsTakingPicture] = useState(false);
  const [cameraReady, setCameraReady] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [pictureSize, setPictureSize] = useState<string>();
  const [cameraResolutionInfo, setCameraResolutionInfo] = useState<string>('');

  const cameraRef = useRef<CameraView>(null);

  const handleCameraReady = async () => {
    setCameraReady(true);
    if (cameraRef.current) {
      try {
        const resolutionInfo = await getOptimalCameraResolution(cameraRef.current);
        if (resolutionInfo) {
          setPictureSize(resolutionInfo.resolution);
          const displayText = `${formatMegapixels(resolutionInfo.megapixels)} (${resolutionInfo.resolution})`;
          setCameraResolutionInfo(displayText);
        }
      } catch (e) {
        console.warn('Failed to get optimal camera resolution:', e);
      }
    }
  };

  const facing = 'back';

  useEffect(() => {
    if (permission && !permission.granted && permission.canAskAgain) {
      setShowPermissionModal(true);
    }
  }, [permission]);

  const handleRequestPermission = async () => {
    setShowPermissionModal(false);
    const result = await requestPermission();
    if (!result.granted) {
      onClose();
    }
  };

  if (!permission?.granted) {
    return (
      <View style={styles.permissionContainer}>
        <CameraPermissionModal 
          visible={showPermissionModal}
          onClose={onClose}
          onConfirm={handleRequestPermission}
        />
        <Text style={styles.permissionText}>
          Camera access is required to take product photos.
        </Text>
        <TouchableOpacity
          style={styles.permissionButton}
          onPress={() => setShowPermissionModal(true)}
        >
          <Text style={styles.permissionButtonText}>Request Permission</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
          <Text style={styles.cancelButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const takePicture = async () => {
    if (isTakingPicture || !cameraRef.current || !cameraReady) return;
    try {
      setIsTakingPicture(true);
      if (Platform.OS === 'web') {
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      const options = { 
        quality: 1, 
        base64: Platform.OS === 'web',
        exif: true,
        skipProcessing: false,
      };
      const photo = await cameraRef.current.takePictureAsync(options);
      if (photo?.uri) {
        if (Platform.OS === 'web') {
          setCapturedPhoto(photo.uri);
        } else {
          const fileName = `photo-${Date.now()}.jpg`;
          const permanentUri = `${FileSystem.documentDirectory}${fileName}`;
          await FileSystem.copyAsync({ from: photo.uri, to: permanentUri });
          setCapturedPhoto(permanentUri);
        }
        setCameraMode('preview');
      }
    } catch (error) {
      console.error('Capture error:', error);
      Alert.alert('Error', 'Failed to capture photo.');
    } finally {
      setIsTakingPicture(false);
    }
  };

  const handleRetake = () => {
    setCapturedPhoto(null);
    setCameraMode('capture');
  };

  const handleDone = () => {
    if (capturedPhoto) {
      onPhotoCapture(capturedPhoto);
      onClose();
    }
  };

  const renderHeader = (title: string, leftIcon: React.ReactNode, onLeftPress: () => void) => (
    <View style={styles.header}>
      <TouchableOpacity onPress={onLeftPress} style={styles.closeButton}>
        {leftIcon}
      </TouchableOpacity>
      <View style={styles.headerTextContainer}>
        <Text style={styles.headerTitle}>{title}</Text>
        {cameraMode === 'capture' && cameraResolutionInfo ? (
          <Text style={styles.resolutionText}>{cameraResolutionInfo}</Text>
        ) : null}
      </View>
      <View style={styles.headerRightSpacer} />
    </View>
  );

  return (
    <Modal visible animationType="slide">
      <View style={styles.container}>
        {cameraMode === 'capture' ? (
          <>
            {renderHeader(
              isCompulsory ? 'Mandatory Photo' : 'Optional Photo',
              <X size={24} color="#fff" />,
              onClose
            )}
            <CameraView
              ref={cameraRef}
              style={styles.camera}
              facing={facing}
              zoom={0.01}
              autofocus="on"
              flash="auto"
              pictureSize={pictureSize}
              onCameraReady={handleCameraReady}
            />
            <View style={styles.controls}>
              <TouchableOpacity
                style={[
                  styles.captureButton,
                  (isTakingPicture || !cameraReady) && styles.disabledButton,
                ]}
                onPress={takePicture}
                disabled={isTakingPicture || !cameraReady}
              >
                {isTakingPicture ? (
                  <ActivityIndicator color="#007AFF" />
                ) : (
                  <View style={styles.captureButtonInner} />
                )}
              </TouchableOpacity>
            </View>
          </>
        ) : (
          <>
            {renderHeader(
              'Photo Preview',
              <RotateCcw size={24} color="#fff" />,
              handleRetake
            )}
            <View style={styles.previewContainer}>
              {capturedPhoto ? (
                <Image source={{ uri: capturedPhoto }} style={styles.previewImage} />
              ) : null}
            </View>
            <View style={styles.previewControls}>
              <TouchableOpacity
                style={[styles.actionButton, styles.retakeButton]}
                onPress={handleRetake}
              >
                <RotateCcw size={20} color="#fff" />
                <Text style={styles.actionButtonTextWhite}>Retake</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionButton, styles.doneButton]}
                onPress={handleDone}
              >
                <Check size={20} color="#000" />
                <Text style={styles.actionButtonTextBlack}>Done</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    paddingTop: height * 0.06,
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  headerTextContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    color: '#fff',
    fontSize: isSmallDevice ? 16 : 18,
    fontWeight: '600',
  },
  headerRightSpacer: {
    width: 40,
  },
  resolutionText: {
    color: '#FFD700',
    fontSize: isSmallDevice ? 12 : 14,
    fontWeight: '500',
    marginTop: 4,
  },
  closeButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  camera: { flex: 1 },
  controls: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledButton: { opacity: 0.5 },
  captureButtonInner: {
    width: 68,
    height: 68,
    borderRadius: 34,
    backgroundColor: '#007AFF',
  },
  previewContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  previewImage: {
    width: width,
    height: height * 0.75,
    resizeMode: 'contain',
  },
  previewControls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 30,
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: isSmallDevice ? 20 : 30,
    paddingVertical: isSmallDevice ? 12 : 15,
    borderRadius: 12,
    gap: 10,
  },
  retakeButton: { backgroundColor: '#2C2C2E' },
  doneButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E5EA',
  },
  actionButtonTextWhite: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  actionButtonTextBlack: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#000',
  },
  permissionText: {
    color: '#fff',
    fontSize: 18,
    marginBottom: 30,
    textAlign: 'center',
  },
  permissionButton: {
    backgroundColor: '#007AFF',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 10,
    marginBottom: 20,
  },
  permissionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  cancelButton: { padding: 10 },
  cancelButtonText: {
    color: '#999',
    fontSize: 16,
  },
});

export default ImageCapture;
