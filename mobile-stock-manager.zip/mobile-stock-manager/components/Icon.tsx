import React from 'react';
import { icons } from 'lucide-react-native';

interface IconProps {
  name: string;
  color: string;
  size: number;
}

const Icon: React.FC<IconProps> = ({ name, color, size }) => {
  const LucideIcon = icons[name];

  if (!LucideIcon) {
    return null;
  }

  return <LucideIcon color={color} size={size} />;
};

export default Icon;
