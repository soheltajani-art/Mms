
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const Card = ({ children, style }) => <View style={[styles.card, style]}>{children}</View>;
const CardHeader = ({ children, style }) => <View style={[styles.cardHeader, style]}>{children}</View>;
const CardTitle = ({ children, style }) => <Text style={[styles.cardTitle, style]}>{children}</Text>;
const CardDescription = ({ children, style }) => <Text style={[styles.cardDescription, style]}>{children}</Text>;
const CardContent = ({ children, style }) => <View style={[styles.cardContent, style]}>{children}</View>;

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardHeader: {
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cardDescription: {
    fontSize: 14,
    color: 'gray',
  },
  cardContent: {
  },
});

export { Card, CardHeader, CardTitle, CardDescription, CardContent };
