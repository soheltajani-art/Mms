
import React from 'react';
import { TouchableOpacity, View, StyleSheet } from 'react-native';
import { Check } from 'lucide-react-native';

interface CheckboxProps {
  id: string;
  checked: boolean;
  onValueChange: (value: boolean) => void;
  disabled?: boolean;
}

const Checkbox: React.FC<CheckboxProps> = ({ id, checked, onValueChange, disabled = false }) => {
  return (
    <TouchableOpacity 
      onPress={() => !disabled && onValueChange(!checked)}
      disabled={disabled}
    >
      <View style={[styles.checkbox, checked && styles.checked, disabled && styles.disabled]}>
        {checked && <Check color="white" size={16} />}
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: 'gray',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checked: {
    backgroundColor: 'blue',
    borderColor: 'blue',
  },
  disabled: {
    opacity: 0.5,
  },
});

export { Checkbox };
export type { CheckboxProps };
