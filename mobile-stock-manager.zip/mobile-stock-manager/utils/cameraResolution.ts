/**
 * Camera Resolution Utility
 * Provides functions to get the highest available camera resolution
 * Supports all devices from small phones to large tablets
 */

/**
 * Calculate megapixels from width and height
 */
export const calculateMegapixels = (width: number, height: number): number => {
  return (width * height) / 1_000_000;
};

/**
 * Parse resolution string (e.g., "4000x3000") to width and height
 */
export const parseResolution = (
  resolutionString: string
): { width: number; height: number } => {
  const [width, height] = resolutionString.split('x').map(Number);
  return { width, height };
};

/**
 * Get the highest resolution from available picture sizes
 * This function queries all available resolutions without aspect ratio restrictions
 * and selects the one with the highest megapixel count
 */
export const getHighestResolution = (
  sizes: string[] | undefined
): { resolution: string; megapixels: number } | null => {
  if (!sizes || sizes.length === 0) {
    return null;
  }

  let highestResolution = sizes[0];
  let highestMegapixels = 0;

  for (const size of sizes) {
    const { width, height } = parseResolution(size);
    const megapixels = calculateMegapixels(width, height);

    if (megapixels > highestMegapixels) {
      highestMegapixels = megapixels;
      highestResolution = size;
    }
  }

  return {
    resolution: highestResolution,
    megapixels: highestMegapixels,
  };
};

/**
 * Get camera resolution with fallback strategy
 * Tries multiple aspect ratios to ensure we get the best resolution available
 */
export const getOptimalCameraResolution = async (
  cameraRef: any
): Promise<{
  resolution: string | undefined;
  megapixels: number;
  aspectRatio: string;
} | null> => {
  if (!cameraRef) {
    return null;
  }

  // Try different aspect ratios in order of preference
  const aspectRatios = ['4:3', '16:9', '1:1', '3:2', '9:16'];
  let bestResult = null;
  let bestMegapixels = 0;

  for (const aspectRatio of aspectRatios) {
    try {
      const sizes = await cameraRef.getAvailablePictureSizesAsync(aspectRatio);

      if (sizes && sizes.length > 0) {
        const result = getHighestResolution(sizes);

        if (result && result.megapixels > bestMegapixels) {
          bestMegapixels = result.megapixels;
          bestResult = {
            resolution: result.resolution,
            megapixels: result.megapixels,
            aspectRatio,
          };
        }
      }
    } catch (error) {
      // Continue to next aspect ratio if this one fails
      console.warn(`Failed to get picture sizes for aspect ratio ${aspectRatio}:`, error);
    }
  }

  // If no specific aspect ratio worked, try getting all available sizes
  if (!bestResult) {
    try {
      const allSizes = await cameraRef.getAvailablePictureSizesAsync('4:3');
      if (allSizes && allSizes.length > 0) {
        const result = getHighestResolution(allSizes);
        if (result) {
          bestResult = {
            resolution: result.resolution,
            megapixels: result.megapixels,
            aspectRatio: '4:3',
          };
        }
      }
    } catch (error) {
      console.warn('Failed to get any picture sizes:', error);
    }
  }

  return bestResult;
};

/**
 * Format megapixels for display (e.g., "64 MP")
 */
export const formatMegapixels = (megapixels: number): string => {
  if (megapixels >= 1) {
    return `${Math.round(megapixels)} MP`;
  }
  return `${(megapixels * 1000).toFixed(0)} KP`;
};
