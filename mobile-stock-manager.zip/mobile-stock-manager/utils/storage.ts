
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Saves data to internal storage.
 * @param key The key to save the data under.
 * @param value The value to save.
 */
export const saveData = async (key: string, value: any): Promise<void> => {
  try {
    const jsonValue = JSON.stringify(value);
    await AsyncStorage.setItem(key, jsonValue);
  } catch (e) {
    // saving error
    console.error('Error saving data to async storage', e);
  }
};

/**
 * Gets data from internal storage.
 * @param key The key of the data to retrieve.
 * @returns The stored value, or null if it doesn't exist.
 */
export const getData = async (key: string): Promise<any | null> => {
  try {
    const jsonValue = await AsyncStorage.getItem(key);
    return jsonValue != null ? JSON.parse(jsonValue) : null;
  } catch (e) {
    // error reading value
    console.error('Error getting data from async storage', e);
    return null;
  }
};
