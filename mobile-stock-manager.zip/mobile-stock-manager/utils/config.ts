export const LEGAL_CONTACT_EMAIL = 'soheltajan@gmail.com';
export const GENERAL_CONTACT_EMAIL = 'soheltajan@gmail.com';
