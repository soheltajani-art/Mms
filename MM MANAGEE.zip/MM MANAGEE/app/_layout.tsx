import { Stack } from "expo-router";
import "../global.css";
import { useFonts } from "expo-font";
import * as SplashScreen from "expo-splash-screen";
import { useEffect } from "react";
import {
  DancingScript_400Regular,
  DancingScript_500Medium,
  DancingScript_600SemiBold,
  DancingScript_700Bold,
} from "@expo-google-fonts/dancing-script";


SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    SpaceMono: require("../assets/fonts/SpaceMono-Regular.ttf"),
    DancingScript_400Regular,
    DancingScript_500Medium,
    DancingScript_600SemiBold,
    DancingScript_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded]);

  if (!fontsLoaded) {
    return null;
  }

  return (
    <Stack>
      <Stack.Screen name="index" options={{ headerShown: false }} />
      <Stack.Screen name="Loading-screen" options={{ headerShown: false }} />
      <Stack.Screen name="WelcomePage" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="my-agreement" options={{ headerShown: false }} />
      <Stack.Screen name="privacy-policy" options={{ headerShown: false }} />
      <Stack.Screen name="user-agreement" options={{ headerShown: false }} />
      <Stack.Screen name="acceptable-use-policy" options={{ headerShown: false }} />
      <Stack.Screen name="disclaimer" options={{ headerShown: false }} />
      <Stack.Screen name="features" options={{ headerShown: false }} />
      <Stack.Screen name="available-stock" options={{ headerShown: false }} />
      <Stack.Screen name="sold-out-items" options={{ headerShown: false }} />
      <Stack.Screen name="lifetime-stats" options={{ headerShown: false }} />
      <Stack.Screen name="daily-performance" options={{ headerShown: false }} />
      <Stack.Screen name="reset-data" options={{ headerShown: false }} />

      <Stack.Screen name="todays-sales-report" options={{ headerShown: false }} />
      <Stack.Screen name="help-and-support" options={{ headerShown: false }} />
      <Stack.Screen name="how-it-works" options={{ headerShown: false }} />
      <Stack.Screen name="contact-support" options={{ headerShown: false }} />
      <Stack.Screen name="terms-and-conditions" options={{ headerShown: false }} />
      <Stack.Screen name="daily-performance-report" options={{ headerShown: false }} />
      <Stack.Screen name="todays-purchase-report" options={{ headerShown: false }} />
    </Stack>
  );
}
