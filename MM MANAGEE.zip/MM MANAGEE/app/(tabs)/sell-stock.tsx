import React, { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Alert, ActivityIndicator, Platform, KeyboardAvoidingView, Image, FlatList } from 'react-native';
import { Stack, useRouter, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { ChevronLeft, ScanLine, AlertCircle, CheckCircle2, IndianRupee, Smartphone, Calendar, Hash, Search, X } from 'lucide-react-native';
import { BarcodeScanner } from '../../components/BarcodeScanner';
import { sellStockItem, getAvailableStockByImei, searchAvailableStock, StockItem, getAvailableStock } from '../data/storage';

const InfoRow = ({ icon: Icon, label, value, color = '#666' }: any) => (
  <View style={styles.infoRow}>
    <View style={styles.infoLabelContainer}>
      <Icon size={16} color={color} style={styles.infoIcon} />
      <Text style={styles.infoLabel}>{label}</Text>
    </View>
    <Text style={styles.infoValue}>{value}</Text>
  </View>
);

export default function SellStock() {
  const router = useRouter();
  const params = useLocalSearchParams();
  
  const [searchQuery, setSearchQuery] = useState(params.imei || '');
  const [searchResults, setSearchResults] = useState<StockItem[]>([]);
  const [sellingPrice, setSellingPrice] = useState('');
  const [stockItem, setStockItem] = useState<StockItem | null>(null);

  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const [availableImeis, setAvailableImeis] = useState<string[]>([]);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      if (params.reset === 'true') {
        resetForm();
      }
    }, [params.reset])
  );

  const resetForm = () => {
    setSearchQuery('');
    setSearchResults([]);
    setSellingPrice('');
    setStockItem(null);
    setErrors({});
    setSearchError(null);
    setIsLoading(false);
  };

  useEffect(() => {
    if (params.imei) {
      handleImeiSearch(params.imei as string);
    }
  }, [params.imei]);

  const handleImeiSearch = async (imei: string) => {
    if (!imei || imei.length !== 15) {
      setSearchError('Please enter a valid 15-digit IMEI');
      setStockItem(null);
      return;
    }

    setIsLoading(true);
    setSearchError(null);
    try {
      const result = await getAvailableStockByImei(imei);
      if (result.item) {
        setStockItem(result.item);
        setSearchQuery(result.item.primaryImei);
        setSearchResults([]);
      } else {
        setSearchError(result.error || 'Product not found in available stock');
        setStockItem(null);
      }
    } catch (error) {
      console.error('Search failed:', error);
      setSearchError('An error occurred during search');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTextSearch = async (text: string) => {
    setSearchQuery(text);
    setStockItem(null);
    setSearchError(null);

    if (text.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    setIsLoading(true);
    try {
      const results = await searchAvailableStock(text);
      setSearchResults(results);
    } catch (error) {
      console.error('Text search failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const selectProduct = (item: StockItem) => {
    setStockItem(item);
    setSearchQuery(item.primaryImei);
    setSearchResults([]);
    setSearchError(null);
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!stockItem) newErrors.search = 'Please find a product first';
    if (!sellingPrice || isNaN(parseFloat(sellingPrice))) newErrors.sellingPrice = 'Valid selling price is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm() || !stockItem) return;

    setIsLoading(true);
    try {
      const purchasePrice = stockItem.purchaseCost || stockItem.buyingPrice || 0;
      await sellStockItem(stockItem.id, {
        sellingPrice: parseFloat(sellingPrice),
        customerName: '',
        customerContact: '',
        saleDate: new Date().toISOString(),
        customerPhoto: '',
      });
      
      router.push({
        pathname: '/sell-success',
        params: {
          model: stockItem.model || stockItem.modelNo,
          imei: stockItem.primaryImei,
          purchasePrice: purchasePrice.toString(),
          sellingPrice: sellingPrice,
          profit: (parseFloat(sellingPrice) - purchasePrice).toString(),
          sellDate: new Date().toISOString(),
        },
      });

    } catch (error) {
      console.error('Sell failed:', error);
      Alert.alert('Error', 'An unexpected error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBarcodeScanComplete = (imei1: string) => {
    setShowBarcodeScanner(false);
    handleImeiSearch(imei1);
  };

  const openScanner = async () => {
    try {
      const stock = await getAvailableStock();
      const imeis = stock.map(item => item.primaryImei);
      setAvailableImeis(imeis);
      setShowBarcodeScanner(true);
    } catch (error) {
      console.error('Failed to fetch available stock for scanner:', error);
      setShowBarcodeScanner(true);
    }
  };

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        <Stack.Screen options={{ headerShown: false }} />
        
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ChevronLeft size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Sell Product</Text>
          <View style={{ width: 24 }} />
        </View>

        <View style={styles.mainContent}>
          {/* Search Section */}
          <View style={styles.sectionCard}>
            <Text style={styles.sectionLabel}>FIND PRODUCT</Text>
            <View style={[styles.searchWrapper, focusedField === 'search' && styles.inputFocused, searchError && styles.inputError]}>
              <Search size={20} color="#666" style={styles.inputIcon} />
              <TextInput
                style={[styles.searchInput, Platform.OS === 'web' && { outline: 'none' } as any]}
                placeholder="Search by Name or IMEI"
                placeholderTextColor="#999"
                value={searchQuery}
                onChangeText={handleTextSearch}
                onFocus={() => setFocusedField('search')}
                onBlur={() => setFocusedField(null)}
              />
              {searchQuery.length > 0 && (
                <TouchableOpacity onPress={resetForm} style={styles.clearBtn}>
                  <X size={18} color="#999" />
                </TouchableOpacity>
              )}
            </View>
            
            <TouchableOpacity style={styles.scanBtn} onPress={openScanner}>
              <ScanLine size={20} color="#D32F2F" />
              <Text style={styles.scanBtnText}>Scan Barcode</Text>
            </TouchableOpacity>

            {/* Search Results Dropdown */}
            {searchResults.length > 0 && !stockItem && (
              <View style={styles.resultsContainer}>
                {searchResults.map((item) => (
                  <TouchableOpacity 
                    key={item.id} 
                    style={styles.resultItem}
                    onPress={() => selectProduct(item)}
                  >
                    <Smartphone size={18} color="#D32F2F" />
                    <View style={styles.resultTextContainer}>
                      <Text style={styles.resultModel}>{item.model || item.modelNo}</Text>
                      <Text style={styles.resultImei}>{item.primaryImei}</Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {searchError && (
              <View style={styles.errorBox}>
                <AlertCircle size={14} color="#D32F2F" />
                <Text style={styles.errorText}>{searchError}</Text>
              </View>
            )}
          </View>

          {isLoading && !stockItem && searchResults.length === 0 && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#D32F2F" />
              <Text style={styles.loadingText}>Searching Stock...</Text>
            </View>
          )}

          {/* Product Details Section */}
          {stockItem && (
            <View style={styles.detailsCard}>
              <View style={styles.successBadge}>
                <CheckCircle2 size={16} color="#2E7D32" />
                <Text style={styles.successBadgeText}>Product Selected</Text>
              </View>

              <Text style={styles.modelTitle}>{stockItem.model || stockItem.modelNo}</Text>
              
              <View style={styles.infoGrid}>
                <InfoRow icon={Smartphone} label="IMEI" value={stockItem.primaryImei} color="#D32F2F" />
                <InfoRow icon={IndianRupee} label="Purchase Price" value={`₹${stockItem.purchaseCost || stockItem.buyingPrice}`} color="#2E7D32" />
                <InfoRow icon={Calendar} label="Purchase Date" value={new Date(stockItem.purchaseDate).toLocaleDateString()} color="#1976D2" />
              </View>

              {stockItem.compulsoryPhoto && (
                <View style={styles.photoPreviewContainer}>
                  <Text style={styles.photoLabel}>Photo Documentation</Text>
                  <Image source={{ uri: stockItem.compulsoryPhoto }} style={styles.productImage} />
                </View>
              )}

              <View style={styles.divider} />

              <Text style={styles.sectionLabel}>SALE INFORMATION</Text>
              
              <View style={styles.priceInputWrapper}>
                <Text style={styles.priceLabel}>SELLING PRICE</Text>
                <View style={[styles.priceInputBox, errors.sellingPrice && styles.inputError, focusedField === 'sellingPrice' && styles.inputFocused]}>
                  <IndianRupee size={20} color="#666" />
                  <TextInput
                    style={[styles.priceInput, Platform.OS === 'web' && { outline: 'none' } as any]}
                    placeholder="0.00"
                    placeholderTextColor="#999"
                    keyboardType="numeric"
                    value={sellingPrice}
                    onChangeText={setSellingPrice}
                    onFocus={() => setFocusedField('sellingPrice')}
                    onBlur={() => setFocusedField(null)}
                  />
                </View>
                {errors.sellingPrice && <Text style={styles.errorText}>{errors.sellingPrice}</Text>}
              </View>

              <TouchableOpacity 
                style={[styles.submitBtn, isLoading && styles.submitBtnDisabled]} 
                onPress={handleSubmit}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <Text style={styles.submitBtnText}>Complete Sale</Text>
                    <CheckCircle2 size={20} color="#fff" />
                  </>
                )}
              </TouchableOpacity>
            </View>
          )}
        </View>

        <BarcodeScanner 
          isVisible={showBarcodeScanner} 
          onScan={handleBarcodeScanComplete} 
          onClose={() => setShowBarcodeScanner(false)} 
          allowedBarcodes={availableImeis}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFEBEE' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  headerTitle: { fontSize: 20, fontWeight: 'bold', color: '#000' },
  mainContent: { paddingHorizontal: 20 },
  sectionCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#FFCDD2',
    shadowColor: '#D32F2F',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 4,
  },
  sectionLabel: {
    fontSize: 12,
    fontWeight: '800',
    color: '#D32F2F',
    letterSpacing: 1.5,
    marginBottom: 12,
  },
  searchWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    height: 50,
  },
  inputIcon: { marginRight: 10 },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#1F2937',
    fontWeight: '500',
  },
  clearBtn: { padding: 4 },
  scanBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFEBEE',
    borderRadius: 12,
    padding: 12,
    marginTop: 12,
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: '#D32F2F',
  },
  scanBtnText: {
    marginLeft: 8,
    color: '#D32F2F',
    fontWeight: '600',
    fontSize: 14,
  },
  resultsContainer: {
    marginTop: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    overflow: 'hidden',
    maxHeight: 200,
  },
  resultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  resultTextContainer: { marginLeft: 12 },
  resultModel: { fontSize: 14, fontWeight: '600', color: '#1F2937' },
  resultImei: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  detailsCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: '#C8E6C9',
    shadowColor: '#2E7D32',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 4,
  },
  successBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: 'flex-start',
    marginBottom: 16,
  },
  successBadgeText: {
    marginLeft: 6,
    fontSize: 12,
    fontWeight: '700',
    color: '#2E7D32',
  },
  modelTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: '#1F2937',
    marginBottom: 20,
  },
  infoGrid: { gap: 12 },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  infoLabelContainer: { flexDirection: 'row', alignItems: 'center' },
  infoIcon: { marginRight: 8 },
  infoLabel: { fontSize: 14, color: '#6B7280', fontWeight: '500' },
  infoValue: { fontSize: 14, color: '#1F2937', fontWeight: '700' },
  photoPreviewContainer: { marginTop: 20 },
  photoLabel: { fontSize: 12, fontWeight: '700', color: '#6B7280', marginBottom: 8 },
  productImage: { width: '100%', height: 200, borderRadius: 12, resizeMode: 'cover' },
  divider: { height: 1, backgroundColor: '#E5E7EB', marginVertical: 24 },
  priceInputWrapper: { marginBottom: 24 },
  priceLabel: { fontSize: 12, fontWeight: '800', color: '#6B7280', letterSpacing: 1, marginBottom: 8 },
  priceInputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    height: 56,
  },
  priceInput: {
    flex: 1,
    fontSize: 20,
    fontWeight: '700',
    color: '#1F2937',
    marginLeft: 8,
  },
  inputFocused: { borderColor: '#D32F2F', backgroundColor: '#FFF' },
  inputError: { borderColor: '#D32F2F' },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFEBEE',
    padding: 10,
    borderRadius: 8,
    marginTop: 12,
  },
  errorText: { marginLeft: 8, color: '#D32F2F', fontSize: 12, fontWeight: '600' },
  loadingContainer: { alignItems: 'center', padding: 40 },
  loadingText: { marginTop: 12, color: '#6B7280', fontWeight: '500' },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#D32F2F',
    borderRadius: 16,
    height: 56,
    shadowColor: '#D32F2F',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  submitBtnDisabled: { opacity: 0.6 },
  submitBtnText: { color: '#fff', fontSize: 18, fontWeight: '700', marginRight: 8 },
});
