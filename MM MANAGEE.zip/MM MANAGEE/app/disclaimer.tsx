import { useRouter } from 'expo-router';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { ChevronLeft, Info } from 'lucide-react-native';

export default function Disclaimer() {
  const router = useRouter();

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Disclaimer</Text>
        <View style={{ width: 24 }} />
      </View>

      <Card style={styles.card}>
        <CardHeader>
          <CardTitle style={styles.cardTitle}>
            Mobile Stock Manager [Special Edition] Disclaimer
          </CardTitle>
          <Text style={styles.subTitle}>
            This app is provided “as-is”, without any warranties.
          </Text>
        </CardHeader>

        <CardContent>

          <View style={styles.noticeBox}>
            <Info size={24} color="#007AFF" style={styles.noticeIcon} />
            <View style={styles.noticeTextContainer}>
              <Text style={styles.noticeTitle}>Important Notice</Text>
              <Text style={styles.noticeText}>
                Some features may be under development and will be added in future updates. By using this app, you accept this condition.
              </Text>
            </View>
          </View>

          <Text style={styles.sectionTitle}>1. No Warranty</Text>
          <Text style={styles.bulletPoint}>• The app is provided “as-is” without any guarantees.</Text>
          <Text style={styles.bulletPoint}>• The app may contain bugs or errors.</Text>
          <Text style={styles.bulletPoint}>• It may not meet all user requirements.</Text>

          <Text style={styles.sectionTitle}>2. Limitation of Liability</Text>
          <Text style={styles.bulletPoint}>
            • The developer is not responsible for any loss of data, profits, or business resulting from use of the app.
          </Text>
          <Text style={styles.bulletPoint}>• You use the app at your own risk.</Text>

          <Text style={styles.sectionTitle}>3. App Quality and Testing</Text>
          <Text style={styles.bulletPoint}>
            • This app was developed with great attention to detail and has been thoroughly tested.
          </Text>
          <Text style={styles.bulletPoint}>
            • However, in the event of errors leading to data loss or other issues, the developer and owner are not liable for any damages.
          </Text>

          <Text style={styles.sectionTitle}>4. Data Responsibility</Text>
          <Text style={styles.bulletPoint}>
            • Only stock-related data is stored locally on your device.
          </Text>
          <Text style={styles.bulletPoint}>
            • No personal or sensitive user data is collected or stored.
          </Text>

          <Text style={styles.sectionTitle}>5. Reset Function</Text>
          <Text style={styles.bulletPoint}>
            • The reset function permanently deletes all stored data and cannot be undone.
          </Text>

          <Text style={styles.sectionTitle}>6. Service Changes</Text>
          <Text style={styles.bulletPoint}>
            • Features, pricing, or availability may change at any time without notice.
          </Text>

          <Text style={styles.sectionTitle}>7. Contact Information</Text>
          <Text style={styles.paragraph}>For support or feedback:</Text>
          <Text style={styles.paragraph}>soheltajani@gmail.com</Text>

          <Text style={styles.footerText}>
            By using Mobile Stock Manager [Special Edition], you agree to this disclaimer.
          </Text>

        </CardContent>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  card: {
    margin: 16,
    marginTop: 0,
    borderRadius: 20,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subTitle: {
    fontSize: 16,
    color: '#6C757D',
    marginBottom: 16,
  },
  noticeBox: {
    backgroundColor: '#E7F3FF',
    borderRadius: 20,
    padding: 16,
    marginVertical: 16,
    flexDirection: 'row',
  },
  noticeIcon: {
    marginRight: 12,
  },
  noticeTextContainer: {
    flex: 1,
  },
  noticeTitle: {
    fontWeight: 'bold',
    color: '#007AFF',
    marginBottom: 4,
  },
  noticeText: {
    color: '#007AFF',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  paragraph: {
    fontSize: 16,
    lineHeight: 24,
    color: '#495057',
    marginBottom: 4,
  },
  bulletPoint: {
    fontSize: 16,
    lineHeight: 24,
    color: '#495057',
    marginBottom: 8,
  },
  footerText: {
    marginTop: 24,
    fontSize: 14,
    textAlign: 'center',
    color: '#6C757D',
  },
});