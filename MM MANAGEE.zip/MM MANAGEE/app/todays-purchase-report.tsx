
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, FlatList, SafeAreaView, Platform } from 'react-native';
import { ChevronLeft, Search, Box, X } from 'lucide-react-native';
import { useRouter, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { getHistory, HistoryItem, getLocalDateString, extractLocalDateFromISO } from './data/storage';
import { PhotoPreview } from '../components/PhotoPreview';
import ProductCard from './components/ProductCard';
import { BlurView } from 'expo-blur';

const TodaysPurchaseReport = () => {
  const router = useRouter();
  const [allPurchases, setAllPurchases] = useState<HistoryItem[]>([]);
  const [purchases, setPurchases] = useState<HistoryItem[]>([]);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [allDataLoaded, setAllDataLoaded] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState<string | undefined>(undefined);
  const params = useLocalSearchParams();
  const { date } = params;
  const PURCHASES_PER_PAGE = 20;

  const fetchTodaysPurchases = useCallback(async () => {
    const history = await getHistory();
    const targetDate = date ? new Date(date as string) : new Date();
    const targetDateString = getLocalDateString(targetDate);

    const purchasesForDate = history.filter(item => {
        if (item.type === 'PURCHASE' && item.purchaseDate) {
            const purchaseDateString = extractLocalDateFromISO(item.purchaseDate);
            return purchaseDateString === targetDateString;
        }
        return false;
    });
    setAllPurchases(purchasesForDate);
    setPage(1);
    setAllDataLoaded(false);
    setPurchases([]);
    setSearchQuery('');
  }, [date]);

  useFocusEffect(
    useCallback(() => {
      fetchTodaysPurchases();
    }, [fetchTodaysPurchases])
  );

  const filteredPurchases = allPurchases.filter(purchase => {
    if (!searchQuery.trim()) return true;
    
    const query = searchQuery.trim().toLowerCase();
    const modelMatch = purchase.model?.toLowerCase().includes(query) ?? false;
    const imeiMatch = purchase.primaryImei?.includes(query) ?? false;
    
    return modelMatch || imeiMatch;
  });

  useEffect(() => {
    if (allDataLoaded) return;
    const newPurchases = filteredPurchases.slice((page - 1) * PURCHASES_PER_PAGE, page * PURCHASES_PER_PAGE);
    if (newPurchases.length > 0) {
      if (page === 1) {
        setPurchases(newPurchases);
      } else {
        setPurchases(prevPurchases => [...prevPurchases, ...newPurchases]);
      }
    } else {
      if (page === 1) {
        setPurchases([]);
      }
      setAllDataLoaded(true);
    }
  }, [page, filteredPurchases, allDataLoaded]);

  useEffect(() => {
    setPage(1);
    setAllDataLoaded(false);
  }, [searchQuery]);

  const handleLoadMore = () => {
    if (!allDataLoaded) {
      setPage(prevPage => prevPage + 1);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setFocusedField(null);
  };

  const renderFooter = () => {
    if (allDataLoaded && purchases.length > 0) {
      return <Text style={styles.endOfListText}>End of purchase list</Text>;
    }
    return null;
  };

  const handleViewPhoto = (photoUri: string | undefined) => {
    if (photoUri) {
      setPreviewPhotoUri(photoUri);
      setShowPhotoPreview(true);
    }
  };

  const headerTitle = date
    ? `Purchases on ${new Date(date as string).toLocaleDateString()}`
    : "Today's Purchase Report";

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{headerTitle}</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Search Bar */}
      <View style={[styles.searchContainer, focusedField === 'search' && styles.searchContainerFocused]}>
        <Search size={20} color={focusedField === 'search' ? '#8A2BE2' : '#909090'} style={styles.searchIcon} />
        <TextInput
          placeholder="Search by model or IMEI..."
          placeholderTextColor="#909090"
          style={[
            styles.searchInput,
            Platform.OS === 'web' && { outline: 'none' } as any
          ]}
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => setFocusedField('search')}
          onBlur={() => setFocusedField(null)}
        />
        {searchQuery ? (
          <TouchableOpacity onPress={handleClearSearch} style={styles.clearButton}>
            <X size={18} color="#909090" />
          </TouchableOpacity>
        ) : null}
      </View>

      <View style={styles.infoRow}>
        <View style={styles.itemsAvailableContainer}>
          <Text style={styles.itemsAvailable}>{filteredPurchases.length} ITEMS PURCHASED</Text>
        </View>
        {searchQuery.length > 0 && (
          <Text style={styles.searchHint}>Search active</Text>
        )}
      </View>

      <View style={styles.contentWrapper}>
        <FlatList
            data={purchases}
            renderItem={({ item }) => (
              <ProductCard 
                item={item} 
                onViewPhoto={handleViewPhoto} 
                isAvailable={true} 
              />
            )}
            keyExtractor={item => item.id}
            onEndReached={handleLoadMore}
            onEndReachedThreshold={0.5}
            ListFooterComponent={renderFooter}
            contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24, flexGrow: 1 }}
            ListEmptyComponent={(
              <View style={styles.emptyStateContainer}>
                <View style={styles.iconBackground}>
                  <Box size={48} color="#8A2BE2" />
                </View>
                <Text style={styles.emptyStateTitle}>
                  {searchQuery.length > 0 ? 'NO MATCHES FOUND' : 'NO PURCHASES TODAY'}
                </Text>
                <Text style={styles.emptyStateSubtitle}>
                  {searchQuery.length > 0
                    ? "We couldn't find any purchases matching your search."
                    : 'There have been no purchases recorded for this day yet.'}
                </Text>
              </View>
            )}
          />
      </View>

      <PhotoPreview
        isVisible={showPhotoPreview}
        photoUri={previewPhotoUri}
        onClose={() => setShowPhotoPreview(false)}
        allowRetake={false}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    marginHorizontal: 12,
    marginBottom: 12,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    marginHorizontal: 12,
    paddingHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  searchContainerFocused: {
    borderColor: '#1565C0',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
    marginRight: 12,
  },
  clearButton: {
    padding: 8,
    marginLeft: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    fontSize: 14,
    color: '#000',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 12,
    marginTop: 12,
    marginBottom: 12,
  },
  itemsAvailableContainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 2,
    elevation: 1,
  },
  itemsAvailable: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#1565C0',
    letterSpacing: 0.3,
  },
  searchHint: {
    fontSize: 9,
    color: '#666',
    fontStyle: 'italic',
  },
  emptyStateContainer: {
    flex: 1,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBackground: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1.5,
    borderColor: '#1565C0',
  },
  emptyStateTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1565C0',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtitle: {
    fontSize: 14,
    color: '#1565C0',
    textAlign: 'center',
    lineHeight: 20,
  },
  endOfListText: {
    textAlign: 'center',
    padding: 12,
    fontSize: 12,
    color: '#888',
  },
});

export default TodaysPurchaseReport;
