import * as SQLite from 'expo-sqlite';
import { Platform } from 'react-native';

let db: SQLite.SQLiteDatabase | null = null;

/**
 * Initialize the SQLite database and create tables if they don't exist.
 */
export const initializeDatabase = async (): Promise<SQLiteDatabase> => {
  if (db) {
    return db;
  }

  try {
    db = await SQLite.openDatabaseAsync('stock_manager.db');
    console.log('Database opened successfully');

    // Create tables if they don't exist
    await db.execAsync(`
      CREATE TABLE IF NOT EXISTS stock (
        id TEXT PRIMARY KEY,
        name TEXT,
        status TEXT,
        model TEXT,
        modelNo TEXT,
        inventory INTEGER,
        primaryImei TEXT UNIQUE,
        purchaseCost REAL,
        buyingPrice REAL,
        mopValue REAL,
        frontImage TEXT,
        backImage TEXT,
        purchaseDate TEXT,
        sellingPrice REAL,
        soldDate TEXT,
        compulsoryPhoto TEXT,
        optionalPhoto TEXT,
        type TEXT
      );

      CREATE TABLE IF NOT EXISTS history (
        id TEXT,
        type TEXT,
        model TEXT,
        primaryImei TEXT,
        purchaseCost REAL,
        mopValue REAL,
        sellingPrice REAL,
        profit REAL,
        purchaseDate TEXT,
        soldDate TEXT,
        timestamp TEXT,
        compulsoryPhoto TEXT,
        optionalPhoto TEXT
      );

      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
      );
    `);

    console.log('Database tables created successfully');
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

/**
 * Get the database instance.
 */
export const getDatabase = async (): Promise<SQLiteDatabase> => {
  if (!db) {
    return initializeDatabase();
  }
  return db;
};

/**
 * Close the database connection.
 */
export const closeDatabase = async (): Promise<void> => {
  if (db) {
    try {
      await db.closeAsync();
      db = null;
      console.log('Database closed successfully');
    } catch (error) {
      console.error('Failed to close database:', error);
    }
  }
};

/**
 * Clear all data from the database (for reset functionality).
 */
export const clearAllData = async (): Promise<void> => {
  try {
    const database = await getDatabase();
    await database.execAsync(`
      DELETE FROM stock;
      DELETE FROM history;
      DELETE FROM settings;
    `);
    console.log('All database data cleared successfully');
  } catch (error) {
    console.error('Failed to clear database data:', error);
    throw error;
  }
};

/**
 * Save a setting key-value pair.
 */
export const saveSetting = async (key: string, value: string): Promise<void> => {
  try {
    const database = await getDatabase();
    await database.runAsync(
      `INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)`,
      [key, value]
    );
  } catch (error) {
    console.error(`Failed to save setting ${key}:`, error);
    throw error;
  }
};

/**
 * Get a setting value by key.
 */
export const getSetting = async (key: string): Promise<string | null> => {
  try {
    const database = await getDatabase();
    const result = await database.getFirstAsync<{ value: string }>(
      `SELECT value FROM settings WHERE key = ?`,
      [key]
    );
    return result ? result.value : null;
  } catch (error) {
    console.error(`Failed to get setting ${key}:`, error);
    return null;
  }
};

/**
 * Remove a setting by key.
 */
export const removeSetting = async (key: string): Promise<void> => {
  try {
    const database = await getDatabase();
    await database.runAsync(`DELETE FROM settings WHERE key = ?`, [key]);
  } catch (error) {
    console.error(`Failed to remove setting ${key}:`, error);
    throw error;
  }
};

/**
 * Type definition for SQLiteDatabase
 */
export type SQLiteDatabase = SQLite.SQLiteDatabase;
