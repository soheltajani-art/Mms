import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, SafeAreaView, Platform } from 'react-native';
import { ChevronLeft, Package, PackageMinus, RefreshCw, Box, FileText, Settings, ChevronRight, Trash2, Search, Save, ListRestart, HelpCircle, X } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { BlurView } from 'expo-blur';

const FeaturesPage = () => {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const features = [
    {
      id: 'available-stock',
      category: 'INVENTORY MANAGEMENT',
      icon: <Package size={24} color="#1565C0" />,
      title: 'Available Stock',
      description: 'Real-time view of all items currently in your warehouse.',
      theme: 'blue',
      route: '/available-stock',
      keywords: ['stock', 'inventory', 'available', 'products', 'warehouse'],
    },
    {
      id: 'sold-items',
      category: 'INVENTORY MANAGEMENT',
      icon: <PackageMinus size={24} color="#C62828" />,
      title: 'Sold Out Items',
      description: 'Track products that are out of stock and need restocking.',
      theme: 'red',
      route: '/sold-out-items',
      keywords: ['sold', 'out', 'items', 'history', 'sold out'],
    },
    {
      id: 'daily-performance',
      category: 'ANALYTICS & REPORTS',
      icon: <RefreshCw size={24} color="#1565C0" />,
      title: 'Previous Performance',
      description: 'Get an overview of your performance for a selected date.',
      theme: 'blue',
      route: '/daily-performance',
      keywords: ['daily', 'performance', 'analytics', 'report', 'stats', 'previous'],
    },
    {
      id: 'lifetime-history',
      category: 'ANALYTICS & REPORTS',
      icon: <Box size={24} color="#1E8449" />,
      title: 'Lifetime History',
      description: 'Comprehensive history of your business growth over time.',
      theme: 'green',
      route: '/lifetime-stats',
      keywords: ['lifetime', 'history', 'analytics', 'growth', 'business'],
    },
    {
      id: 'previous-calculation-report',
      category: 'ANALYTICS & REPORTS',
      icon: <FileText size={24} color="#1565C0" />,
      title: 'Previous Calculation Report',
      description: 'View calculation reports for any specific past date.',
      theme: 'blue',
      route: '/previous-calculation-report',
      keywords: ['calculation', 'report', 'previous', 'history', 'profit', 'date'],
    },
    {
      id: 'legal-agreements',
      category: 'SYSTEM & LEGAL',
      icon: <FileText size={24} color="#F9A825" />,
      title: 'Legal Agreements',
      description: 'Review terms of service and privacy policies.',
      theme: 'yellow',
      route: '/my-agreement',
      keywords: ['legal', 'agreement', 'terms', 'privacy', 'policy'],
    },

    {
      id: 'reset-data',
      category: 'SYSTEM & LEGAL',
      icon: <Trash2 size={24} color="#B71C1C" />,
      title: 'Reset All Data',
      description: 'Permanently deletes all app data. This action cannot be undone.',
      theme: 'dangerRed',
      route: '/reset-data',
      keywords: ['reset', 'delete', 'data', 'clear', 'danger'],
    },
    {
      id: 'help-and-support',
      category: 'SUPPORT',
      icon: <HelpCircle size={24} color="#1565C0" />,
      title: 'Help & Support',
      description: 'Get help and support from our team.',
      theme: 'blue',
      route: '/help-and-support',
      keywords: ['help', 'support', 'contact', 'customer service'],
    },
  ];

  const filteredFeatures = searchQuery.trim() === '' 
    ? features 
    : features.filter(feature =>
        feature.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        feature.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        feature.keywords.some(keyword => keyword.includes(searchQuery.toLowerCase()))
      );

  const groupedFeatures = filteredFeatures.reduce((acc, feature) => {
    const category = feature.category;
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(feature);
    return acc;
  }, {} as Record<string, typeof features>);

  const handleClearSearch = () => {
    setSearchQuery('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Features</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Search Bar */}
      <View style={[styles.searchContainer, focusedField === 'search' && styles.searchContainerFocused]}>
        <Search size={20} color={focusedField === 'search' ? '#1565C0' : '#909090'} style={styles.searchIcon} />
        <TextInput
          placeholder="Search features..."
          placeholderTextColor="#909090"
          style={[
            styles.searchInput,
            Platform.OS === 'web' && { outline: 'none' } as any
          ]}
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => setFocusedField('search')}
          onBlur={() => setFocusedField(null)}
        />
        {searchQuery ? (
          <TouchableOpacity onPress={handleClearSearch} style={styles.clearButton}>
            <X size={18} color="#909090" />
          </TouchableOpacity>
        ) : null}
      </View>

      <View style={styles.contentWrapper}>
        <ScrollView contentContainerStyle={styles.contentContainer}>
          {Object.entries(groupedFeatures).length > 0 ? (
            Object.entries(groupedFeatures).map(([category, categoryFeatures]) => (
              <View key={category} style={styles.section}>
                <Text style={styles.sectionTitle}>{category}</Text>
                {categoryFeatures.map((feature) => (
                  <FeatureCard
                    key={feature.id}
                    icon={feature.icon}
                    title={feature.title}
                    description={feature.description}
                    theme={feature.theme}
                    onPress={() => router.push(feature.route)}
                  />
                ))}
              </View>
            ))
          ) : (
            <View style={styles.emptyStateContainer}>
              <View style={styles.emptyIconBackground}>
                <Search size={48} color="#999" />
              </View>
              <Text style={styles.emptyStateTitle}>No Features Found</Text>
              <Text style={styles.emptyStateSubtitle}>
                Try adjusting your search terms to find what you're looking for.
              </Text>
            </View>
          )}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

const FeatureCard = ({ icon, title, description, theme = 'blue', onPress }: any) => {
  let wrapperStyle, cardStyle, titleColor, descriptionColor, chevronColor, iconBgColor;

  switch (theme) {
    case 'red':
      wrapperStyle = styles.redSpecialCardWrapper;
      cardStyle = styles.redSpecialCard;
      titleColor = '#C62828';
      descriptionColor = '#D32F2F';
      chevronColor = '#C62828';
      iconBgColor = 'rgba(255, 235, 238, 0.6)';
      break;
    case 'green':
      wrapperStyle = styles.greenSpecialCardWrapper;
      cardStyle = styles.greenSpecialCard;
      titleColor = '#1E8449';
      descriptionColor = '#145A32';
      chevronColor = '#1E8449';
      iconBgColor = 'rgba(232, 248, 245, 0.6)';
      break;
    case 'yellow':
      wrapperStyle = styles.yellowSpecialCardWrapper;
      cardStyle = styles.yellowSpecialCard;
      titleColor = '#F9A825';
      descriptionColor = '#FBC02D';
      chevronColor = '#F9A825';
      iconBgColor = 'rgba(255, 253, 227, 0.6)';
      break;
    case 'dangerRed':
      wrapperStyle = styles.dangerRedSpecialCardWrapper;
      cardStyle = styles.dangerRedSpecialCard;
      titleColor = '#B71C1C';
      descriptionColor = '#C62828';
      chevronColor = '#B71C1C';
      iconBgColor = 'rgba(255, 205, 210, 0.95)';
      break;
    case 'grey':
      wrapperStyle = styles.greySpecialCardWrapper;
      cardStyle = styles.greySpecialCard;
      titleColor = '#37474F';
      descriptionColor = '#546E7A';
      chevronColor = '#37474F';
      iconBgColor = 'rgba(236, 239, 241, 0.95)';
      break;
    case 'lightGreen':
      wrapperStyle = styles.lightGreenSpecialCardWrapper;
      cardStyle = styles.lightGreenSpecialCard;
      titleColor = '#388E3C';
      descriptionColor = '#66BB6A';
      chevronColor = '#388E3C';
      iconBgColor = 'rgba(200, 230, 201, 0.6)';
      break;
    default: // blue
      wrapperStyle = styles.blueSpecialCardWrapper;
      cardStyle = styles.blueSpecialCard;
      titleColor = '#0D47A1';
      descriptionColor = '#1A237E';
      chevronColor = '#0D47A1';
      iconBgColor = 'rgba(227, 242, 253, 0.6)';
      break;
  }

  return (
    <TouchableOpacity onPress={onPress} style={[styles.specialCardWrapper, wrapperStyle]}>
      <BlurView intensity={95} tint="light" style={[styles.specialCard, cardStyle]}>
        <View style={[styles.iconContainer, { backgroundColor: iconBgColor }]}>
          {icon}
        </View>
        <View style={styles.textContainer}>
          <Text style={[styles.cardTitle, { color: titleColor, fontWeight: 'bold' }]}>{title}</Text>
          <Text style={[styles.cardDescription, { color: descriptionColor, fontWeight: '500' }]}>{description}</Text>
        </View>
        <ChevronRight size={20} color={chevronColor} />
      </BlurView>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginTop: 12,
    overflow: 'hidden',
    marginHorizontal: 12,
    marginBottom: 12,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    marginTop: 12,
    marginHorizontal: 12,
    borderRadius: 16,
    paddingHorizontal: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  searchContainerFocused: {
    borderColor: '#1565C0',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    fontSize: 14,
    color: '#000',
  },
  clearButton: {
    padding: 8,
    marginLeft: 8,
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 24,
  },
  section: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#666666',
    marginBottom: 12,
    marginLeft: 8,
    letterSpacing: 0.3,
  },
  specialCardWrapper: {
    borderRadius: 16,
    marginBottom: 12,
  },
  blueSpecialCardWrapper: {
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  redSpecialCardWrapper: {
    shadowColor: '#C62828',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  greenSpecialCardWrapper: {
    shadowColor: '#1E8449',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  yellowSpecialCardWrapper: {
    shadowColor: '#F9A825',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  dangerRedSpecialCardWrapper: {
    shadowColor: '#B71C1C',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
  },
  greySpecialCardWrapper: {
    shadowColor: '#455A64',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  lightGreenSpecialCardWrapper: {
    shadowColor: '#66BB6A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  specialCard: {
    borderRadius: 16,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  blueSpecialCard: {
    backgroundColor: 'rgba(227, 242, 253, 0.9)',
  },
  redSpecialCard: {
    backgroundColor: 'rgba(255, 235, 238, 0.9)',
  },
  greenSpecialCard: {
    backgroundColor: 'rgba(232, 248, 245, 0.9)',
  },
  yellowSpecialCard: {
    backgroundColor: 'rgba(255, 253, 227, 0.9)',
  },
  dangerRedSpecialCard: {
    backgroundColor: 'rgba(255, 205, 210, 0.95)',
  },
  greySpecialCard: {
    backgroundColor: 'rgba(236, 239, 241, 0.95)',
  },
  lightGreenSpecialCard: {
    backgroundColor: 'rgba(200, 230, 201, 0.9)',
  },
  iconContainer: {
    padding: 8,
    borderRadius: 999,
    marginRight: 12,
  },
  textContainer: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000000',
  },
  cardDescription: {
    fontSize: 12,
    color: '#666666',
    marginTop: 2,
  },
  emptyStateContainer: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
  },
  emptyIconBackground: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#F0F0F0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#DDD',
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 12,
  },
  emptyStateSubtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    lineHeight: 20,
  },
});

export default FeaturesPage;