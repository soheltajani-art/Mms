
import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, SafeAreaView, StatusBar } from 'react-native';
import { ChevronLeft, TrendingUp, DollarSign, Package } from 'lucide-react-native';
import { useRouter, useFocusEffect, Stack } from 'expo-router';
import { getSoldStock, StockItem } from './data/storage';

const CalculationReportPage = () => {
  const router = useRouter();
  const [soldProducts, setSoldProducts] = useState<StockItem[]>([]);
  const [totals, setTotals] = useState({
    buying: 0,
    selling: 0,
    profit: 0
  });

  useFocusEffect(
    useCallback(() => {
      const fetchSoldStock = async () => {
        const stock = await getSoldStock();
        setSoldProducts(stock);
        
        const calcTotals = stock.reduce((acc, item) => {
          const buy = item.purchaseCost || item.buyingPrice || 0;
          const sell = item.sellingPrice || 0;
          return {
            buying: acc.buying + buy,
            selling: acc.selling + sell,
            profit: acc.profit + (sell - buy)
          };
        }, { buying: 0, selling: 0, profit: 0 });
        
        setTotals(calcTotals);
      };
      fetchSoldStock();
    }, [])
  );

  const renderItem = ({ item, index }: { item: StockItem; index: number }) => {
    const buyPrice = item.purchaseCost || item.buyingPrice || 0;
    const sellPrice = item.sellingPrice || 0;
    const profit = sellPrice - buyPrice;

    return (
      <View style={styles.productRow}>
        <View style={styles.productHeader}>
          <Text style={styles.productIndex}>{index + 1}</Text>
          <Text style={styles.productName} numberOfLines={1}>{item.model || item.name || 'Unknown'}</Text>
        </View>
        
        <View style={styles.productDetails}>
          <View style={styles.detailCol}>
            <Text style={styles.detailLabel}>BUYING</Text>
            <Text style={styles.detailValue}>₹{buyPrice.toLocaleString()}</Text>
          </View>
          <View style={styles.detailCol}>
            <Text style={styles.detailLabel}>SELLING</Text>
            <Text style={styles.detailValue}>₹{sellPrice.toLocaleString()}</Text>
          </View>
          <View style={styles.detailCol}>
            <Text style={styles.detailLabel}>PROFIT</Text>
            <Text style={[styles.detailValue, { color: profit >= 0 ? '#1565C0' : '#C62828' }]}>
              ₹{profit.toLocaleString()}
            </Text>
          </View>
        </View>
        
        <View style={styles.imeiContainer}>
          <Text style={styles.imeiLabel}>IMEI:</Text>
          <Text style={styles.imeiValue}>{item.primaryImei}</Text>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar barStyle="dark-content" />
      
      {/* Custom Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Calculation Report</Text>
        <View style={{ width: 40 }} />
      </View>

      <FlatList
        data={soldProducts}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Package size={48} color="#ccc" />
            <Text style={styles.emptyText}>NO SOLD PRODUCTS YET</Text>
          </View>
        }
      />

      <View style={styles.footer}>
        <View style={styles.footerHeader}>
          <TrendingUp size={20} color="#1565C0" />
          <Text style={styles.footerTitle}>{soldProducts.length} PRODUCTS SOLD</Text>
        </View>
        
        <View style={styles.footerStats}>
          <View style={styles.footerStatItem}>
            <Text style={styles.footerStatLabel}>TOTAL BUYING</Text>
            <Text style={styles.footerStatValue}>₹{totals.buying.toLocaleString()}</Text>
          </View>
          <View style={styles.footerStatDivider} />
          <View style={styles.footerStatItem}>
            <Text style={styles.footerStatLabel}>TOTAL SELLING</Text>
            <Text style={styles.footerStatValue}>₹{totals.selling.toLocaleString()}</Text>
          </View>
        </View>
        
        <View style={styles.profitBanner}>
          <View style={styles.profitIconContainer}>
            <DollarSign size={24} color="#1565C0" />
          </View>
          <View>
            <Text style={styles.profitLabel}>TOTAL PROFIT MADE</Text>
            <Text style={styles.profitValue}>₹{totals.profit.toLocaleString()}</Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3F2FD',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    marginHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  listContent: {
    padding: 16,
    paddingBottom: 20,
  },
  productRow: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  productHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  productIndex: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#1565C0',
    backgroundColor: '#E3F2FD',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    marginRight: 8,
  },
  productName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1E293B',
    flex: 1,
  },
  productDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#F8FAFC',
    padding: 12,
    borderRadius: 12,
    marginBottom: 10,
  },
  detailCol: {
    alignItems: 'flex-start',
  },
  detailLabel: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#94A3B8',
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '700',
    color: '#334155',
  },
  imeiContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  imeiLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#94A3B8',
    marginRight: 6,
  },
  imeiValue: {
    fontSize: 12,
    fontWeight: '700',
    color: '#64748B',
  },
  footer: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 10,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    borderBottomWidth: 0,
  },
  footerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    gap: 8,
  },
  footerTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: '#1565C0',
    letterSpacing: 0.5,
  },
  footerStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    marginBottom: 20,
  },
  footerStatItem: {
    alignItems: 'center',
    flex: 1,
  },
  footerStatLabel: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#94A3B8',
    marginBottom: 4,
  },
  footerStatValue: {
    fontSize: 16,
    fontWeight: '800',
    color: '#1E293B',
  },
  footerStatDivider: {
    width: 1,
    height: 30,
    backgroundColor: '#E2E8F0',
  },
  profitBanner: {
    backgroundColor: '#E3F2FD',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    borderWidth: 1.5,
    borderColor: '#1565C0',
  },
  profitIconContainer: {
    backgroundColor: '#BBDEFB',
    padding: 10,
    borderRadius: 12,
  },
  profitLabel: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#1565C0',
    letterSpacing: 0.5,
  },
  profitValue: {
    fontSize: 22,
    fontWeight: '900',
    color: '#0D47A1',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 100,
    gap: 16,
  },
  emptyText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#CBD5E1',
    letterSpacing: 1,
  },
});

export default CalculationReportPage;
