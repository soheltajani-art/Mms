import { useEffect, useRef, useState, useCallback } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions, Platform, StatusBar } from 'react-native';
import { useRouter } from 'expo-router';
import { getSetting, saveSetting, removeSetting } from './data/sqlite';

const { width, height } = Dimensions.get('window');

// Responsive sizing based on screen dimensions
const getResponsiveSizes = () => {
  const isSmallScreen = width < 360;
  const isMediumScreen = width >= 360 && width < 420;
  const isLargeScreen = width >= 420;

  return {
    cardWidth: Math.min(width * 0.92, 380),
    mainFontSize: isSmallScreen ? 48 : isMediumScreen ? 56 : 64,
    prestsTextSize: isSmallScreen ? 10 : 12,
    footerTextSize: isSmallScreen ? 10 : 12,
    cardPadding: isSmallScreen ? 16 : 20,
    mainTextLineHeight: isSmallScreen ? 52 : isMediumScreen ? 60 : 68,
  };
};

const sizes = getResponsiveSizes();

// Correct way to get the number of dots for the animation
const numDots = 49;

export default function LoadingPage() {
  const router = useRouter();
  const [typedText, setTypedText] = useState('');

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.95)).current;
  const presentsAnim = useRef(new Animated.Value(0)).current; // For the "PRESENTS" text
  const lineAnim1 = useRef(new Animated.Value(0)).current;
  const lineAnim2 = useRef(new Animated.Value(0)).current;
  const lineAnim3 = useRef(new Animated.Value(0)).current;
  const circleScaleAnim = useRef(new Animated.Value(0)).current;
  const bottomLineAnim1 = useRef(new Animated.Value(0)).current;
  const bottomLineAnim2 = useRef(new Animated.Value(0)).current;
  const bottomLineAnim3 = useRef(new Animated.Value(0)).current;
  const dotAnims = useRef(Array.from({ length: numDots }).map(() => new Animated.Value(0))).current;

  const navigate = useCallback(async () => {
    try {
      const hasSeenWelcome = await getSetting('hasSeenWelcome');
      const isReturningFromWelcome = await getSetting('isReturningFromWelcome');
      
      if (isReturningFromWelcome === 'true') {
        // New user flow: Step 3 (Returning from Welcome to Dashboard)
        await saveSetting('hasSeenWelcome', 'true');
        await removeSetting('isReturningFromWelcome');
        router.replace('/(tabs)');
      } else if (hasSeenWelcome === 'true') {
        // Old user flow: Step 2 (Loading to Dashboard)
        router.replace('/(tabs)');
      } else {
        // New user flow: Step 1 (Loading to Welcome)
        router.replace('/WelcomePage');
      }
    } catch (error) {
      console.error('Failed to check first launch', error);
      router.replace('/(tabs)');
    }
  }, [router]);

  useEffect(() => {
    const targetText = 'Powered by Mohammed Sohel Tajani';
    let index = 0;
    
    // Typing effect - optimized interval
    const typingInterval = setInterval(() => {
      setTypedText(targetText.slice(0, index + 1));
      index++;
      if (index >= targetText.length) {
        clearInterval(typingInterval);
      }
    }, 60);

    // Animation sequence - optimized for Android performance
    // Using parallel for smoother initial entrance
    Animated.sequence([
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 600,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 7,
          tension: 40,
          useNativeDriver: true,
        }),
        Animated.timing(presentsAnim, {
          toValue: 1,
          duration: 600,
          useNativeDriver: true,
        }),
        Animated.timing(circleScaleAnim, {
          toValue: 1,
          duration: 600,
          useNativeDriver: true,
        }),
      ]),
      Animated.parallel([
        Animated.stagger(100, [
          Animated.timing(lineAnim1, { toValue: 1, duration: 300, useNativeDriver: true }),
          Animated.timing(lineAnim2, { toValue: 1, duration: 300, useNativeDriver: true }),
          Animated.timing(lineAnim3, { toValue: 1, duration: 300, useNativeDriver: true }),
        ]),
        // Batching dot animations to reduce bridge traffic on Android
        Animated.stagger(15, dotAnims.map(anim =>
          Animated.spring(anim, {
            toValue: 1,
            speed: 20,
            bounciness: 8,
            useNativeDriver: true,
          }))
        ),
        Animated.stagger(100, [
          Animated.timing(bottomLineAnim1, { toValue: 1, duration: 300, useNativeDriver: true }),
          Animated.timing(bottomLineAnim2, { toValue: 1, duration: 300, useNativeDriver: true }),
          Animated.timing(bottomLineAnim3, { toValue: 1, duration: 300, useNativeDriver: true }),
        ]),
      ])
    ]).start();

    // Reduced wait time from 5000ms to 3000ms for better UX
    const timer = setTimeout(navigate, 3000);

    return () => {
      clearInterval(typingInterval);
      clearTimeout(timer);
    };
  }, [navigate, dotAnims, fadeAnim, scaleAnim, presentsAnim, circleScaleAnim, lineAnim1, lineAnim2, lineAnim3, bottomLineAnim1, bottomLineAnim2, bottomLineAnim3]);

  // Interpolated styles
  const line1Scale = lineAnim1.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const line2Scale = lineAnim2.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const line3Scale = lineAnim3.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const bottomLine1Scale = bottomLineAnim1.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const bottomLine2Scale = bottomLineAnim2.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const bottomLine3Scale = bottomLineAnim3.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });

  const presentsOpacity = presentsAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1],
  });
  const presentsScale = presentsAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [0.9, 1],
  });

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      <Animated.View style={[styles.card, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
        <View style={styles.cardInner}>
          {/* PRESENTS Badge */}
          <Animated.View style={[styles.presentsContainer, { opacity: presentsOpacity, transform: [{ scale: presentsScale }] }]}>
            <Text style={styles.presentsText}>PRESENTS</Text>
          </Animated.View>

          {/* Top Right Lines */}
          <View style={styles.topRightLines}>
            <Animated.View style={[styles.line, { width: 48, transform: [{ scaleX: line1Scale }] }]} />
            <Animated.View style={[styles.line, { width: 48, transform: [{ scaleX: line2Scale }] }]} />
            <Animated.View style={[styles.line, { width: 48, transform: [{ scaleX: line3Scale }] }]} />
          </View>

          {/* Main Text - TAJANI STUDIO */}
          <View style={styles.mainTextContainer}>
            <Text style={styles.mainText} numberOfLines={1} adjustsFontSizeToFit>
              TAJANI
            </Text>
            <Text style={styles.mainText} numberOfLines={1} adjustsFontSizeToFit>
              STUDIO
            </Text>
          </View>

          {/* Circle - Bottom Left */}
          <Animated.View style={[styles.circle, { transform: [{ scale: circleScaleAnim }] }]} />

          {/* Bottom Right Container - Grid and Lines */}
          <View style={styles.bottomRightContainer}>
            <View style={styles.grid}>
              {dotAnims.map((anim, i) => (
                <Animated.View
                    key={i}
                    style={[styles.dot, {
                        opacity: anim,
                        transform: [{ scale: anim }]
                    }]}
                />
              ))}
            </View>
            <View style={styles.bottomRightLines}>
              <Animated.View style={[styles.bottomLine, { width: 96, transform: [{ scaleX: bottomLine1Scale }] }]} />
              <Animated.View style={[styles.bottomLine, { width: 96, transform: [{ scaleX: bottomLine2Scale }] }]} />
              <Animated.View style={[styles.bottomLine, { width: 96, transform: [{ scaleX: bottomLine3Scale }] }]} />
            </View>
          </View>
        </View>
      </Animated.View>

      {/* Footer Text */}
      <View style={styles.footerContainer}>
        <Text style={styles.footerText} numberOfLines={2}>
          {typedText}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 12,
  },
  card: {
    width: sizes.cardWidth,
    aspectRatio: 3 / 4,
    padding: sizes.cardPadding,
    overflow: 'hidden',
  },
  cardInner: {
    flex: 1,
    position: 'relative',
    justifyContent: 'flex-start',
  },
  presentsContainer: {
    alignSelf: 'flex-start',
    backgroundColor: '#4A90E2',
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 999,
    marginBottom: 12,
  },
  presentsText: {
    color: 'white',
    fontSize: sizes.prestsTextSize,
    fontWeight: '700',
    letterSpacing: 1.2,
  },
  topRightLines: {
    position: 'absolute',
    top: 16,
    right: 0,
    gap: 5,
    alignItems: 'flex-end',
  },
  line: {
    height: 3,
    backgroundColor: '#4A90E2',
    borderRadius: 1.5,
  },
  mainTextContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
    paddingRight: 12,
    minHeight: sizes.mainFontSize * 2.5,
  },
  mainText: {
    fontSize: sizes.mainFontSize,
    fontWeight: '900',
    color: '#2D3436',
    lineHeight: sizes.mainTextLineHeight,
    letterSpacing: -1,
  },
  circle: {
    position: 'absolute',
    bottom: -60,
    left: -60,
    width: 180,
    height: 180,
    borderRadius: 90,
    borderWidth: 24,
    borderColor: '#4A90E2',
  },
  bottomRightContainer: {
    position: 'absolute',
    bottom: 20,
    right: 8,
    alignItems: 'flex-end',
    gap: 24,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: 70,
    justifyContent: 'flex-end',
    gap: 5,
    marginBottom: 10,
  },
  dot: {
    width: 4,
    height: 4,
    backgroundColor: '#4A90E2',
    borderRadius: 2,
  },
  bottomRightLines: {
    gap: 8,
    transform: [{ rotate: '-45deg' }],
    alignItems: 'flex-end',
    marginRight: -10,
  },
  bottomLine: {
    height: 3,
    backgroundColor: '#4A90E2',
    borderRadius: 1.5,
  },
  footerContainer: {
    position: 'absolute',
    bottom: Platform.OS === 'android' ? 32 : 24,
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerText: {
    fontSize: sizes.footerTextSize,
    color: '#888888',
    textAlign: 'center',
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    fontWeight: '400',
  }
});
