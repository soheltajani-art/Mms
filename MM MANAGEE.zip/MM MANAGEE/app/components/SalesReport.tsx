import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { HistoryItem } from '../data/storage';

interface SalesReportProps {
  sales: HistoryItem[];
  onViewPhoto: (uri: string) => void;
}

const SalesReport: React.FC<SalesReportProps> = ({ sales, onViewPhoto }) => {
  const renderSaleItem = ({ item }: { item: HistoryItem }) => {
    
    // ✅ FIX: move calculation outside JSX
    const profit =
      item.profit ?? ((item.sellingPrice ?? 0) - (item.purchaseCost ?? 0));

    return (
      <LinearGradient colors={['#ffffff', '#f9f9f9']} style={styles.saleItem}>
        
        <View style={styles.productHeader}>
          <Text style={styles.productName}>{item.model}</Text>
          <View style={styles.statusBadge}>
            <Text style={styles.statusText}>SOLD</Text>
          </View>
        </View>

        <View style={styles.detailsGrid}>
          <View style={styles.detailItem}>
            <Text style={styles.detailLabel}>IMEI</Text>
            <Text style={styles.detailValue}>
              {item.primaryImei ?? 'N/A'}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.priceColumn}>
          <View style={styles.priceRow}>
            <Text style={styles.detailLabel}>MOP</Text>
            <Text style={styles.priceValue}>₹{item.mopValue ?? 0}</Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.detailLabel}>DP (Purchase)</Text>
            <Text style={styles.priceValue}>₹{item.purchaseCost ?? 0}</Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.detailLabel}>Sell Price</Text>
            <Text style={[styles.priceValue, styles.soldPrice]}>
              ₹{item.sellingPrice ?? 0}
            </Text>
          </View>
        </View>

        <View style={styles.divider} />

        <View style={styles.dateRow}>
          <Feather name="calendar" size={14} color="#666" />
          <Text style={styles.dateText}>
            Sold:{' '}
            {item.soldDate
              ? new Date(item.soldDate).toLocaleDateString()
              : 'N/A'}
          </Text>
        </View>

        <View style={[styles.detailRow, styles.profitRow]}>
          <Text style={styles.profitLabel}>Profit</Text>
          <Text style={styles.profitValue}>₹{profit}</Text>
        </View>

        {(item.compulsoryPhoto || item.optionalPhoto) && (
          <View style={styles.photoSection}>
            <Text style={styles.photoTitle}>Photo Documentation</Text>

            <View style={styles.photoRow}>
              
              {item.compulsoryPhoto ? (
                <TouchableOpacity
                  onPress={() => onViewPhoto(item.compulsoryPhoto!)}
                  style={styles.photoThumbnailContainer}
                >
                  <Image
                    source={{ uri: item.compulsoryPhoto }}
                    style={styles.thumbnail}
                  />
                  <View style={styles.viewOverlay}>
                    <Feather name="eye" size={20} color="#fff" />
                  </View>
                </TouchableOpacity>
              ) : null}

              {item.optionalPhoto ? (
                <TouchableOpacity
                  onPress={() => onViewPhoto(item.optionalPhoto!)}
                  style={styles.photoThumbnailContainer}
                >
                  <Image
                    source={{ uri: item.optionalPhoto }}
                    style={styles.thumbnail}
                  />
                  <View style={styles.viewOverlay}>
                    <Feather name="eye" size={20} color="#fff" />
                  </View>
                </TouchableOpacity>
              ) : null}

            </View>
          </View>
        )}

      </LinearGradient>
    );
  };

  return (
    <FlatList
      data={sales}
      renderItem={renderSaleItem}
      keyExtractor={(item, index) =>
        item.id ?? item.primaryImei ?? index.toString()
      }
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={false}
    />
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    paddingHorizontal: 16,
    paddingBottom: 24,
    paddingTop: 8,
  },
  saleItem: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    elevation: 4,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  productHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  productName: {
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
  },
  statusBadge: {
    backgroundColor: '#FFE5E5',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#D32F2F',
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  detailItem: {
    flex: 1,
    minWidth: '30%',
    marginBottom: 8,
  },
  priceColumn: {
    flexDirection: 'column',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  detailLabel: {
    fontSize: 12,
    color: '#888',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  priceValue: {
    fontSize: 15,
    fontWeight: '700',
  },
  soldPrice: {},
  divider: {
    height: 1,
    backgroundColor: '#EEE',
    marginVertical: 12,
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  dateText: {
    marginLeft: 6,
    fontSize: 13,
    color: '#666',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  profitRow: {
    backgroundColor: '#F1FBF3',
    padding: 12,
    borderRadius: 12,
  },
  profitLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  profitValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  photoSection: {
    marginTop: 20,
  },
  photoTitle: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
  },
  photoRow: {
    flexDirection: 'row',
  },
  photoThumbnailContainer: {
    width: 80,
    height: 80,
    marginRight: 12,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  viewOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default SalesReport;