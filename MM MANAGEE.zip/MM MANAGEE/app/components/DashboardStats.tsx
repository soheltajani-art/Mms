
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';

interface DashboardStatsProps {
  todaysPurchases: number;
  todaysSoldOut: number;
  todaysSales: number;
  todaysProfit: number;
}

const DashboardStats: React.FC<DashboardStatsProps> = ({
  todaysPurchases,
  todaysSoldOut,
  todaysSales,
  todaysProfit,
}) => {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <View style={styles.row}>
        <TouchableOpacity style={styles.smallCard} onPress={() => router.push('/todays-purchase-report')}>
          <View style={[styles.cardIconContainer, { backgroundColor: '#E8D9FF' }]}>
            <Feather name="shopping-cart" size={24} color="#8A2BE2" />
          </View>
          <Text style={styles.smallCardTitle}>TODAY PURCHASE</Text>
          <Text style={styles.smallCardValue}>{todaysPurchases}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.smallCard} onPress={() => router.push('/sold-out-items')}>
          <View style={[styles.cardIconContainer, { backgroundColor: '#FFD9D9' }]}>
            <Feather name="tag" size={24} color="#FF3B30" />
          </View>
          <Text style={styles.smallCardTitle}>TODAY SOLD</Text>
          <Text style={styles.smallCardValue}>{todaysSoldOut}</Text>
        </TouchableOpacity>
      </View>

      <LinearGradient
        colors={['#FF2D55', '#FF0000']}
        style={styles.largeCard}
      >
        <View style={styles.largeCardIconWrapper}>
          <Feather name="trending-up" size={20} color="#fff" />
        </View>
        <View style={styles.largeCardTextContainer}>
          <Text style={styles.largeCardTitle}>TODAY'S SALES (RUPEES)</Text>
          <Text style={styles.largeCardValue}>₹{todaysSales.toLocaleString()}</Text>
        </View>
        <View style={styles.liveContainer}>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>LIVE</Text>
        </View>
      </LinearGradient>

      <View style={styles.profitCard}>
        <View style={styles.profitIconWrapper}>
          <Feather name="dollar-sign" size={20} color="#1565C0" />
        </View>
        <View style={styles.largeCardTextContainer}>
          <Text style={styles.profitTitle}>TODAY'S PROFIT</Text>
          <Text style={styles.profitValue}>₹{todaysProfit.toLocaleString()}</Text>
        </View>
        <View style={styles.liveContainerBlue}>
          <View style={styles.liveDotBlue} />
          <Text style={styles.liveTextBlue}>LIVE</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginVertical: 10,
  },
  smallCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 15,
    width: '48%',
    elevation: 2,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  cardIconContainer: {
    borderRadius: 15,
    padding: 12,
    width: 50,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  smallCardTitle: {
    fontSize: 11,
    color: "#94A3B8",
    fontWeight: 'bold',
    marginBottom: 5,
  },
  smallCardValue: {
    fontSize: 28,
    fontWeight: "900",
    color: '#1E293B'
  },
  largeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    padding: 16,
    marginVertical: 8,
    elevation: 3,
  },
  largeCardIconWrapper: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 15,
    padding: 12,
    marginRight: 12,
  },
  largeCardTextContainer: {
    flex: 1,
  },
  largeCardTitle: {
    color: '#fff',
    fontSize: 11,
    fontWeight: 'bold',
  },
  largeCardValue: {
    color: '#fff',
    fontSize: 24,
    fontWeight: '900',
    marginTop: 4,
  },
  profitCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    padding: 16,
    marginVertical: 8,
    elevation: 2,
    backgroundColor: '#E3F2FD',
    borderWidth: 1.5,
    borderColor: '#1565C0',
  },
  profitIconWrapper: {
    backgroundColor: '#BBDEFB',
    borderRadius: 15,
    padding: 12,
    marginRight: 12,
  },
  profitTitle: {
    color: '#1565C0',
    fontSize: 11,
    fontWeight: 'bold',
  },
  profitValue: {
    color: '#0D47A1',
    fontSize: 24,
    fontWeight: '900',
    marginTop: 4,
  },
  liveContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 10,
    paddingVertical: 4,
    paddingHorizontal: 8,
    marginHorizontal: 10,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#34C759',
    marginRight: 6,
  },
  liveText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  liveContainerBlue: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#BBDEFB',
    borderRadius: 10,
    paddingVertical: 4,
    paddingHorizontal: 8,
    marginHorizontal: 10,
  },
  liveDotBlue: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#1565C0',
    marginRight: 6,
  },
  liveTextBlue: {
    color: '#1565C0',
    fontSize: 10,
    fontWeight: 'bold',
  },
});

export default DashboardStats;
