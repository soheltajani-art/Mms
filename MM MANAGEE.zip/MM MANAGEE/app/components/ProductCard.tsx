import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { StockItem, HistoryItem } from '../data/storage';

interface ProductCardProps {
  item: StockItem | HistoryItem;
  onViewPhoto: (uri: string) => void;
  isAvailable?: boolean;
}

const ProductCard = ({ item, onViewPhoto, isAvailable = false }: ProductCardProps) => {
  const isSold = 'type' in item && item.type === 'SOLD';
  const displayDate = isSold ? (item as HistoryItem).soldDate : item.purchaseDate;
  const dateLabel = isSold ? 'Sale Date' : 'Purchase Date';

  const renderPhotoSection = () => {
    if (!item.compulsoryPhoto && !item.optionalPhoto) {
      return null;
    }
    return (
      <View style={styles.photoSection}>
        <Text style={styles.photoTitle}>Photo Documentation</Text>
        <View style={styles.photoRow}>
          {item.compulsoryPhoto ? (
            <TouchableOpacity onPress={() => onViewPhoto(item.compulsoryPhoto!)} style={styles.photoThumbnailContainer}>
              <Image source={{ uri: item.compulsoryPhoto }} style={styles.thumbnail} />
              <View style={styles.viewOverlay}>
                <Feather name="eye" size={20} color="#fff" />
              </View>
            </TouchableOpacity>
          ) : null}
          {item.optionalPhoto ? (
            <TouchableOpacity onPress={() => onViewPhoto(item.optionalPhoto!)} style={styles.photoThumbnailContainer}>
              <Image source={{ uri: item.optionalPhoto }} style={styles.thumbnail} />
              <View style={styles.viewOverlay}>
                <Feather name="eye" size={20} color="#fff" />
              </View>
            </TouchableOpacity>
          ) : null}
        </View>
      </View>
    );
  };

  const renderProfitSection = () => {
    if (!isSold || (item as HistoryItem).profit === undefined) {
      return null;
    }
    return (
      <View>
        <View style={styles.row}>
          <Text style={styles.labelText}>Profit</Text>
          <Text style={[styles.value, { color: '#22c55e', fontWeight: 'bold' }]}>₹ {(item as HistoryItem).profit}</Text>
        </View>
        <View style={styles.divider} />
      </View>
    );
  };

  return (
    <View style={styles.itemContainer}>
      <LinearGradient colors={['#ffffff', '#f3f6fb']} style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>{item.model}</Text>
          <LinearGradient colors={isSold ? ['#ef4444', '#dc2626'] : ['#22c55e', '#16a34a']} style={styles.stock}>
            <Text style={styles.stockText}>{isSold ? 'Sold' : 'In Stock'}</Text>
          </LinearGradient>
        </View>
        <View style={styles.row}>
          <Text style={styles.labelText}>IMEI</Text>
          <Text style={styles.value}>{item.primaryImei}</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.row}>
          <Text style={styles.labelText}>{isSold ? 'Selling Price' : 'Purchase Price'}</Text>
          <Text style={styles.value}>₹ {isSold ? (item as HistoryItem).sellingPrice : item.purchaseCost}</Text>
        </View>
        <View style={styles.divider} />
        {renderProfitSection()}
        {displayDate && (
          <View style={styles.row}>
            <Text style={styles.labelText}>{dateLabel}</Text>
            <Text style={styles.value}>{new Date(displayDate).toLocaleDateString()}</Text>
          </View>
        )}
        {renderPhotoSection()}
      </LinearGradient>
    </View>
  );
};

const styles = StyleSheet.create({
  itemContainer: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  card: {
    borderRadius: 20,
    padding: 20,
    shadowColor: 'rgba(0,0,0,0.08)',
    shadowOffset: {
      width: 8,
      height: 8,
    },
    shadowOpacity: 1,
    shadowRadius: 20,
    elevation: 10,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  cardTitle: {
    fontSize: 22,
    fontWeight: '600',
    flex: 1,
  },
  stock: {
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  stockText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 14,
  },
  divider: {
    height: 1,
    backgroundColor: '#e5e7eb',
  },
  labelText: {
    color: '#444',
    fontSize: 16,
  },
  value: {
    color: '#7b7b7b',
    fontWeight: '500',
    fontSize: 16,
  },
  photoSection: {
    marginTop: 15,
  },
  photoTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
  },
  photoRow: {
    flexDirection: 'row',
    gap: 12,
  },
  photoThumbnailContainer: {
    width: 80,
    height: 80,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#F5F5F5',
    borderWidth: 1,
    borderColor: '#DDD',
    position: 'relative',
  },
  thumbnail: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  viewOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default ProductCard;
