import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Modal, Dimensions, Platform } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { X, Zap, ZapOff } from 'lucide-react-native';
import { Audio } from 'expo-av';
import CameraPermissionModal from '../app/components/CameraPermissionModal';
import { 
  getOptimalCameraResolution, 
  getOptimalZoom, 
  getOptimalScanArea,
  getDeviceCategory,
  getOptimalAutofocus,
  formatMegapixels 
} from '../utils/cameraResolution';

interface BarcodeScannerProps {
  isVisible: boolean;
  onClose: () => void;
  onScan: (data: string) => void;
  allowedBarcodes?: string[];
}

export const BarcodeScanner: React.FC<BarcodeScannerProps> = ({ isVisible, onClose, onScan, allowedBarcodes }) => {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [torch, setTorch] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [pictureSize, setPictureSize] = useState<string>('1920x1080');
  const [zoom, setZoom] = useState<number>(0);
  const [resolutionInfo, setResolutionInfo] = useState<string>('');
  const [deviceCategory, setDeviceCategory] = useState<'small' | 'medium' | 'large'>('medium');

  const cameraRef = useRef<CameraView>(null);
  const soundRef = useRef<Audio.Sound | null>(null);
  const scanTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize device category and preload sound
  useEffect(() => {
    const category = getDeviceCategory();
    setDeviceCategory(category);
    
    // Preload sound
    const loadSound = async () => {
      try {
        const { sound } = await Audio.Sound.createAsync(
          require('../assets/sounds/beep.mp3')
        );
        soundRef.current = sound;
      } catch (error) {
        console.warn('Failed to load scan sound:', error);
      }
    };

    loadSound();

    return () => {
      if (soundRef.current) {
        soundRef.current.unloadAsync();
      }
      if (scanTimeoutRef.current) {
        clearTimeout(scanTimeoutRef.current);
      }
    };
  }, []);

  // Handle permission modal when scanner becomes visible
  useEffect(() => {
    if (isVisible) {
      setScanned(false);
      if (permission && !permission.granted && permission.canAskAgain) {
        setShowPermissionModal(true);
      }
    }
  }, [isVisible, permission]);

  const handleRequestPermission = async () => {
    setShowPermissionModal(false);
    const result = await requestPermission();
    if (!result.granted) {
      onClose();
    }
  };

  const handleCameraReady = async () => {
    if (cameraRef.current) {
      try {
        // Get optimal resolution based on device size
        const resolutionInfo = await getOptimalCameraResolution(cameraRef.current);
        
        if (resolutionInfo) {
          setPictureSize(resolutionInfo.resolution);
          
          // Get optimal zoom for device (now returns 0 for normal opening)
          const optimalZoom = getOptimalZoom(resolutionInfo.deviceCategory);
          setZoom(optimalZoom);
          
          const megapixelString = formatMegapixels(resolutionInfo.megapixels);
          setResolutionInfo(`${resolutionInfo.resolution} (${megapixelString})`);
          
          console.log(`✅ Scanner Optimized for ${resolutionInfo.deviceCategory} device`);
          console.log(`📸 Resolution: ${resolutionInfo.resolution} | ${megapixelString}`);
          console.log(`🔍 Zoom Level: ${optimalZoom} (Normal Opening)`);
          console.log(`📐 Aspect Ratio: ${resolutionInfo.aspectRatio}`);
        }
      } catch (e) {
        console.warn('Resolution optimization failed, using default HD', e);
        setResolutionInfo('1920x1080 (2 MP)');
      }
    }
  };

  const handleBarCodeScanned = async ({ data }: { data: string }) => {
    // Prevent multiple scans
    if (scanned) return;
    
    const cleanData = data.trim();
    
    // High-speed validation for 15-digit barcodes (IMEI)
    // Accept 15 digits as requested for IMEI scanning
    if (cleanData.length === 15 && /^\d+$/.test(cleanData)) {
      // If allowedBarcodes is provided, only accept if the scanned data is in the list
      if (allowedBarcodes && !allowedBarcodes.includes(cleanData)) {
        console.warn(`Barcode ${cleanData} not in allowed list`);
        return;
      }
      
      // Play beep sound
      if (soundRef.current) {
        try {
          await soundRef.current.replayAsync();
        } catch (error) {
          console.warn('Failed to play scan sound:', error);
        }
      }

      setScanned(true);
      
      // Add a small delay before closing to ensure sound plays
      scanTimeoutRef.current = setTimeout(() => {
        onScan(cleanData);
      }, 300);
    } else {
      console.warn(`Invalid barcode format: ${cleanData} (length: ${cleanData.length})`);
    }
  };

  if (!permission) return null;

  const autofocus = getOptimalAutofocus(deviceCategory);
  const scanArea = getOptimalScanArea();

  return (
    <Modal
      animationType="fade"
      transparent={false}
      visible={isVisible}
      onRequestClose={onClose}
    >
      <View style={styles.container}>
        {!permission.granted ? (
          <View style={styles.permissionContainer}>
            <CameraPermissionModal 
              visible={showPermissionModal}
              onClose={onClose}
              onConfirm={handleRequestPermission}
            />
            <Text style={styles.permissionText}>Camera access is required for high-speed scanning.</Text>
            <TouchableOpacity style={styles.permissionButton} onPress={() => setShowPermissionModal(true)}>
              <Text style={styles.permissionButtonText}>Enable Camera</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.closeButton} onPress={onClose}>
              <X size={30} color="#fff" />
            </TouchableOpacity>
          </View>
        ) : (
          <CameraView
            ref={cameraRef}
            style={styles.camera}
            facing="back"
            enableTorch={torch}
            autofocus={autofocus}
            zoom={zoom}
            pictureSize={pictureSize}
            onCameraReady={handleCameraReady}
            onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
            barcodeScannerSettings={{
              // Limited to specific types for faster processing
              // code128 and code39 are common for IMEI barcodes
              barcodeTypes: ["code128", "code39", "ean13", "upc_a", "ean8", "upce"],
            }}
          >
            <View style={styles.overlay}>
              <View style={styles.header}>
                <TouchableOpacity style={styles.iconButton} onPress={() => setTorch(!torch)}>
                  {torch ? <Zap size={28} color="#FFD700" /> : <ZapOff size={28} color="#fff" />}
                </TouchableOpacity>
                <View style={styles.headerTextContainer}>
                  <Text style={styles.headerText}>IMEI Scanner</Text>
                  <Text style={styles.subHeaderText}>
                    {allowedBarcodes ? 'Inventory-Only Mode' : 'High Clarity Mode'}
                  </Text>
                </View>
                <TouchableOpacity style={styles.iconButton} onPress={onClose}>
                  <X size={28} color="#fff" />
                </TouchableOpacity>
              </View>

              <View style={styles.scanAreaContainer}>
                <View style={[styles.scanArea, { width: scanArea.width, height: scanArea.height }]}>
                  <View style={[styles.corner, styles.topLeft]} />
                  <View style={[styles.corner, styles.topRight]} />
                  <View style={[styles.corner, styles.bottomLeft]} />
                  <View style={[styles.corner, styles.bottomRight]} />
                  <View style={styles.scanLine} />
                </View>
                <Text style={styles.hintText}>
                  {allowedBarcodes ? 'Scanning Available Stock' : 'Align IMEI Barcode to Scan'}
                </Text>
              </View>

              <View style={styles.footer}>
                <Text style={styles.footerText}>
                  {resolutionInfo ? `📸 ${resolutionInfo}` : 'OPTIMIZED PERFORMANCE'}
                </Text>
              </View>
            </View>
          </CameraView>
        )}
      </View>
    </Modal>
  );
};

const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#000' 
  },
  camera: { 
    flex: 1 
  },
  permissionContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    padding: 20 
  },
  permissionText: { 
    color: '#fff', 
    fontSize: 18, 
    textAlign: 'center', 
    marginBottom: 20 
  },
  permissionButton: { 
    backgroundColor: '#007AFF', 
    paddingHorizontal: 25, 
    paddingVertical: 12, 
    borderRadius: 10 
  },
  permissionButtonText: { 
    color: '#fff', 
    fontSize: 16, 
    fontWeight: 'bold' 
  },
  closeButton: { 
    position: 'absolute', 
    top: 50, 
    right: 20 
  },
  overlay: { 
    flex: 1, 
    backgroundColor: 'rgba(0,0,0,0.8)', 
    justifyContent: 'space-between' 
  },
  header: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    paddingTop: height * 0.07, 
    paddingHorizontal: 20 
  },
  headerTextContainer: { 
    flex: 1, 
    alignItems: 'center' 
  },
  headerText: { 
    color: '#fff', 
    fontSize: 20, 
    fontWeight: '700', 
    letterSpacing: 0.5 
  },
  subHeaderText: { 
    color: '#FF0000', 
    fontSize: 12, 
    fontWeight: '600', 
    marginTop: 2 
  },
  iconButton: { 
    width: 46, 
    height: 46, 
    justifyContent: 'center', 
    alignItems: 'center', 
    backgroundColor: 'rgba(0,0,0,0.4)', 
    borderRadius: 23 
  },
  scanAreaContainer: { 
    alignItems: 'center', 
    justifyContent: 'center' 
  },
  scanArea: { 
    position: 'relative' 
  },
  scanLine: { 
    height: 1.5, 
    backgroundColor: '#FF0000', 
    width: '100%', 
    position: 'absolute', 
    top: '50%', 
    opacity: 0.8 
  },
  corner: { 
    position: 'absolute', 
    width: 25, 
    height: 25, 
    borderColor: '#FF0000', 
    borderStyle: 'solid' 
  },
  topLeft: { 
    top: 0, 
    left: 0, 
    borderTopWidth: 5, 
    borderLeftWidth: 5 
  },
  topRight: { 
    top: 0, 
    right: 0, 
    borderTopWidth: 5, 
    borderRightWidth: 5 
  },
  bottomLeft: { 
    bottom: 0, 
    left: 0, 
    borderBottomWidth: 5, 
    borderLeftWidth: 5 
  },
  bottomRight: { 
    bottom: 0, 
    right: 0, 
    borderBottomWidth: 5, 
    borderRightWidth: 5 
  },
  hintText: { 
    color: '#fff', 
    marginTop: 25, 
    fontSize: 14, 
    fontWeight: '500', 
    backgroundColor: 'rgba(255,0,0,0.6)', 
    paddingHorizontal: 20, 
    paddingVertical: 8, 
    borderRadius: 25, 
    overflow: 'hidden' 
  },
  footer: { 
    paddingBottom: 40, 
    alignItems: 'center' 
  },
  footerText: { 
    color: '#fff', 
    fontSize: 10, 
    fontWeight: '700', 
    opacity: 0.5, 
    letterSpacing: 1.5 
  },
});

export default BarcodeScanner;
