/**
 * Camera Resolution Utility
 * Provides functions to get the optimal camera resolution based on device size
 * Supports all devices from small phones to large tablets
 * OPTIMIZED FOR HIGH CLARITY ACROSS ALL DEVICES
 */

import { Dimensions } from 'react-native';

/**
 * Calculate megapixels from width and height
 */
export const calculateMegapixels = (width: number, height: number): number => {
  return (width * height) / 1_000_000;
};

/**
 * Parse resolution string (e.g., "4000x3000") to width and height
 */
export const parseResolution = (
  resolutionString: string
): { width: number; height: number } => {
  const [width, height] = resolutionString.split('x').map(Number);
  return { width, height };
};

/**
 * Determine device category based on screen width
 */
export const getDeviceCategory = (): 'small' | 'medium' | 'large' => {
  const { width } = Dimensions.get('window');
  
  if (width < 375) {
    return 'small';  // Small phones (iPhone SE, etc.)
  } else if (width < 768) {
    return 'medium'; // Regular phones
  } else {
    return 'large';  // Tablets and large devices
  }
};

/**
 * Get target resolution megapixels based on device category
 * OPTIMIZED FOR HIGH CLARITY:
 * Small devices: 12-16MP (high clarity for small screens)
 * Medium devices: 16-20MP (high clarity for standard phones)
 * Large devices: 20MP+ (maximum clarity for tablets)
 */
export const getTargetMegapixels = (deviceCategory?: 'small' | 'medium' | 'large'): { min: number; max: number } => {
  const category = deviceCategory || getDeviceCategory();
  
  switch (category) {
    case 'small':
      return { min: 12, max: 20 };  // Increased for high clarity
    case 'medium':
      return { min: 16, max: 24 };  // Increased for high clarity
    case 'large':
      return { min: 20, max: 100 }; // Maximum clarity for tablets
  }
};

/**
 * Filter resolutions by target megapixel range
 */
export const filterResolutionsByMegapixels = (
  sizes: string[],
  targetMegapixels: { min: number; max: number }
): Array<{ resolution: string; megapixels: number }> => {
  return sizes
    .map(size => {
      const { width, height } = parseResolution(size);
      const megapixels = calculateMegapixels(width, height);
      return { resolution: size, megapixels };
    })
    .filter(item => item.megapixels >= targetMegapixels.min && item.megapixels <= targetMegapixels.max)
    .sort((a, b) => b.megapixels - a.megapixels);
};

/**
 * Get the highest resolution from available picture sizes
 * This function queries all available resolutions without aspect ratio restrictions
 * and selects the one with the highest megapixel count
 */
export const getHighestResolution = (
  sizes: string[] | undefined
): { resolution: string; megapixels: number } | null => {
  if (!sizes || sizes.length === 0) {
    return null;
  }

  let highestResolution = sizes[0];
  let highestMegapixels = 0;

  for (const size of sizes) {
    const { width, height } = parseResolution(size);
    const megapixels = calculateMegapixels(width, height);

    if (megapixels > highestMegapixels) {
      highestMegapixels = megapixels;
      highestResolution = size;
    }
  }

  return {
    resolution: highestResolution,
    megapixels: highestMegapixels,
  };
};

/**
 * Get optimal zoom level based on device category
 * ALL DEVICES: 0 (normal opening with no zoom for high clarity)
 */
export const getOptimalZoom = (deviceCategory?: 'small' | 'medium' | 'large'): number => {
  // Return 0 for all devices to ensure normal opening and high clarity
  return 0;
};

/**
 * Get optimal scan area dimensions based on device size
 */
export const getOptimalScanArea = (): { width: number; height: number } => {
  const { width, height } = Dimensions.get('window');
  const deviceCategory = getDeviceCategory();
  
  let scanAreaWidthRatio = 0.85;
  let scanAreaHeight = 120;
  
  if (deviceCategory === 'small') {
    scanAreaWidthRatio = 0.90;
    scanAreaHeight = 100;
  } else if (deviceCategory === 'large') {
    scanAreaWidthRatio = 0.75;
    scanAreaHeight = 150;
  }
  
  return {
    width: width * scanAreaWidthRatio,
    height: scanAreaHeight,
  };
};

/**
 * Get camera resolution with device-adaptive fallback strategy
 * Tries multiple aspect ratios to ensure we get the best resolution available
 * Adapts target resolution based on device size for HIGH CLARITY
 */
export const getOptimalCameraResolution = async (
  cameraRef: any
): Promise<{
  resolution: string | undefined;
  megapixels: number;
  aspectRatio: string;
  deviceCategory: 'small' | 'medium' | 'large';
} | null> => {
  if (!cameraRef) {
    return null;
  }

  const deviceCategory = getDeviceCategory();
  const targetMegapixels = getTargetMegapixels(deviceCategory);
  
  // Try different aspect ratios in order of preference
  const aspectRatios = ['16:9', '4:3', '1:1', '3:2', '9:16'];
  let bestResult = null;
  let bestMegapixels = 0;

  for (const aspectRatio of aspectRatios) {
    try {
      const sizes = await cameraRef.getAvailablePictureSizesAsync(aspectRatio);

      if (sizes && sizes.length > 0) {
        // First, try to find a resolution within the target range
        const filteredSizes = filterResolutionsByMegapixels(sizes, targetMegapixels);
        
        let result = null;
        if (filteredSizes.length > 0) {
          result = {
            resolution: filteredSizes[0].resolution,
            megapixels: filteredSizes[0].megapixels,
          };
        } else {
          // If no resolution in target range, get the highest available
          result = getHighestResolution(sizes);
        }

        if (result && result.megapixels > bestMegapixels) {
          bestMegapixels = result.megapixels;
          bestResult = {
            resolution: result.resolution,
            megapixels: result.megapixels,
            aspectRatio,
            deviceCategory,
          };
        }
      }
    } catch (error) {
      // Continue to next aspect ratio if this one fails
      console.warn(`Failed to get picture sizes for aspect ratio ${aspectRatio}:`, error);
    }
  }

  // If no specific aspect ratio worked, try getting all available sizes
  if (!bestResult) {
    try {
      const allSizes = await cameraRef.getAvailablePictureSizesAsync('4:3');
      if (allSizes && allSizes.length > 0) {
        const result = getHighestResolution(allSizes);
        if (result) {
          bestResult = {
            resolution: result.resolution,
            megapixels: result.megapixels,
            aspectRatio: '4:3',
            deviceCategory,
          };
        }
      }
    } catch (error) {
      console.warn('Failed to get any picture sizes:', error);
    }
  }

  return bestResult;
};

/**
 * Format megapixels for display (e.g., "64 MP")
 */
export const formatMegapixels = (megapixels: number): string => {
  if (megapixels >= 1) {
    return `${Math.round(megapixels)} MP`;
  }
  return `${(megapixels * 1000).toFixed(0)} KP`;
};

/**
 * Get autofocus mode based on device category
 */
export const getOptimalAutofocus = (deviceCategory?: 'small' | 'medium' | 'large'): 'on' | 'auto' => {
  const category = deviceCategory || getDeviceCategory();
  
  // Use continuous autofocus for all devices
  return 'on';
};
