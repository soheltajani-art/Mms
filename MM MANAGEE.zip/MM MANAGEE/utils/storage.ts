import { saveSetting, getSetting } from '../app/data/sqlite';

/**
 * Saves data to SQLite database.
 * @param key The key to save the data under.
 * @param value The value to save.
 */
export const saveData = async (key: string, value: any): Promise<void> => {
  try {
    const jsonValue = JSON.stringify(value);
    await saveSetting(key, jsonValue);
  } catch (e) {
    // saving error
    console.error('Error saving data to SQLite', e);
  }
};

/**
 * Gets data from SQLite database.
 * @param key The key of the data to retrieve.
 * @returns The stored value, or null if it doesn't exist.
 */
export const getData = async (key: string): Promise<any | null> => {
  try {
    const jsonValue = await getSetting(key);
    return jsonValue != null ? JSON.parse(jsonValue) : null;
  } catch (e) {
    // error reading value
    console.error('Error getting data from SQLite', e);
    return null;
  }
};
