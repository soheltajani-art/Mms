import { getDatabase } from './sqlite';

const AVAILABLE_STOCK_KEY = 'available_stock';
const SOLD_STOCK_KEY = 'sold_stock';
const HISTORY_KEY = 'transaction_history';

export interface StockItem {
  id: string;
  name?: string;
  status?: string;
  model?: string;
  modelNo?: string;
  inventory?: number;
  primaryImei: string;
  purchaseCost?: number;
  buyingPrice?: number;
  mopValue: number;
  frontImage?: string;
  backImage?: string;
  purchaseDate: string;
  sellingPrice?: number;
  soldDate?: string;
  compulsoryPhoto?: string;
  optionalPhoto?: string;
  type?: 'PURCHASE' | 'SOLD'; // To distinguish between purchase and sold items
}

export interface HistoryItem {
  id: string;
  type: 'PURCHASE' | 'SOLD';
  model: string;
  primaryImei: string;
  purchaseCost: number;
  mopValue: number;
  sellingPrice?: number;
  profit?: number;
  purchaseDate: string;
  soldDate?: string;
  timestamp: string;
  compulsoryPhoto?: string;
  optionalPhoto?: string;
}

/**
 * Utility function to get a consistent date string in local timezone (YYYY-MM-DD)
 * This ensures consistent date comparisons across all platforms
 */
export const getLocalDateString = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

/**
 * Extract date portion from ISO string in local timezone
 */
export const extractLocalDateFromISO = (isoString: string): string => {
  const date = new Date(isoString);
  return getLocalDateString(date);
};

export const getAvailableStock = async (): Promise<StockItem[]> => {
  try {
    const db = await getDatabase();
    const results = await db.getAllAsync<StockItem>(
      `SELECT * FROM stock WHERE type IS NULL OR type = 'PURCHASE' ORDER BY purchaseDate DESC`
    );
    return results || [];
  } catch (error) {
    console.error('Failed to get available stock', error);
    return [];
  }
};

export const addAvailableStock = async (newItem: StockItem): Promise<{ duplicate: boolean; message?: string }> => {
  try {
    const duplicateCheck = await checkImeiStatus(newItem.primaryImei);
    if (duplicateCheck.isDuplicate) {
      return { duplicate: true, message: duplicateCheck.message };
    }

    // Normalize data before saving
    const normalizedItem: StockItem = {
      ...newItem,
      model: newItem.model || newItem.modelNo || 'Unknown',
      purchaseCost: newItem.purchaseCost || newItem.buyingPrice || 0,
      type: 'PURCHASE',
    };

    const db = await getDatabase();
    await db.runAsync(
      `INSERT INTO stock (id, name, status, model, modelNo, inventory, primaryImei, purchaseCost, buyingPrice, mopValue, frontImage, backImage, purchaseDate, sellingPrice, soldDate, compulsoryPhoto, optionalPhoto, type)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        normalizedItem.id,
        normalizedItem.name || '',
        normalizedItem.status || 'Available',
        normalizedItem.model,
        normalizedItem.modelNo || '',
        normalizedItem.inventory || 1,
        normalizedItem.primaryImei,
        normalizedItem.purchaseCost,
        normalizedItem.buyingPrice || 0,
        normalizedItem.mopValue,
        normalizedItem.frontImage || '',
        normalizedItem.backImage || '',
        normalizedItem.purchaseDate,
        normalizedItem.sellingPrice || 0,
        normalizedItem.soldDate || '',
        normalizedItem.compulsoryPhoto || '',
        normalizedItem.optionalPhoto || '',
        'PURCHASE',
      ]
    );

    const historyItem: HistoryItem = {
      id: normalizedItem.id,
      type: 'PURCHASE',
      model: normalizedItem.model!,
      primaryImei: normalizedItem.primaryImei,
      purchaseCost: normalizedItem.purchaseCost!,
      mopValue: normalizedItem.mopValue,
      purchaseDate: normalizedItem.purchaseDate,
      timestamp: new Date().toISOString(),
      compulsoryPhoto: normalizedItem.compulsoryPhoto,
      optionalPhoto: normalizedItem.optionalPhoto,
    };
    await addHistory(historyItem);
    return { duplicate: false };
  } catch (error) {
    console.error('Failed to add available stock', error);
    throw error;
  }
};

export const checkImeiStatus = async (imei: string): Promise<{ isDuplicate: boolean; status?: 'Available' | 'Sold'; message?: string }> => {
  if (!imei || imei.length < 15) {
    return { isDuplicate: false };
  }
  try {
    const db = await getDatabase();

    // Check available stock
    const availableItem = await db.getFirstAsync<{ model: string }>(
      `SELECT model FROM stock WHERE primaryImei = ? AND type = 'PURCHASE'`,
      [imei]
    );

    if (availableItem) {
      return { isDuplicate: true, status: 'Available', message: `IMEI already exists in available stock for model ${availableItem.model}.` };
    }

    // Check sold stock
    const soldItem = await db.getFirstAsync<{ model: string }>(
      `SELECT model FROM stock WHERE primaryImei = ? AND type = 'SOLD'`,
      [imei]
    );

    if (soldItem) {
      return { isDuplicate: true, status: 'Sold', message: 'This product has been sold and cannot be repurchased.' };
    }

    return { isDuplicate: false };
  } catch (error) {
    console.error('Failed to check IMEI status', error);
    return { isDuplicate: false };
  }
};

export const removeAvailableStock = async (itemId: string): Promise<void> => {
  try {
    const db = await getDatabase();
    await db.runAsync(`DELETE FROM stock WHERE id = ?`, [itemId]);
  } catch (error) {
    console.error('Failed to remove available stock', error);
  }
};

export const getSoldStock = async (): Promise<StockItem[]> => {
  try {
    const db = await getDatabase();
    const results = await db.getAllAsync<StockItem>(
      `SELECT * FROM stock WHERE type = 'SOLD' ORDER BY soldDate DESC`
    );
    return results || [];
  } catch (error) {
    console.error('Failed to get sold stock', error);
    return [];
  }
};

export const addSoldStock = async (soldItem: StockItem): Promise<void> => {
  try {
    const db = await getDatabase();

    const purchaseCost = soldItem.purchaseCost || soldItem.buyingPrice || 0;
    const model = soldItem.model || soldItem.modelNo || 'Unknown';

    // Update the existing stock item to mark it as sold
    await db.runAsync(
      `UPDATE stock SET type = 'SOLD', sellingPrice = ?, soldDate = ?, status = 'Sold' WHERE id = ?`,
      [soldItem.sellingPrice || 0, soldItem.soldDate || '', soldItem.id]
    );

    const profit = (soldItem.sellingPrice || 0) - purchaseCost;
    const historyItem: HistoryItem = {
      id: soldItem.id,
      type: 'SOLD',
      model: model,
      primaryImei: soldItem.primaryImei,
      purchaseCost: purchaseCost,
      mopValue: soldItem.mopValue,
      sellingPrice: soldItem.sellingPrice || 0,
      profit: profit,
      purchaseDate: soldItem.purchaseDate,
      soldDate: soldItem.soldDate || '',
      timestamp: new Date().toISOString(),
      compulsoryPhoto: soldItem.compulsoryPhoto || '',
      optionalPhoto: soldItem.optionalPhoto || '',
    };
    await addHistory(historyItem);
  } catch (error) {
    console.error('Failed to add sold stock', error);
  }
};

export const getHistory = async (): Promise<HistoryItem[]> => {
  try {
    const db = await getDatabase();
    const results = await db.getAllAsync<HistoryItem>(
      `SELECT * FROM history ORDER BY timestamp DESC`
    );
    return results || [];
  } catch (error) {
    console.error('Failed to get history', error);
    return [];
  }
};

export const addHistory = async (historyItem: HistoryItem): Promise<void> => {
  try {
    const db = await getDatabase();
    await db.runAsync(
      `INSERT INTO history (id, type, model, primaryImei, purchaseCost, mopValue, sellingPrice, profit, purchaseDate, soldDate, timestamp, compulsoryPhoto, optionalPhoto)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        historyItem.id,
        historyItem.type,
        historyItem.model,
        historyItem.primaryImei,
        historyItem.purchaseCost,
        historyItem.mopValue,
        historyItem.sellingPrice || 0,
        historyItem.profit || 0,
        historyItem.purchaseDate,
        historyItem.soldDate || '',
        historyItem.timestamp,
        historyItem.compulsoryPhoto || '',
        historyItem.optionalPhoto || '',
      ]
    );
  } catch (error) {
    console.error('Failed to add history', error);
  }
};

/**
 * Get available stock item by IMEI
 */
export const getAvailableStockByImei = async (imei: string): Promise<{ item: StockItem | null; error: string | null }> => {
  try {
    const db = await getDatabase();
    const item = await db.getFirstAsync<StockItem>(
      `SELECT * FROM stock WHERE primaryImei = ? AND (type IS NULL OR type = 'PURCHASE')`,
      [imei]
    );

    if (item) {
      // Normalize item on retrieval just in case legacy data exists
      const normalizedItem: StockItem = {
        ...item,
        model: item.model || item.modelNo || 'Unknown',
        purchaseCost: item.purchaseCost || item.buyingPrice || 0,
      };
      return { item: normalizedItem, error: null };
    }

    return { item: null, error: 'Product not found in available stock.' };
  } catch (error) {
    console.error('Failed to get available stock by IMEI', error);
    return { item: null, error: 'An error occurred while searching for the product.' };
  }
};

/**
 * Sell a stock item - moves it from available to sold and updates history
 */
export const sellStockItem = async (itemId: string, saleData: {
  sellingPrice: number;
  customerName: string;
  customerContact: string;
  saleDate: string;
  customerPhoto: string;
}): Promise<void> => {
  try {
    const db = await getDatabase();

    // Get the item from available stock
    const itemToSell = await db.getFirstAsync<StockItem>(
      `SELECT * FROM stock WHERE id = ? AND (type IS NULL OR type = 'PURCHASE')`,
      [itemId]
    );

    if (!itemToSell) {
      throw new Error('Product not found in available stock.');
    }

    // Create sold item with all original data plus sale information
    const soldItem: StockItem = {
      ...itemToSell,
      sellingPrice: saleData.sellingPrice,
      soldDate: saleData.saleDate,
      type: 'SOLD',
    };

    // Add to sold stock
    await addSoldStock(soldItem);
  } catch (error) {
    console.error('Failed to sell stock item', error);
    throw error;
  }
};

/**
 * Get statistics for a specific date using consistent local timezone date comparison
 */
export const getStatsForDate = async (date: Date) => {
  try {
    const availableStock = await getAvailableStock();
    const history = await getHistory();

    // Use consistent local date string for comparison
    const targetDateString = getLocalDateString(date);

    const purchasesForDate = history.filter(
      item => item.type === 'PURCHASE' && extractLocalDateFromISO(item.purchaseDate) === targetDateString
    );

    const soldForDate = history.filter(
      item => item.type === 'SOLD' && item.soldDate && extractLocalDateFromISO(item.soldDate) === targetDateString
    );

    const salesRupeesForDate = soldForDate.reduce((acc, item) => acc + (item.sellingPrice || 0), 0);

    const profitForDate = soldForDate.reduce((acc, item) => {
      const itemProfit = item.profit !== undefined ? item.profit : ((item.sellingPrice || 0) - (item.purchaseCost || 0));
      return acc + itemProfit;
    }, 0);

    // Get recent products for the specified date
    const transactionsForDate = history.filter(item => {
      const itemDate = item.type === 'PURCHASE'
        ? extractLocalDateFromISO(item.purchaseDate)
        : (item.soldDate ? extractLocalDateFromISO(item.soldDate) : null);
      return itemDate === targetDateString;
    }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

    // Convert history items to StockItem format for display
    const recentProducts: StockItem[] = transactionsForDate.slice(0, 10).map(histItem => ({
      id: histItem.id,
      name: histItem.model,
      status: histItem.type === 'SOLD' ? 'Sold' : 'Available',
      model: histItem.model,
      modelNo: histItem.model,
      inventory: 1,
      primaryImei: histItem.primaryImei,
      purchaseCost: histItem.purchaseCost,
      buyingPrice: histItem.purchaseCost,
      mopValue: histItem.mopValue,
      frontImage: '',
      backImage: '',
      purchaseDate: histItem.purchaseDate,
      sellingPrice: histItem.sellingPrice,
      soldDate: histItem.soldDate,
      compulsoryPhoto: histItem.compulsoryPhoto,
      optionalPhoto: histItem.optionalPhoto,
      type: histItem.type,
    }));

    return {
      totalStock: availableStock.length,
      todaysPurchases: purchasesForDate.length,
      todaysSold: soldForDate.length,
      todaysSalesRupees: salesRupeesForDate,
      todaysProfit: profitForDate,
      recentProducts,
    };
  } catch (error) {
    console.error('Failed to get stats for date', error);
    return {
      totalStock: 0,
      todaysPurchases: 0,
      todaysSold: 0,
      todaysSalesRupees: 0,
      todaysProfit: 0,
      recentProducts: [],
    };
  }
};

/**
 * Get today's statistics including purchases, sales, and recent products
 */
export const getTodayStats = async () => {
  return getStatsForDate(new Date());
};

export const clearAllProducts = async (): Promise<void> => {
  try {
    const db = await getDatabase();
    await db.execAsync(`
      DELETE FROM stock;
      DELETE FROM history;
    `);
  } catch (error) {
    console.error('Failed to clear product data', error);
  }
};

/**
 * Search available stock by model name or IMEI
 */
export const searchAvailableStock = async (query: string): Promise<StockItem[]> => {
  try {
    const db = await getDatabase();
    const searchQuery = `%${query}%`;
    const results = await db.getAllAsync<StockItem>(
      `SELECT * FROM stock 
       WHERE (type IS NULL OR type = 'PURCHASE') 
       AND (model LIKE ? OR primaryImei LIKE ?) 
       ORDER BY purchaseDate DESC`,
      [searchQuery, searchQuery]
    );
    return results || [];
  } catch (error) {
    console.error('Failed to search available stock', error);
    return [];
  }
};
