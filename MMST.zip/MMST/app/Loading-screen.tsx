import { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width } = Dimensions.get('window');
const cardWidth = Math.min(width * 0.9, 400);

// Correct way to get the number of dots for the animation
const numDots = 49;

export default function LoadingPage() {
  const router = useRouter();
  const [typedText, setTypedText] = useState('');

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.95)).current;
  const presentsAnim = useRef(new Animated.Value(0)).current; // For the "PRESENTS" text
  const lineAnim1 = useRef(new Animated.Value(0)).current;
  const lineAnim2 = useRef(new Animated.Value(0)).current;
  const lineAnim3 = useRef(new Animated.Value(0)).current;
  const circleScaleAnim = useRef(new Animated.Value(0)).current;
  const bottomLineAnim1 = useRef(new Animated.Value(0)).current;
  const bottomLineAnim2 = useRef(new Animated.Value(0)).current;
  const bottomLineAnim3 = useRef(new Animated.Value(0)).current;
  const dotAnims = useRef(Array.from({ length: numDots }).map(() => new Animated.Value(0))).current;

  useEffect(() => {
    const targetText = 'Powered by Mohammed Sohel Tajani';
    let index = 0;
    
    // Using a more reliable typing effect
    const typingInterval = setInterval(() => {
      setTypedText(targetText.slice(0, index + 1));
      index++;
      if (index >= targetText.length) {
        clearInterval(typingInterval);
      }
    }, 80);

    // Animation sequence
    Animated.sequence([
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 5,
          useNativeDriver: true,
        }),
        Animated.timing(presentsAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
        Animated.timing(circleScaleAnim, {
          toValue: 1,
          duration: 800,
          useNativeDriver: true,
        }),
      ]),
      Animated.parallel([
        Animated.stagger(150, [
          Animated.timing(lineAnim1, { toValue: 1, duration: 400, useNativeDriver: true }),
          Animated.timing(lineAnim2, { toValue: 1, duration: 400, useNativeDriver: true }),
          Animated.timing(lineAnim3, { toValue: 1, duration: 400, useNativeDriver: true }),
        ]),
        Animated.stagger(20, dotAnims.map(anim =>
          Animated.spring(anim, {
            toValue: 1,
            speed: 20,
            bounciness: 12,
            useNativeDriver: true,
          }))
        ),
        Animated.stagger(150, [
          Animated.timing(bottomLineAnim1, { toValue: 1, duration: 400, useNativeDriver: true }),
          Animated.timing(bottomLineAnim2, { toValue: 1, duration: 400, useNativeDriver: true }),
          Animated.timing(bottomLineAnim3, { toValue: 1, duration: 400, useNativeDriver: true }),
        ]),
      ])
    ]).start();

    const checkFirstLaunch = async () => {
      try {
        const hasSeenWelcome = await AsyncStorage.getItem('hasSeenWelcome');
        const isReturningFromWelcome = await AsyncStorage.getItem('isReturningFromWelcome');
        
        setTimeout(async () => {
          if (isReturningFromWelcome === 'true') {
            // New user flow: Step 3 (Returning from Welcome to Dashboard)
            await AsyncStorage.setItem('hasSeenWelcome', 'true');
            await AsyncStorage.removeItem('isReturningFromWelcome');
            router.replace('/(tabs)');
          } else if (hasSeenWelcome === 'true') {
            // Old user flow: Step 2 (Loading to Dashboard)
            router.replace('/(tabs)');
          } else {
            // New user flow: Step 1 (Loading to Welcome)
            router.replace('/WelcomePage');
          }
        }, 5000);
      } catch (error) {
        console.error('Failed to check first launch', error);
        router.replace('/(tabs)');
      }
    };
    checkFirstLaunch();

    return () => {
        clearInterval(typingInterval);
    };
  }, []);

  // Interpolated styles
  const line1Scale = lineAnim1.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const line2Scale = lineAnim2.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const line3Scale = lineAnim3.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const bottomLine1Scale = bottomLineAnim1.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const bottomLine2Scale = bottomLineAnim2.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });
  const bottomLine3Scale = bottomLineAnim3.interpolate({ inputRange: [0, 1], outputRange: [0, 1] });

  const presentsOpacity = presentsAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [0, 1],
  });
  const presentsScale = presentsAnim.interpolate({
      inputRange: [0, 1],
      outputRange: [0.9, 1],
  });

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.card, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
        <View style={styles.cardInner}>
          <Animated.View style={[styles.presentsContainer, { opacity: presentsOpacity, transform: [{ scale: presentsScale }] }]}>
            <Text style={styles.presentsText}>PRESENTS</Text>
          </Animated.View>

          <View style={styles.topRightLines}>
            <Animated.View style={[styles.line, { width: 64, transform: [{ scaleX: line1Scale }] }]} />
            <Animated.View style={[styles.line, { width: 64, transform: [{ scaleX: line2Scale }] }]} />
            <Animated.View style={[styles.line, { width: 64, transform: [{ scaleX: line3Scale }] }]} />
          </View>

          <View style={styles.mainTextContainer}>
            <Text style={styles.mainText}>TAJANI</Text>
            <Text style={styles.mainText}>STUDIO</Text>
          </View>

          <Animated.View style={[styles.circle, { transform: [{ scale: circleScaleAnim }] }]} />

          <View style={styles.bottomRightContainer}>
             <View style={styles.grid}>
              {dotAnims.map((anim, i) => (
                <Animated.View
                    key={i}
                    style={[styles.dot, {
                        opacity: anim,
                        transform: [{ scale: anim }]
                    }]}
                />
              ))}
            </View>
            <View style={styles.bottomRightLines}>
                 <Animated.View style={[styles.bottomLine, { width: 128, transform: [{ scaleX: bottomLine1Scale }] }]} />
                 <Animated.View style={[styles.bottomLine, { width: 128, transform: [{ scaleX: bottomLine2Scale }] }]} />
                 <Animated.View style={[styles.bottomLine, { width: 128, transform: [{ scaleX: bottomLine3Scale }] }]} />
            </View>
          </View>

        </View>
      </Animated.View>
      <View style={styles.footerContainer}>
        <Text style={styles.footerText}>{typedText}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
  },
  card: {
    width: cardWidth,
    aspectRatio: 3 / 4,
    padding: 24,
  },
  cardInner: {
    flex: 1,
    position: 'relative',
  },
  presentsContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: '#4A90E2',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 999,
  },
  presentsText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
    letterSpacing: 1.5,
  },
  topRightLines: {
    position: 'absolute',
    top: 8,
    right: 0,
    gap: 4,
    alignItems: 'flex-end',
  },
  line: {
    height: 4,
    backgroundColor: '#4A90E2',
    transformOrigin: 'right',
  },
  mainTextContainer: {
    position: 'absolute',
    top: '25%',
    left: 0,
    width: '100%',
  },
  mainText: {
    fontSize: 72,
    fontWeight: '900',
    color: '#000000',
    lineHeight: 72,
  },
  circle: {
    position: 'absolute',
    bottom: -80,
    left: -80,
    width: 220,
    height: 220,
    borderRadius: 110,
    borderWidth: 28,
    borderColor: '#4A90E2',
  },
  bottomRightContainer: {
      position: 'absolute',
      bottom: 0,
      right: 0,
      alignItems: 'flex-end',
      gap: 24,
  },
  grid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      width: 120,
      justifyContent: 'flex-end',
  },
  dot: {
      width: 6,
      height: 6,
      backgroundColor: '#4A90E2',
      borderRadius: 3,
      margin: 3,
  },
  bottomRightLines: {
      gap: 8,
      transform: [{ rotate: '-45deg' }],
      transformOrigin: 'bottom right',
      position: 'relative',
      right: -50,
      bottom: 20,
      alignItems: 'flex-end',
  },
  bottomLine: {
      height: 4,
      backgroundColor: '#4A90E2',
      borderRadius: 2,
      transformOrigin: 'right',
  },
  footerContainer: {
    position: 'absolute',
    bottom: Platform.OS === 'android' ? 40 : 20,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerText: {
    fontSize: 12,
    color: '#666666',
    textAlign: 'center',
  }
});
