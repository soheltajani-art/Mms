import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Animated, Platform, Dimensions } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { ChevronLeft, FileText, CheckCircle } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFonts, DancingScript_700Bold } from '@expo-google-fonts/dancing-script';
import { BlurView } from 'expo-blur';

const { width } = Dimensions.get('window');

const MyAgreementPage = () => {
  const router = useRouter();
  const [userName, setUserName] = useState('');
  const stampAnim = useRef(new Animated.Value(0)).current;

  let [fontsLoaded] = useFonts({
    DancingScript_700Bold,
  });

  useEffect(() => {
    const fetchUserName = async () => {
      const storedUserName = await AsyncStorage.getItem('userName');
      if (storedUserName) {
        setUserName(storedUserName);
      }
    };
    fetchUserName();

    Animated.spring(stampAnim, {
      toValue: 1,
      friction: 3,
      tension: 40,
      useNativeDriver: true,
    }).start();
  }, []);

  const agreements = [
    { id: 'terms', label: 'TERMS AND CONDITIONS', route: '/terms-and-conditions' },
    { id: 'privacy', label: 'PRIVACY AND POLICY', route: '/privacy-policy' },
    { id: 'agreement', label: 'USER AGREEMENT', route: '/user-agreement' },
    { id: 'policy', label: 'ACCEPTABLE USE POLICY', route: '/acceptable-use-policy' },
    { id: 'disclaimer', label: 'DISCLAIMER', route: '/disclaimer' },
  ];

  const stampRotation = stampAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['-20deg', '0deg'],
  });

  const stampScale = stampAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [1.5, 1],
  });

  if (!fontsLoaded) {
    return null;
  }

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#B71C1C" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Agreement</Text>
        <View style={{ width: 40 }}/>
      </View>
      
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.contentCard}>
            <View style={styles.iconContainer}>
              <FileText size={32} color="#D32F2F" />
            </View>
            <Text style={styles.title}>Agreements Confirmation</Text>
            <Text style={styles.subtitle}>
              This document confirms the legal terms and policies you accepted during setup.
            </Text>

            <View style={styles.noticeBox}>
              <CheckCircle size={20} color="#D32F2F" />
              <View style={styles.noticeContent}>
                  <Text style={styles.noticeTitle}>Verified Agreement</Text>
                  <Text style={styles.noticeText}>
                    The following terms are legally binding and currently active for your account.
                  </Text>
              </View>
            </View>

            <View style={styles.agreementsList}>
              {agreements.map((agreement) => (
                  <TouchableOpacity 
                    style={styles.agreementRow} 
                    key={agreement.id}
                    onPress={() => router.push(agreement.route)}
                  >
                    <View style={styles.agreementLabel}>
                        <CheckCircle size={18} color="#D32F2F" />
                        <Text style={styles.agreementText}>{agreement.label}</Text>
                    </View>
                    <Text style={styles.viewText}>VIEW</Text>
                  </TouchableOpacity>
              ))}
              
              <Animated.View pointerEvents="none" style={[styles.stampContainer, {
                opacity: stampAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, 0.8],
                }),
                transform: [
                    { scale: stampScale },
                    { rotate: stampRotation }
                ]
              }]}>
                <View style={styles.stamp}>
                  <BlurView intensity={20} tint="light" style={StyleSheet.absoluteFill} />
                  <Text style={styles.stampTextTitle}>MOBILE STOCK</Text>
                  <Text style={styles.stampTextSubtitle}>OFFICIAL SEAL</Text>
                  <Text style={styles.stampTextStatus}>ACCEPTED</Text>
                </View>
              </Animated.View>
            </View>

            <View style={styles.signatureSection}>
              <Text style={styles.signatureTitle}>DIGITAL SIGNATURE</Text>
              <Text 
                style={[
                  styles.signatureName, 
                  userName.length > 10 && { fontSize: 40 },
                  userName.length > 15 && { fontSize: 32 }
                ]}
                numberOfLines={1}
                adjustsFontSizeToFit
              >
                {userName || 'User Name'}
              </Text>
              <View style={styles.signatureLine} />
              <View style={styles.footerInfo}>
                <Text style={styles.dateText}>DATE: {new Date().toLocaleDateString()}</Text>
                <Text style={styles.verifiedText}>STATUS: VERIFIED</Text>
              </View>
            </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    marginTop: Platform.OS === 'android' ? 40 : 16,
    borderWidth: 2,
    borderColor: '#FFEBEE',
    shadowColor: '#D32F2F',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#B71C1C',
  },
  backButton: {
    backgroundColor: '#FFEBEE',
    borderRadius: 12,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#FFCDD2',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 32,
  },
  contentCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    marginHorizontal: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.05,
    shadowRadius: 12,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F3F4F6',
  },
  iconContainer: {
    backgroundColor: '#FFF5F5',
    borderRadius: 20,
    padding: 16,
    marginBottom: 16,
    alignSelf: 'center',
    borderWidth: 1,
    borderColor: '#FFEBEE',
  },
  title: {
    fontSize: 22,
    fontWeight: '900',
    textAlign: 'center',
    marginBottom: 8,
    color: '#1A202C',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 14,
    color: '#718096',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
    paddingHorizontal: 8,
  },
  noticeBox: {
    backgroundColor: '#FFF5F5',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#FFCDD2',
    borderStyle: 'dashed',
  },
  noticeContent: {
    marginLeft: 12,
    flex: 1,
  },
  noticeTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: '#B71C1C',
  },
  noticeText: {
    fontSize: 13,
    color: '#D32F2F',
    marginTop: 2,
    fontWeight: '500',
  },
  agreementsList: {
    width: '100%',
    borderColor: '#FFEBEE',
    borderWidth: 1.5,
    borderRadius: 20,
    paddingHorizontal: 4,
    paddingVertical: 4,
    marginBottom: 24,
    position: 'relative',
    overflow: 'visible',
    backgroundColor: '#FDF2F2',
  },
  agreementRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#FFEBEE',
  },
  agreementLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  agreementText: {
    fontSize: 13,
    marginLeft: 10,
    color: '#2D3748',
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  viewText: {
    fontSize: 12,
    color: '#D32F2F',
    fontWeight: '900',
    letterSpacing: 0.5,
    backgroundColor: '#fff',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FFCDD2',
  },
  stampContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
  },
  stamp: {
    backgroundColor: 'transparent',
    paddingHorizontal: 30,
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 4,
    borderColor: 'rgba(0, 0, 0, 0.1)',
    alignItems: 'center',
    overflow: 'hidden',
  },
  stampTextTitle: {
    color: '#000000',
    fontWeight: '900',
    fontSize: 16,
    textAlign: 'center',
  },
  stampTextSubtitle: {
    color: '#000000',
    fontWeight: '900',
    fontSize: 12,
    textAlign: 'center',
    marginVertical: 2,
  },
  stampTextStatus: {
    color: '#000000',
    fontWeight: '900',
    fontSize: 18,
    textAlign: 'center',
  },
  signatureSection: {
    width: '100%',
    alignItems: 'center',
    marginTop: 8,
    padding: 20,
    backgroundColor: '#FFF5F5',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#FFEBEE',
  },
  signatureTitle: {
    fontSize: 11,
    color: '#B71C1C',
    marginBottom: 8,
    letterSpacing: 2,
    fontWeight: '900',
  },
  signatureName: {
    fontSize: 48,
    color: '#1A202C',
    fontFamily: 'DancingScript_700Bold',
    textAlign: 'center',
    width: '100%',
  },
  signatureLine: {
    width: '100%',
    height: 2,
    backgroundColor: '#D32F2F',
    marginVertical: 12,
    opacity: 0.6,
  },
  footerInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  dateText: {
    fontSize: 11,
    color: '#718096',
    fontWeight: '700',
  },
  verifiedText: {
    fontSize: 11,
    color: '#38A169',
    fontWeight: '900',
  },
});

export default MyAgreementPage;
