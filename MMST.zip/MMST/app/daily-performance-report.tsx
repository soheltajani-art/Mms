import { router, useFocusEffect, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useState, useEffect } from 'react';
import { StyleSheet, View, Text, TextInput, Modal, Image, TouchableOpacity, Platform } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { getHistory, HistoryItem } from '@/utils/database';
import SalesReport from './components/SalesReport';

const DailyPerformanceReport = () => {
  const [sales, setSales] = useState<HistoryItem[]>([]);
  const [filteredSales, setFilteredSales] = useState<HistoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState<string | undefined>(undefined);
  const params = useLocalSearchParams();
  const { date } = params;

  const fetchSalesForDate = useCallback(async () => {
    const history = await getHistory();
    const targetDate = date ? new Date(date as string) : new Date();
    targetDate.setHours(0, 0, 0, 0); // Start of the day

    const salesForDate = history.filter(item => {
        if (item.soldDate) {
            const soldDate = new Date(item.soldDate);
            return soldDate.toDateString() === targetDate.toDateString();
        }
        return false;
    });
    setSales(salesForDate);
  }, [date]);

  useFocusEffect(
    useCallback(() => {
      fetchSalesForDate();
    }, [fetchSalesForDate])
  );

  useEffect(() => {
    const filtered = sales.filter(item =>
      item.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.primaryImei.includes(searchQuery)
    );
    setFilteredSales(filtered);
  }, [searchQuery, sales]);

  const handleViewPhoto = (photoUri: string | undefined) => {
    if (photoUri) {
      setPreviewPhotoUri(photoUri);
      setShowPhotoPreview(true);
    }
  };

  const headerTitle = date 
    ? `Sales for ${new Date(date as string).toLocaleDateString()}` 
    : "Today's Sales Report";

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Feather name="chevron-left" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{headerTitle}</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.topBar}>
        <View style={[styles.searchContainer, focusedField === 'search' && styles.searchContainerFocused]}>
          <TextInput 
            style={[
              styles.search,
              Platform.OS === 'web' && { outline: 'none' } as any
            ]} 
            placeholder="Search by model or IMEI..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            onFocus={() => setFocusedField('search')}
            onBlur={() => setFocusedField(null)}
          />
        </View>
      </View>

      {filteredSales.length > 0 ? (
        <SalesReport sales={filteredSales} onViewPhoto={handleViewPhoto} />
      ) : (
        <Text style={styles.noSalesText}>No sales recorded for this day yet.</Text>
      )}

      <Modal
        animationType="slide"
        transparent={true}
        visible={showPhotoPreview}
        onRequestClose={() => setShowPhotoPreview(false)}
      >
        <View style={styles.modalContainer}>
          <Image source={{ uri: previewPhotoUri }} style={styles.previewImage} resizeMode="contain" />
          <TouchableOpacity style={styles.closeButton} onPress={() => setShowPhotoPreview(false)}>
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    margin: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  topBar: {
    marginBottom: 15,
  },
  search: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    fontSize: 16,
    flex: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    marginHorizontal: 16,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  searchContainerFocused: {
    borderColor: '#1565C0',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  noSalesText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#666',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
  },
  previewImage: {
    width: '90%',
    height: '80%',
  },
  closeButton: {
    position: 'absolute',
    top: 40,
    right: 20,
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 5,
  },
  closeButtonText: {
    color: 'black',
    fontWeight: 'bold',
  },
});

export default DailyPerformanceReport;
