import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, TextInput, Platform } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useRouter, useFocusEffect, useLocalSearchParams } from 'expo-router';
import { getStatsForDate, StockItem } from './data/storage';
import { LinearGradient } from 'expo-linear-gradient';
import ProductCard from './components/ProductCard';
import DashboardStats from './components/DashboardStats';
import { ChevronLeft } from 'lucide-react-native';
import DatePickerModal from './components/DatePickerModal';

const DailyPerformancePage = () => {
  const router = useRouter();
  const params = useLocalSearchParams();
  const { date } = params;

  const [todaysPurchases, setTodaysPurchases] = useState(0);
  const [todaysSold, setTodaysSold] = useState(0);
  const [todaysSalesRupees, setTodaysSalesRupees] = useState(0);
  const [todaysProfit, setTodaysProfit] = useState(0);
  const [allProducts, setAllProducts] = useState<StockItem[]>([]);
  const [products, setProducts] = useState<StockItem[]>([]);
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [allDataLoaded, setAllDataLoaded] = useState(false);
  const PRODUCTS_PER_PAGE = 20;

  const [showDatePicker, setShowDatePicker] = useState(false);
  const [currentDate, setCurrentDate] = useState(date ? new Date(date as string) : new Date());

  useFocusEffect(
    useCallback(() => {
      const fetchData = async () => {
        const targetDate = date ? new Date(date as string) : new Date();
        setCurrentDate(targetDate);
        const stats = await getStatsForDate(targetDate);
        setTodaysPurchases(stats.todaysPurchases);
        setTodaysSold(stats.todaysSold);
        setTodaysSalesRupees(stats.todaysSalesRupees);
        setTodaysProfit(stats.todaysProfit);
        setAllProducts(stats.recentProducts);
        setPage(1);
        setAllDataLoaded(false);
        setProducts([]);
      };
      fetchData();
    }, [date])
  );

  const handleDateChange = (selectedDate: Date) => {
    const newDate = new Date(selectedDate);
    router.push(`/daily-performance?date=${newDate.toISOString()}`);
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const filteredAllProducts = useMemo(
    () => allProducts.filter(p => {
      const modelMatch = p.model?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false;
      const imeiMatch = p.primaryImei?.includes(searchQuery) ?? false;
      return modelMatch || imeiMatch;
    }),
    [allProducts, searchQuery]
  );

  useEffect(() => {
    if (allDataLoaded) return;
    const newItems = filteredAllProducts.slice((page - 1) * PRODUCTS_PER_PAGE, page * PRODUCTS_PER_PAGE);

    if (newItems.length === 0) {
      if (page === 1) setProducts([]);
      setAllDataLoaded(true);
      return;
    }

    if (page === 1) {
      setProducts(newItems);
    } else {
      setProducts(prevItems => [...prevItems, ...newItems]);
    }
  }, [page, filteredAllProducts, allDataLoaded]);

  useEffect(() => {
    setPage(1);
    setAllDataLoaded(false);
  }, [searchQuery]);

  const handleLoadMore = () => {
    if (!allDataLoaded) {
      setPage(prevPage => prevPage + 1);
    }
  };

  const renderFooter = () => {
    if (allDataLoaded && products.length > 0) {
      return <Text style={styles.endOfListText}>End of product list</Text>;
    }
    return null;
  };

  const renderProductItem = ({ item }: { item: StockItem }) => (
    <View style={{paddingHorizontal: 16}}>
      <ProductCard item={item} isAvailable={item.type !== 'SOLD'} />
    </View>
  );

  const ListHeader = () => (
    <View>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Daily Performance</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.datePickerContainer}>
        <TouchableOpacity style={styles.dateButton} onPress={() => setShowDatePicker(true)}>
          <Feather name="calendar" size={20} color="#007AFF" style={{marginRight: 8}}/>
          <Text style={styles.dateText}>{formatDate(currentDate)}</Text>
        </TouchableOpacity>
      </View>

      <DatePickerModal
        visible={showDatePicker}
        currentDate={currentDate}
        onDateChange={handleDateChange}
        onClose={() => setShowDatePicker(false)}
      />

      <DashboardStats 
        todaysPurchases={todaysPurchases} 
        todaysSoldOut={todaysSold} 
        todaysSales={todaysSalesRupees} 
        todaysProfit={todaysProfit} 
      />

      <View style={styles.recentProductsContainer}>
        <View style={styles.recentProductsHeader}>
          <Text style={styles.recentProductsTitle}>Recent Products</Text>
          <TouchableOpacity onPress={() => router.push(`/todays-sales-report?date=${date ? new Date(date as string).toISOString() : new Date().toISOString()}`)}>
            <Text style={styles.viewAllText}>VIEW SALES REPORT</Text>
          </TouchableOpacity>
        </View>
      <View style={[styles.searchContainer, isFocused && styles.searchContainerFocused]}>
        <Feather name="search" size={20} color={isFocused ? "#1565C0" : "#999"} style={styles.searchIcon} />
        <TextInput
          style={[styles.searchInput, Platform.OS === 'web' && { outline: 'none' } as any]}
          placeholder="Search model or IMEI..."
          placeholderTextColor="#999"
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
        />
      </View>
      </View>
    </View>
  );

  return (
    <LinearGradient
       colors={['#F8F9FA', '#F8F9FA']}
       style={{flex: 1}}
    >
      <FlatList
        data={products}
        renderItem={renderProductItem}
        keyExtractor={(item, index) => `${item.id}-${index}`}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.5}
        ListHeaderComponent={ListHeader}
        ListFooterComponent={renderFooter}
        contentContainerStyle={styles.container}
        ListEmptyComponent={(
            <View style={styles.emptyStateContainer}>
              <View style={styles.emptyStateContent}>
                <View style={styles.iconBackground}>
                  <Feather name="package" size={48} color="#1565C0" />
                </View>
                <Text style={styles.emptyStateTitle}>
                  {searchQuery.length > 0 ? 'NO MATCHES FOUND' : 'NO ACTIVITY ON THIS DATE'}
                </Text>
                <Text style={styles.emptyStateSubtitle}>
                  {searchQuery.length > 0
                    ? "We couldn't find any products matching your search."
                    : 'There were no products purchased or sold on this selected date.'}
                </Text>
              </View>
            </View>
          )}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    margin: 16,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  container: {
    paddingBottom: 50,
  },
  datePickerContainer: {
    alignItems: 'flex-start',
    paddingHorizontal: 12,
    marginBottom: 12,
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  dateText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#007AFF',
  },
  recentProductsContainer: {
    paddingHorizontal: 12,
    marginTop: 12,
  },
  recentProductsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  recentProductsTitle: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  viewAllText: {
    fontSize: 12,
    color: '#8A2BE2',
    fontWeight: 'bold',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingHorizontal: 12,
    marginTop: 12,
    elevation: 2,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  searchContainerFocused: {
    borderColor: '#1565C0',
    borderWidth: 2.5,
    shadowColor: '#1565C0',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    fontSize: 12,
    color: '#000',

  },
  endOfListText: {
    textAlign: 'center',
    padding: 16,
    fontSize: 12,
    color: '#888',
  },
  emptyStateContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    marginTop: 24,
  },
  emptyStateContent: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
    width: '100%',
  },
  iconBackground: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#E3F2FD',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1.5,
    borderColor: '#1565C0',
  },
  emptyStateTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#0D47A1',
    textAlign: 'center',
    marginBottom: 12,
  },
  emptyStateSubtitle: {
    fontSize: 12,
    color: '#1565C0',
    textAlign: 'center',
    lineHeight: 22,
  },
});

export default DailyPerformancePage;
