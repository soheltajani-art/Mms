import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, Platform } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { ChevronLeft, Trash2, AlertTriangle } from 'lucide-react-native';
import { resetApp } from './data/reset';
import CustomAlert from './components/CustomAlert';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ResetDataPage = () => {
  const router = useRouter();
  const [alertVisible, setAlertVisible] = useState(false);

  const handleReset = () => {
    setAlertVisible(true);
  };

  const confirmReset = async () => {
    try {
      setAlertVisible(false);
      await resetApp();
      
      // Set a flag to show notification after reset
      await AsyncStorage.setItem('showResetNotification', 'true');
      
      if (Platform.OS === 'web') {
        alert("All data has been reset successfully. The app will now return to the welcome screen.");
        router.replace('/WelcomePage');
      } else {
        Alert.alert(
          "Success",
          "All data has been reset successfully. The app will now return to the welcome screen.",
          [
            { 
              text: "OK", 
              onPress: () => router.replace('/WelcomePage') 
            }
          ]
        );
      }
    } catch (error) {
      if (Platform.OS === 'web') {
        alert("Failed to reset data. Please try again.");
      } else {
        Alert.alert("Error", "Failed to reset data. Please try again.");
      }
    }
  };

  const cancelReset = () => {
    setAlertVisible(false);
  };

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#EF4444" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Reset All Data</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={styles.contentContainer}>
        <View style={styles.card}>
          <View style={styles.dangerContainer}>
            <View style={styles.iconContainer}>
              <AlertTriangle size={48} color="#EF4444" />
            </View>
            <Text style={styles.dangerZone}>Danger Zone</Text>
            <Text style={styles.description}>
              This action will permanently delete all application data from your device.
            </Text>
            <Text style={styles.detailedDescription}>
              This includes all products, sales history, and any other saved information. This action cannot be undone. Use this only if you want to start over from a completely fresh state.
            </Text>
          </View>
          <TouchableOpacity style={styles.resetButton} onPress={handleReset}>
            <Trash2 size={20} color="#FFFFFF" />
            <Text style={styles.resetButtonText}>Reset All Application Data</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
      <CustomAlert
        visible={alertVisible}
        onClose={cancelReset}
        onConfirm={confirmReset}
        title="Are you absolutely sure?"
        message="This will permanently delete all your data. This action cannot be undone. Are you sure you want to proceed?"
        showPasswordInput={true}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC', // Light background
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    margin: 15,
    marginTop: Platform.OS === 'android' ? 40 : 15,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 3,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#EF4444', // Red for danger
  },
  backButton: {
    backgroundColor: '#FEF2F2', // Light red background
    borderRadius: 10,
    padding: 8,
    borderWidth: 1,
    borderColor: '#FEE2E2',
  },
  contentContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 25,
    alignItems: 'center',
    width: '100%',
    maxWidth: 500, // Max width for larger screens
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
    borderWidth: 1,
    borderColor: '#F3F4F6',
  },
  dangerContainer: {
    backgroundColor: '#FFF5F5', // Very light red background
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    width: '100%',
    marginBottom: 25,
    borderWidth: 1.5,
    borderColor: '#FEE2E2',
    borderStyle: 'solid', // Solid border for clarity
  },
  iconContainer: {
    backgroundColor: 'transparent',
    borderRadius: 999,
    padding: 10,
    marginBottom: 15,
  },
  dangerZone: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#EF4444',
    marginBottom: 10,
  },
  description: {
    fontSize: 15,
    color: '#4A5568',
    textAlign: 'center',
    marginBottom: 10,
    fontWeight: '600',
    lineHeight: 22,
  },
  detailedDescription: {
    fontSize: 13,
    color: '#718096',
    textAlign: 'center',
    lineHeight: 18,
  },
  resetButton: {
    backgroundColor: '#EF4444',
    borderRadius: 15,
    paddingVertical: 16,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 4,
  },
  resetButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 10,
    letterSpacing: 0.5,
  },
});

export default ResetDataPage;
