
import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, FlatList, SafeAreaView } from 'react-native';
import { ChevronLeft, Search, PackageMinus, X } from 'lucide-react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { getHistory, HistoryItem } from './data/storage';
import SalesReport from './components/SalesReport';
import { PhotoPreview } from '../components/PhotoPreview';

const SoldOutItemsPage = () => {
  const router = useRouter();
  const [soldProducts, setSoldProducts] = useState<HistoryItem[]>([]);
  const [displayProducts, setDisplayProducts] = useState<HistoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [showPhotoPreview, setShowPhotoPreview] = useState(false);
  const [previewPhotoUri, setPreviewPhotoUri] = useState<string | undefined>(undefined);

  const fetchData = useCallback(async () => {
    const history = await getHistory();
    const sold = history.filter(item => item.type === 'SOLD');
    setSoldProducts(sold);
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchData();
    }, [fetchData])
  );

  useEffect(() => {
    const filteredSold = soldProducts.filter(product => {
      const modelMatch = product.model?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false;
      const imeiMatch = product.primaryImei?.includes(searchQuery) ?? false;
      return modelMatch || imeiMatch;
    });
    setDisplayProducts(filteredSold);
  }, [searchQuery, soldProducts]);

  const handleViewPhoto = (photoUri: string | undefined) => {
    if (photoUri) {
      setPreviewPhotoUri(photoUri);
      setShowPhotoPreview(true);
    }
  };

  const handleClearSearch = () => {
    setSearchQuery('');
    setFocusedField(null);
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ChevronLeft size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Sold Out Items</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={[styles.searchContainer, focusedField === 'search' && styles.searchContainerFocused]}>
        <Search size={20} color={focusedField === 'search' ? '#C62828' : '#909090'} style={styles.searchIcon} />
        <TextInput
          placeholder="Search sold items..."
          placeholderTextColor="#909090"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
          onFocus={() => setFocusedField('search')}
          onBlur={() => setFocusedField(null)}
        />
        {searchQuery ? (
          <TouchableOpacity onPress={handleClearSearch} style={styles.clearButton}>
            <X size={18} color="#909090" />
          </TouchableOpacity>
        ) : null}
      </View>

      <View style={styles.infoRow}>
        <View style={styles.itemsSoldCountainer}>
          <Text style={styles.itemsSoldText}>
            {displayProducts.length} ITEMS SOLD
          </Text>
        </View>
      </View>

      <View style={styles.contentWrapper}>
        {displayProducts.length > 0 ? (
          <SalesReport sales={displayProducts} onViewPhoto={handleViewPhoto} />
        ) : (
          <View style={styles.emptyStateContainer}>
            <View style={styles.iconBackground}>
              <PackageMinus size={48} color="#C62828" />
            </View>
            <Text style={styles.emptyStateTitle}>NO ITEMS FOUND</Text>
            <Text style={styles.emptyStateSubtitle}>
              {searchQuery.length > 0 
                ? "We couldn't find any sold products matching your search."
                : "When an item sells out, it will appear here."}
            </Text>
          </View>
        )}
      </View>

      <PhotoPreview
        isVisible={showPhotoPreview}
        photoUri={previewPhotoUri}
        onClose={() => setShowPhotoPreview(false)}
        allowRetake={false}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFEBEE',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    marginHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  backButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 8,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
  },
  contentWrapper: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    overflow: 'hidden',
    marginHorizontal: 12,
    marginBottom: 12,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    marginHorizontal: 12,
    paddingHorizontal: 12,
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
    overflow: 'hidden',
  },
  searchContainerFocused: {
    borderColor: '#C62828',
    borderWidth: 2.5,
    shadowColor: '#C62828',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 8,
    backgroundColor: '#FFFFFF',
  },
  searchIcon: {
    marginRight: 12,
  },
  clearButton: {
    padding: 8,
    marginLeft: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    fontSize: 14,
    color: '#000',

  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 12,
    marginTop: 12,
    marginBottom: 12,
  },
  itemsSoldCountainer: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  itemsSoldText: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#B71C1C',
    letterSpacing: 0.5,
  },
  emptyStateContainer: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconBackground: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#FFCDD2',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 32,
    borderWidth: 1.5,
    borderColor: '#C62828',
  },
  emptyStateTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#B71C1C',
    textAlign: 'center',
    marginBottom: 12,
  },
  emptyStateSubtitle: {
    fontSize: 14,
    color: '#C62828',
    textAlign: 'center',
    lineHeight: 22,
  },
});

export default SoldOutItemsPage;
