import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Modal, Dimensions } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { X, Zap, ZapOff } from 'lucide-react-native';
import CameraPermissionModal from '../app/components/CameraPermissionModal';
import { getOptimalCameraResolution, formatMegapixels } from '../utils/cameraResolution';

interface BarcodeScannerProps {
  isVisible: boolean;
  onClose: () => void;
  onScan: (data: string) => void;
}

export const BarcodeScanner: React.FC<BarcodeScannerProps> = ({ isVisible, onClose, onScan }) => {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);
  const [torch, setTorch] = useState(false);
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [pictureSize, setPictureSize] = useState<string>();
  const [cameraResolutionInfo, setCameraResolutionInfo] = useState<string>('');

  const cameraRef = useRef<CameraView>(null);

  useEffect(() => {
    if (isVisible) {
      setScanned(false);
      if (permission && !permission.granted && permission.canAskAgain) {
        setShowPermissionModal(true);
      }
    }
  }, [isVisible, permission]);

  const handleRequestPermission = async () => {
    setShowPermissionModal(false);
    const result = await requestPermission();
    if (!result.granted) {
      onClose();
    }
  };

  const handleCameraReady = async () => {
    if (cameraRef.current) {
      try {
        const resolutionInfo = await getOptimalCameraResolution(cameraRef.current);
        if (resolutionInfo) {
          setPictureSize(resolutionInfo.resolution);
          const displayText = `${formatMegapixels(resolutionInfo.megapixels)} (${resolutionInfo.resolution})`;
          setCameraResolutionInfo(displayText);
        }
      } catch (e) {
        console.warn('Failed to get optimal camera resolution:', e);
      }
    }
  };

  const handleBarCodeScanned = ({ data }: { data: string }) => {
    const cleanData = data.trim();
    if (cleanData.length === 15 && /^\d+$/.test(cleanData)) {
      setScanned(true);
      onScan(cleanData);
    }
  };

  if (!permission) {
    return null;
  }

  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={isVisible}
      onRequestClose={onClose}
    >
      <View style={styles.container}>
        {!permission.granted ? (
          <View style={styles.permissionContainer}>
            <CameraPermissionModal 
              visible={showPermissionModal}
              onClose={onClose}
              onConfirm={handleRequestPermission}
            />
            <Text style={styles.permissionText}>Camera access is required to scan barcodes.</Text>
            <TouchableOpacity style={styles.permissionButton} onPress={() => setShowPermissionModal(true)}>
              <Text style={styles.permissionButtonText}>Request Permission</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.closeButton} onPress={onClose}>
              <X size={30} color="#fff" />
            </TouchableOpacity>
          </View>
        ) : (
          <CameraView
            ref={cameraRef}
            style={styles.camera}
            facing="back"
            enableTorch={torch}
            autofocus="on"
            zoom={0.01}
            pictureSize={pictureSize}
            onCameraReady={handleCameraReady}
            onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
            barcodeScannerSettings={{
              barcodeTypes: ["code128", "code39", "ean13", "upc_a", "upc_e", "itf14"],
            }}
          >
            <View style={styles.overlay}>
              <View style={styles.header}>
                <TouchableOpacity style={styles.iconButton} onPress={() => setTorch(!torch)}>
                  {torch ? <Zap size={28} color="#FFD700" /> : <ZapOff size={28} color="#fff" />}
                </TouchableOpacity>
                <View style={styles.headerTextContainer}>
                  <Text style={styles.headerText}>Scan 15-Digit Barcode</Text>
                  {cameraResolutionInfo ? (
                    <Text style={styles.resolutionText}>{cameraResolutionInfo}</Text>
                  ) : null}
                </View>
                <TouchableOpacity style={styles.iconButton} onPress={onClose}>
                  <X size={28} color="#fff" />
                </TouchableOpacity>
              </View>

              <View style={styles.scanAreaContainer}>
                <View style={styles.scanArea}>
                  <View style={[styles.corner, styles.topLeft]} />
                  <View style={[styles.corner, styles.topRight]} />
                  <View style={[styles.corner, styles.bottomLeft]} />
                  <View style={[styles.corner, styles.bottomRight]} />
                  <View style={styles.scanLine} />
                </View>
                <Text style={styles.hintText}>Align barcode within the frame</Text>
              </View>

              <View style={styles.footer}>
                <Text style={styles.footerText}>Searching for 15-digit IMEI...</Text>
              </View>
            </View>
          </CameraView>
        )}
      </View>
    </Modal>
  );
};

const { width, height } = Dimensions.get('window');
const isSmallDevice = width < 375;
const scanAreaSize = width * (isSmallDevice ? 0.8 : 0.7);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  camera: {
    flex: 1,
  },
  permissionContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  permissionText: {
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
  },
  permissionButton: {
    backgroundColor: '#007AFF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  permissionButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  closeButton: {
    position: 'absolute',
    top: 50,
    right: 20,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'space-between',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: height * 0.06,
    paddingHorizontal: 20,
  },
  headerTextContainer: {
    flex: 1,
    alignItems: 'center',
  },
  headerText: {
    color: '#fff',
    fontSize: isSmallDevice ? 16 : 18,
    fontWeight: '600',
  },
  resolutionText: {
    color: '#FFD700',
    fontSize: isSmallDevice ? 12 : 14,
    fontWeight: '500',
    marginTop: 4,
  },
  iconButton: {
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    borderRadius: 22,
  },
  scanAreaContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  scanArea: {
    width: scanAreaSize,
    height: scanAreaSize * 0.6,
    borderWidth: 0,
    borderColor: '#fff',
    backgroundColor: 'transparent',
    position: 'relative',
  },
  scanLine: {
    height: 2,
    backgroundColor: '#007AFF',
    width: '100%',
    position: 'absolute',
    top: '50%',
  },
  corner: {
    position: 'absolute',
    width: 20,
    height: 20,
    borderColor: '#007AFF',
  },
  topLeft: {
    top: 0,
    left: 0,
    borderTopWidth: 4,
    borderLeftWidth: 4,
  },
  topRight: {
    top: 0,
    right: 0,
    borderTopWidth: 4,
    borderRightWidth: 4,
  },
  bottomLeft: {
    bottom: 0,
    left: 0,
    borderBottomWidth: 4,
    borderLeftWidth: 4,
  },
  bottomRight: {
    bottom: 0,
    right: 0,
    borderBottomWidth: 4,
    borderRightWidth: 4,
  },
  hintText: {
    color: '#fff',
    marginTop: 20,
    fontSize: 16,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 15,
    paddingVertical: 5,
    borderRadius: 20,
  },
  footer: {
    paddingBottom: 50,
    alignItems: 'center',
  },
  footerText: {
    color: '#fff',
    fontSize: 14,
    opacity: 0.8,
  },
});
