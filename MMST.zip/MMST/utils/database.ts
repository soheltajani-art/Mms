import AsyncStorage from '@react-native-async-storage/async-storage';

const HISTORY_KEY = 'inventory_history';

export interface HistoryItem {
  id: string;
  type: 'PURCHASE' | 'SOLD';
  model: string;
  primaryImei: string;
  secondaryId: string;
  purchaseCost: number;
  sellingPrice?: number;
  profit?: number;
  purchaseDate: string;
  soldDate?: string;
  timestamp: string;
  compulsoryPhoto?: string;
  optionalPhoto?: string;
}

export const getHistory = async (): Promise<HistoryItem[]> => {
  try {
    const historyJson = await AsyncStorage.getItem(HISTORY_KEY);
    return historyJson ? JSON.parse(historyJson) : [];
  } catch (error) {
    console.error("Failed to load history", error);
    return [];
  }
};

export const addToHistory = async (item: HistoryItem) => {
  try {
    const history = await getHistory();
    history.push(item);
    await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  } catch (error) {
    console.error("Failed to add to history", error);
  }
};
