const createExpoWebpackConfigAsync = require('@expo/webpack-config');

module.exports = async function (env, argv) {
  const config = await createExpoWebpackConfigAsync(env, argv);
  // Customize the config before returning it.
  config.watchOptions = {
    poll: true,
  };
  config.resolve.alias = {
    ...config.resolve.alias,
    'stream': 'stream-browserify',
    'readable-stream': 'readable-stream/readable-browser.js'
  };
  return config;
};
